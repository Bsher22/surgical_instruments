/**
 * TypeScript Types for SurgicalPrep
 * Types matching backend Pydantic schemas
 */

// ============================================
// User Types
// ============================================

export type UserRole = 
  | 'surgical_tech_student'
  | 'certified_surgical_tech'
  | 'or_nurse'
  | 'surgical_tech_educator'
  | 'other';

export type SubscriptionTier = 'free' | 'premium';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  institution?: string | null;
  subscription_tier: SubscriptionTier;
  subscription_expires_at?: string | null;
  created_at: string;
  updated_at: string;
}

// ============================================
// Instrument Types
// ============================================

export type InstrumentCategory =
  | 'cutting'
  | 'grasping'
  | 'clamping'
  | 'retracting'
  | 'suturing'
  | 'specialty'
  | 'other';

export interface Instrument {
  id: string;
  name: string;
  aliases?: string[] | null;
  category: InstrumentCategory;
  description?: string | null;
  primary_uses?: string[] | null;
  common_procedures?: string[] | null;
  handling_notes?: string | null;
  image_url?: string | null;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

export interface InstrumentListItem {
  id: string;
  name: string;
  category: InstrumentCategory;
  image_url?: string | null;
  is_premium: boolean;
}

// ============================================
// Preference Card Types
// ============================================

export type ItemCategory =
  | 'instrument'
  | 'supply'
  | 'suture'
  | 'implant'
  | 'other';

export interface PreferenceCardPhoto {
  id: string;
  card_id: string;
  photo_url: string;
  caption?: string | null;
  order_index: number;
  created_at: string;
}

export interface PreferenceCardItem {
  id: string;
  card_id: string;
  instrument_id?: string | null;
  item_name: string;
  quantity?: number | null;
  size?: string | null;
  notes?: string | null;
  category?: ItemCategory | null;
  order_index: number;
  created_at: string;
  updated_at: string;
  // Populated when instrument_id is present
  instrument?: InstrumentListItem | null;
}

export interface PreferenceCard {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string | null;
  procedure_name?: string | null;
  specialty?: string | null;
  notes?: string | null;
  setup_notes?: string | null;
  is_template: boolean;
  is_public: boolean;
  created_at: string;
  updated_at: string;
  items?: PreferenceCardItem[];
  photos?: PreferenceCardPhoto[];
}

export interface PreferenceCardListItem {
  id: string;
  title: string;
  surgeon_name?: string | null;
  procedure_name?: string | null;
  specialty?: string | null;
  is_template: boolean;
  item_count: number;
  updated_at: string;
}

// ============================================
// Card Create/Update DTOs
// ============================================

export interface CreatePreferenceCardItemInput {
  instrument_id?: string | null;
  item_name: string;
  quantity?: number | null;
  size?: string | null;
  notes?: string | null;
  category?: ItemCategory | null;
  order_index?: number;
}

export interface CreatePreferenceCardInput {
  title: string;
  surgeon_name?: string | null;
  procedure_name?: string | null;
  specialty?: string | null;
  notes?: string | null;
  setup_notes?: string | null;
  items?: CreatePreferenceCardItemInput[];
}

export interface UpdatePreferenceCardInput {
  title?: string;
  surgeon_name?: string | null;
  procedure_name?: string | null;
  specialty?: string | null;
  notes?: string | null;
  setup_notes?: string | null;
}

export interface UpdatePreferenceCardItemInput {
  id?: string;
  instrument_id?: string | null;
  item_name?: string;
  quantity?: number | null;
  size?: string | null;
  notes?: string | null;
  category?: ItemCategory | null;
  order_index?: number;
}

// ============================================
// Quiz Types
// ============================================

export type QuizType = 'flashcard' | 'multiple_choice';
export type QuestionType = 'image_to_name' | 'name_to_use' | 'image_to_category';

export interface QuizQuestion {
  id: string;
  instrument_id: string;
  instrument: InstrumentListItem;
  question_type: QuestionType;
  options?: string[];
  correct_answer: string;
}

export interface QuizSession {
  id: string;
  user_id: string;
  quiz_type: QuizType;
  category_filter?: InstrumentCategory | null;
  total_questions: number;
  correct_answers: number;
  completed_at?: string | null;
  created_at: string;
  questions?: QuizQuestion[];
}

export interface QuizResult {
  session_id: string;
  total_questions: number;
  correct_answers: number;
  score_percentage: number;
  time_taken_seconds: number;
}

// ============================================
// Study Progress Types
// ============================================

export interface UserInstrumentProgress {
  id: string;
  user_id: string;
  instrument_id: string;
  times_studied: number;
  times_correct: number;
  last_studied_at?: string | null;
  next_review_at?: string | null;
  ease_factor: number;
  interval_days: number;
  is_bookmarked: boolean;
}

export interface StudyStats {
  total_instruments_studied: number;
  total_quizzes_completed: number;
  average_score: number;
  current_streak: number;
  due_for_review_count: number;
}

// ============================================
// API Response Types
// ============================================

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  total_pages: number;
}

export interface ApiError {
  detail: string;
  status_code?: number;
}

// ============================================
// Query Parameter Types
// ============================================

export interface GetCardsParams {
  search?: string;
  specialty?: string;
  page?: number;
  page_size?: number;
  include_templates?: boolean;
}

export interface GetInstrumentsParams {
  search?: string;
  category?: InstrumentCategory;
  page?: number;
  page_size?: number;
}

export interface StartQuizParams {
  quiz_type: QuizType;
  category?: InstrumentCategory;
  question_count?: number;
}
