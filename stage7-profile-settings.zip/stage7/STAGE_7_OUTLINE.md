# Stage 7: User Profile & Settings - Implementation Outline

## Overview

Stage 7 implements comprehensive user account management and application settings. This stage delivers the profile screen with user information display and editing, subscription status visualization, usage statistics, settings management for quiz preferences and display options, and critical account actions including password change, logout, and account deletion.

---

## Stage Dependencies

**Requires from previous stages:**
- Stage 2: Auth store, secure token storage, API client with interceptors
- Stage 3: Instruments API (for stats calculations)
- Stage 5: Cards API (for stats calculations)
- Stage 6: Quiz API and progress tracking (for stats calculations)

---

## Architecture Overview

### New Files Structure
```
mobile/src/
├── api/
│   └── user.ts                    # User API functions (profile, settings, account)
├── components/
│   └── profile/
│       ├── index.ts               # Barrel exports
│       ├── ProfileHeader.tsx      # User avatar and basic info
│       ├── SubscriptionCard.tsx   # Premium status and upgrade CTA
│       ├── UsageStatsCard.tsx     # Cards created, instruments studied, quizzes
│       ├── SettingsSection.tsx    # Reusable settings section wrapper
│       ├── SettingsRow.tsx        # Individual setting row (toggle, link, etc.)
│       └── EditProfileModal.tsx   # Modal form for editing profile
├── hooks/
│   └── useUser.ts                 # React Query hooks for user data
├── stores/
│   └── settingsStore.ts           # Local settings (dark mode, quiz prefs)
├── types/
│   └── user.ts                    # User-related TypeScript types

mobile/app/(tabs)/profile/
├── index.tsx                      # Main profile screen
├── settings.tsx                   # Settings screen
├── change-password.tsx            # Change password screen
└── delete-account.tsx             # Delete account confirmation screen
```

---

## 7A: Profile Screen

### Features
1. **Profile Header**
   - User avatar (initials-based or uploaded photo)
   - Full name display
   - Email display
   - Role badge (Student, Surgical Tech, RN, etc.)
   - Institution name
   - Edit button → opens EditProfileModal

2. **Subscription Status Card**
   - Current tier indicator (Free/Premium badge)
   - If premium: expiration date, renewal info
   - If free: feature limits summary
   - "Upgrade to Premium" CTA button (navigates to paywall - Stage 8)
   - Visual distinction between tiers

3. **Usage Statistics Card**
   - Cards created: X / limit (or unlimited)
   - Instruments studied: total count
   - Quizzes completed: total count
   - Current study streak: X days
   - Animated progress indicators

4. **Edit Profile Modal**
   - Pre-filled form with current values
   - Editable fields: name, role, institution
   - Email shown but not editable (security)
   - Save/Cancel buttons
   - Loading state during save
   - Validation errors display

### API Endpoints Used
- `GET /api/users/me` - Get current user profile
- `PUT /api/users/me` - Update profile
- `GET /api/users/me/stats` - Get usage statistics

---

## 7B: Settings Screen

### Features
1. **Quiz Preferences Section**
   - Default question count: Slider (5-50, default 20)
   - Timer enabled: Toggle switch
   - Preferred categories: Multi-select chips
   - These persist to local storage + sync to backend

2. **Display Settings Section**
   - Dark mode: Toggle switch (with system default option)
   - Text size: Small/Medium/Large selector
   - Haptic feedback: Toggle switch

3. **About Section**
   - App version number (from app.json)
   - Privacy Policy link → opens in-app browser
   - Terms of Service link → opens in-app browser
   - Contact Support link → opens email composer
   - Rate the App link → opens app store

4. **Account Section**
   - Change Password → navigates to change-password screen
   - Logout button
   - Delete Account → navigates to delete-account screen

### State Management
- Local settings stored in Zustand with AsyncStorage persistence
- Quiz preferences synced to backend on change
- Dark mode applies to entire app via context

---

## 7C: Account Actions

### Change Password Flow
1. Screen with form:
   - Current password (required)
   - New password (required, min 8 chars)
   - Confirm new password (must match)
2. Validation before submission
3. API call to change password endpoint
4. Success: Show confirmation, navigate back
5. Error: Display error message (wrong current password, etc.)

### Logout Flow
1. Confirmation alert (optional, can be direct)
2. Clear auth tokens from secure storage
3. Clear user data from stores
4. Navigate to login screen
5. Reset navigation stack

### Delete Account Flow
1. Warning screen explaining consequences:
   - All data will be permanently deleted
   - Cards, progress, quiz history gone
   - Subscription cancelled (if applicable)
2. Require typing "DELETE" to confirm
3. Require password entry for verification
4. API call to delete account
5. Clear all local data
6. Navigate to signup screen

---

## Implementation Details

### TypeScript Types

```typescript
// User profile and settings types
interface UserProfile {
  id: string;
  email: string;
  full_name: string;
  role: UserRole;
  institution?: string;
  avatar_url?: string;
  subscription_tier: SubscriptionTier;
  subscription_expires_at?: string;
  created_at: string;
  updated_at: string;
}

type UserRole = 'student' | 'surgical_tech' | 'rn' | 'cst' | 'other';
type SubscriptionTier = 'free' | 'premium';

interface UserStats {
  cards_created: number;
  cards_limit: number | null; // null = unlimited
  instruments_studied: number;
  quizzes_completed: number;
  current_streak: number;
  longest_streak: number;
  total_study_time_minutes: number;
}

interface UserSettings {
  quiz_question_count: number;
  quiz_timer_enabled: boolean;
  preferred_categories: string[];
  dark_mode: 'light' | 'dark' | 'system';
  text_size: 'small' | 'medium' | 'large';
  haptic_feedback_enabled: boolean;
}

interface UpdateProfileRequest {
  full_name?: string;
  role?: UserRole;
  institution?: string;
}

interface ChangePasswordRequest {
  current_password: string;
  new_password: string;
}
```

### API Client Functions

```typescript
// GET /api/users/me
export const getCurrentUser = async (): Promise<UserProfile>

// PUT /api/users/me
export const updateProfile = async (data: UpdateProfileRequest): Promise<UserProfile>

// GET /api/users/me/stats
export const getUserStats = async (): Promise<UserStats>

// GET /api/users/me/settings
export const getUserSettings = async (): Promise<UserSettings>

// PUT /api/users/me/settings
export const updateUserSettings = async (data: Partial<UserSettings>): Promise<UserSettings>

// POST /api/auth/change-password
export const changePassword = async (data: ChangePasswordRequest): Promise<void>

// DELETE /api/users/me
export const deleteAccount = async (password: string): Promise<void>
```

### React Query Hooks

```typescript
// Profile data with caching
export const useCurrentUser = () => useQuery({
  queryKey: ['user', 'profile'],
  queryFn: getCurrentUser,
  staleTime: 5 * 60 * 1000, // 5 minutes
});

// User stats with frequent refresh
export const useUserStats = () => useQuery({
  queryKey: ['user', 'stats'],
  queryFn: getUserStats,
  staleTime: 60 * 1000, // 1 minute
});

// Update profile mutation
export const useUpdateProfile = () => useMutation({
  mutationFn: updateProfile,
  onSuccess: () => {
    queryClient.invalidateQueries({ queryKey: ['user', 'profile'] });
  },
});
```

### Settings Store (Zustand)

```typescript
interface SettingsState {
  // Local settings
  darkMode: 'light' | 'dark' | 'system';
  textSize: 'small' | 'medium' | 'large';
  hapticFeedback: boolean;
  
  // Quiz preferences (also synced to backend)
  quizQuestionCount: number;
  quizTimerEnabled: boolean;
  preferredCategories: string[];
  
  // Actions
  setDarkMode: (mode: 'light' | 'dark' | 'system') => void;
  setTextSize: (size: 'small' | 'medium' | 'large') => void;
  setHapticFeedback: (enabled: boolean) => void;
  setQuizQuestionCount: (count: number) => void;
  setQuizTimerEnabled: (enabled: boolean) => void;
  setPreferredCategories: (categories: string[]) => void;
  resetToDefaults: () => void;
}
```

---

## UI Components Specifications

### ProfileHeader
- Circular avatar (80x80) with initials fallback
- Name in bold, 20px
- Email in gray, 14px
- Role badge: colored pill based on role
- Institution in gray, 14px (if set)
- Edit icon button in top-right

### SubscriptionCard
- Full-width card with gradient background (different for free/premium)
- Tier badge in corner
- Large tier name display
- Expiration date or limit info
- CTA button (upgrade or manage)

### UsageStatsCard
- 2x2 grid layout of stat items
- Each stat: icon, number, label
- Numbers animate on load (count up)
- Progress bars where applicable

### SettingsRow
- Props: icon, label, type (toggle/link/select/slider), value, onChange
- Toggle type: shows switch on right
- Link type: shows chevron, handles onPress
- Select type: shows current value, opens picker
- Slider type: shows slider with value label

### EditProfileModal
- Modal sliding from bottom (70% height)
- Form with TextInputs
- Role dropdown using Picker
- Save and Cancel buttons at bottom
- Keyboard avoiding behavior

---

## Screen Layouts

### Profile Screen Layout
```
┌─────────────────────────────┐
│         Profile             │ ← Header with settings icon
├─────────────────────────────┤
│  ┌───────────────────────┐  │
│  │    [Avatar]           │  │
│  │    John Smith         │  │
│  │    john@email.com     │  │
│  │    [CST Badge]        │  │
│  │    Memorial Hospital  │  │
│  │              [Edit]   │  │
│  └───────────────────────┘  │
│                             │
│  ┌───────────────────────┐  │
│  │  ★ PREMIUM            │  │
│  │  Expires: Jan 2027    │  │
│  │  [Manage Subscription]│  │
│  └───────────────────────┘  │
│                             │
│  ┌───────────────────────┐  │
│  │  📊 Your Stats        │  │
│  │  ┌─────┐ ┌─────┐      │  │
│  │  │  12 │ │ 145 │      │  │
│  │  │Cards│ │Instr│      │  │
│  │  └─────┘ └─────┘      │  │
│  │  ┌─────┐ ┌─────┐      │  │
│  │  │  28 │ │  7  │      │  │
│  │  │Quiz │ │Streak│     │  │
│  │  └─────┘ └─────┘      │  │
│  └───────────────────────┘  │
│                             │
│  [Settings]  [Help]         │
└─────────────────────────────┘
```

### Settings Screen Layout
```
┌─────────────────────────────┐
│    ←     Settings           │
├─────────────────────────────┤
│                             │
│  QUIZ PREFERENCES           │
│  ├─ Question Count    [20]──│
│  ├─ Timer Enabled     [ON]  │
│  └─ Categories      [4 sel] │
│                             │
│  DISPLAY                    │
│  ├─ Dark Mode      [System] │
│  ├─ Text Size      [Medium] │
│  └─ Haptic Feedback   [ON]  │
│                             │
│  ABOUT                      │
│  ├─ Version           1.0.0 │
│  ├─ Privacy Policy      →   │
│  ├─ Terms of Service    →   │
│  ├─ Contact Support     →   │
│  └─ Rate the App        →   │
│                             │
│  ACCOUNT                    │
│  ├─ Change Password     →   │
│  ├─ [  Logout  ]            │
│  └─ Delete Account      →   │
│                             │
└─────────────────────────────┘
```

---

## Testing Checklist

### Profile Screen
- [ ] User info displays correctly
- [ ] Edit profile modal opens and pre-fills
- [ ] Profile updates save correctly
- [ ] Subscription status accurate (free vs premium)
- [ ] Stats load and display
- [ ] Stats update after completing quiz/creating card

### Settings Screen
- [ ] All toggles work and persist
- [ ] Slider adjusts question count
- [ ] Category selection works
- [ ] Dark mode applies to app
- [ ] Links open correct destinations
- [ ] Version number displays correctly

### Account Actions
- [ ] Change password validates inputs
- [ ] Change password succeeds with correct current password
- [ ] Change password fails with wrong current password
- [ ] Logout clears all data and redirects to login
- [ ] Delete account requires confirmation
- [ ] Delete account requires password
- [ ] Delete account removes all user data

---

## Deliverables

1. **API Layer**: `src/api/user.ts` with all user/settings endpoints
2. **Types**: `src/types/user.ts` with comprehensive TypeScript types
3. **Hooks**: `src/hooks/useUser.ts` with React Query hooks
4. **Store**: `src/stores/settingsStore.ts` for local settings
5. **Components**: 6 reusable profile components
6. **Screens**: 4 screen files (profile, settings, change-password, delete-account)
7. **Updated Navigation**: Tab icon and routes for profile section

---

## Notes for Stage 8 Integration

This stage prepares for Stage 8 (Subscriptions) by:
- Creating the subscription status display (will link to paywall)
- Showing usage limits for free tier
- Including "Upgrade" CTA buttons
- Settings store ready for premium feature toggles

The `SubscriptionCard` component includes a placeholder navigation to a paywall screen that will be built in Stage 8.
