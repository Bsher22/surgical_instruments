/**
 * Quiz & Study React Query Hooks
 * SurgicalPrep - Stage 6A
 * 
 * Custom hooks for quiz sessions, flashcards, and study progress
 * using TanStack React Query for caching and data fetching.
 */

import {
  useQuery,
  useMutation,
  useQueryClient,
  useInfiniteQuery,
  type UseQueryOptions,
  type UseMutationOptions,
} from '@tanstack/react-query';

import {
  // Quiz session
  startQuizSession,
  getQuizSession,
  submitQuizAnswer,
  endQuizSession,
  abandonQuizSession,
  
  // Flashcard session
  startFlashcardSession,
  getFlashcardSession,
  recordFlashcardResult,
  endFlashcardSession,
  getFlashcardDeck,
  
  // Progress
  getStudyProgress,
  getInstrumentProgress,
  getDueForReview,
  toggleInstrumentBookmark,
  resetInstrumentProgress,
  resetAllProgress,
  
  // History
  getQuizHistory,
  getQuizSessionDetails,
  
  // Limits
  getQuizLimits,
} from '../api/quiz';

import type {
  QuizConfig,
  FlashcardConfig,
  QuizSession,
  FlashcardSession,
  AnswerSubmission,
  AnswerResult,
  FlashcardResultSubmission,
  FlashcardResultResponse,
  QuizSessionResult,
  FlashcardSessionResult,
  StudyProgress,
  InstrumentProgress,
  DueForReviewParams,
  DueForReviewResponse,
  QuizHistoryParams,
  QuizHistoryResponse,
  QuizLimits,
  StartQuizResponse,
  StartFlashcardResponse,
} from '../types/quiz';

// =============================================================================
// Query Keys
// =============================================================================

export const quizKeys = {
  all: ['quiz'] as const,
  
  // Sessions
  sessions: () => [...quizKeys.all, 'sessions'] as const,
  session: (id: string) => [...quizKeys.sessions(), id] as const,
  
  // Flashcards
  flashcards: () => [...quizKeys.all, 'flashcards'] as const,
  flashcardSession: (id: string) => [...quizKeys.flashcards(), 'session', id] as const,
  flashcardDeck: (config: FlashcardConfig) => [...quizKeys.flashcards(), 'deck', config] as const,
  
  // Progress
  progress: () => [...quizKeys.all, 'progress'] as const,
  studyProgress: () => [...quizKeys.progress(), 'study'] as const,
  instrumentProgress: (id: string) => [...quizKeys.progress(), 'instrument', id] as const,
  dueForReview: (params?: DueForReviewParams) => [...quizKeys.progress(), 'due', params] as const,
  
  // History
  history: () => [...quizKeys.all, 'history'] as const,
  historyList: (params?: QuizHistoryParams) => [...quizKeys.history(), 'list', params] as const,
  historyDetail: (id: string) => [...quizKeys.history(), 'detail', id] as const,
  
  // Limits
  limits: () => [...quizKeys.all, 'limits'] as const,
};

// =============================================================================
// Study Progress Hooks
// =============================================================================

/**
 * Fetch user's overall study progress and statistics.
 * Cached for 5 minutes, refetches on window focus.
 */
export function useStudyProgress(
  options?: Omit<UseQueryOptions<StudyProgress>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.studyProgress(),
    queryFn: getStudyProgress,
    staleTime: 5 * 60 * 1000, // 5 minutes
    gcTime: 30 * 60 * 1000,   // 30 minutes (formerly cacheTime)
    ...options,
  });
}

/**
 * Fetch detailed progress for a specific instrument.
 */
export function useInstrumentProgress(
  instrumentId: string,
  options?: Omit<UseQueryOptions<InstrumentProgress>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.instrumentProgress(instrumentId),
    queryFn: () => getInstrumentProgress(instrumentId),
    enabled: !!instrumentId,
    staleTime: 2 * 60 * 1000, // 2 minutes
    ...options,
  });
}

/**
 * Fetch instruments due for spaced repetition review.
 * Supports pagination and filtering.
 */
export function useDueForReview(
  params: DueForReviewParams = {},
  options?: Omit<UseQueryOptions<DueForReviewResponse>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.dueForReview(params),
    queryFn: () => getDueForReview(params),
    staleTime: 2 * 60 * 1000,
    ...options,
  });
}

/**
 * Infinite query for paginated due-for-review items.
 */
export function useDueForReviewInfinite(
  params: Omit<DueForReviewParams, 'offset'> = {}
) {
  return useInfiniteQuery({
    queryKey: quizKeys.dueForReview(params),
    queryFn: ({ pageParam = 0 }) => getDueForReview({ ...params, offset: pageParam }),
    initialPageParam: 0,
    getNextPageParam: (lastPage) => 
      lastPage.has_more ? lastPage.next_offset : undefined,
    staleTime: 2 * 60 * 1000,
  });
}

// =============================================================================
// Quiz Session Hooks
// =============================================================================

/**
 * Fetch an existing quiz session.
 */
export function useQuizSession(
  sessionId: string | null,
  options?: Omit<UseQueryOptions<QuizSession>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.session(sessionId!),
    queryFn: () => getQuizSession(sessionId!),
    enabled: !!sessionId,
    staleTime: 0, // Always fetch fresh session data
    ...options,
  });
}

/**
 * Start a new quiz session.
 * Invalidates progress and limits after successful start.
 */
export function useStartQuizSession(
  options?: UseMutationOptions<StartQuizResponse, Error, QuizConfig>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: startQuizSession,
    onSuccess: (data) => {
      // Cache the new session
      queryClient.setQueryData(quizKeys.session(data.session.id), data.session);
      // Invalidate limits as a quiz was started
      queryClient.invalidateQueries({ queryKey: quizKeys.limits() });
    },
    ...options,
  });
}

/**
 * Submit an answer for a quiz question.
 * Optimistically updates local session state.
 */
export function useSubmitQuizAnswer(
  options?: UseMutationOptions<AnswerResult, Error, AnswerSubmission>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: submitQuizAnswer,
    onSuccess: (result, variables) => {
      // Update cached session with the new answer
      queryClient.setQueryData<QuizSession>(
        quizKeys.session(variables.session_id),
        (oldSession) => {
          if (!oldSession) return oldSession;
          return {
            ...oldSession,
            current_question_index: oldSession.current_question_index + 1,
            score: result.is_correct ? oldSession.score + result.points_earned : oldSession.score,
            answers: [
              ...oldSession.answers,
              {
                question_id: variables.question_id,
                selected_option_id: variables.selected_option_id,
                is_correct: result.is_correct,
                time_taken_seconds: variables.time_taken_seconds,
                answered_at: new Date().toISOString(),
              },
            ],
          };
        }
      );
    },
    ...options,
  });
}

/**
 * End a quiz session and get results.
 * Invalidates progress after completion.
 */
export function useEndQuizSession(
  options?: UseMutationOptions<QuizSessionResult, Error, { sessionId: string; abandoned?: boolean }>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ sessionId, abandoned }) => endQuizSession(sessionId, abandoned),
    onSuccess: (result, variables) => {
      // Remove the session from cache
      queryClient.removeQueries({ queryKey: quizKeys.session(variables.sessionId) });
      // Invalidate progress as it has changed
      queryClient.invalidateQueries({ queryKey: quizKeys.progress() });
      // Invalidate history
      queryClient.invalidateQueries({ queryKey: quizKeys.history() });
    },
    ...options,
  });
}

/**
 * Abandon a quiz session.
 */
export function useAbandonQuizSession(
  options?: UseMutationOptions<void, Error, string>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: abandonQuizSession,
    onSuccess: (_, sessionId) => {
      queryClient.removeQueries({ queryKey: quizKeys.session(sessionId) });
      queryClient.invalidateQueries({ queryKey: quizKeys.history() });
    },
    ...options,
  });
}

// =============================================================================
// Flashcard Session Hooks
// =============================================================================

/**
 * Fetch an existing flashcard session.
 */
export function useFlashcardSession(
  sessionId: string | null,
  options?: Omit<UseQueryOptions<FlashcardSession>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.flashcardSession(sessionId!),
    queryFn: () => getFlashcardSession(sessionId!),
    enabled: !!sessionId,
    staleTime: 0,
    ...options,
  });
}

/**
 * Start a new flashcard session.
 */
export function useStartFlashcardSession(
  options?: UseMutationOptions<StartFlashcardResponse, Error, FlashcardConfig>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: startFlashcardSession,
    onSuccess: (data) => {
      queryClient.setQueryData(
        quizKeys.flashcardSession(data.session.id),
        data.session
      );
    },
    ...options,
  });
}

/**
 * Record a flashcard result (got it / study more).
 * Updates spaced repetition data for the instrument.
 */
export function useRecordFlashcardResult(
  options?: UseMutationOptions<FlashcardResultResponse, Error, FlashcardResultSubmission>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: recordFlashcardResult,
    onSuccess: (result, variables) => {
      // Update cached session
      queryClient.setQueryData<FlashcardSession>(
        quizKeys.flashcardSession(variables.session_id),
        (oldSession) => {
          if (!oldSession) return oldSession;
          const isGotIt = variables.result === 'got_it';
          return {
            ...oldSession,
            current_card_index: oldSession.current_card_index + 1,
            cards_completed: oldSession.cards_completed + 1,
            cards_got_it: isGotIt ? oldSession.cards_got_it + 1 : oldSession.cards_got_it,
            cards_study_more: !isGotIt ? oldSession.cards_study_more + 1 : oldSession.cards_study_more,
            results: [
              ...oldSession.results,
              {
                flashcard_id: variables.flashcard_id,
                instrument_id: variables.instrument_id,
                result: variables.result,
                time_spent_seconds: variables.time_spent_seconds,
                recorded_at: new Date().toISOString(),
              },
            ],
          };
        }
      );
      
      // Update instrument progress in cache
      queryClient.setQueryData<InstrumentProgress>(
        quizKeys.instrumentProgress(variables.instrument_id),
        (old) => {
          if (!old) return old;
          return {
            ...old,
            next_review_date: result.next_review_date,
            easiness_factor: result.updated_difficulty,
            last_reviewed_at: new Date().toISOString(),
          };
        }
      );
    },
    ...options,
  });
}

/**
 * End a flashcard session and get summary.
 */
export function useEndFlashcardSession(
  options?: UseMutationOptions<FlashcardSessionResult, Error, { sessionId: string; abandoned?: boolean }>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ sessionId, abandoned }) => endFlashcardSession(sessionId, abandoned),
    onSuccess: (_, variables) => {
      queryClient.removeQueries({ queryKey: quizKeys.flashcardSession(variables.sessionId) });
      queryClient.invalidateQueries({ queryKey: quizKeys.progress() });
    },
    ...options,
  });
}

/**
 * Get a standalone flashcard deck without creating a session.
 */
export function useFlashcardDeck(
  config: FlashcardConfig | null,
  options?: Omit<UseQueryOptions<FlashcardSession>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.flashcardDeck(config!),
    queryFn: () => getFlashcardDeck(config!),
    enabled: !!config,
    staleTime: 0, // Always get fresh deck
    ...options,
  });
}

// =============================================================================
// Quiz History Hooks
// =============================================================================

/**
 * Fetch paginated quiz history.
 */
export function useQuizHistory(
  params: QuizHistoryParams = {},
  options?: Omit<UseQueryOptions<QuizHistoryResponse>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.historyList(params),
    queryFn: () => getQuizHistory(params),
    staleTime: 5 * 60 * 1000,
    ...options,
  });
}

/**
 * Infinite query for paginated quiz history.
 */
export function useQuizHistoryInfinite(
  params: Omit<QuizHistoryParams, 'offset'> = {}
) {
  return useInfiniteQuery({
    queryKey: quizKeys.historyList(params),
    queryFn: ({ pageParam = 0 }) => getQuizHistory({ ...params, offset: pageParam }),
    initialPageParam: 0,
    getNextPageParam: (lastPage) => 
      lastPage.has_more ? lastPage.next_offset : undefined,
    staleTime: 5 * 60 * 1000,
  });
}

/**
 * Fetch detailed results for a specific past session.
 */
export function useQuizSessionDetails(
  sessionId: string | null,
  options?: Omit<UseQueryOptions<QuizSessionResult>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.historyDetail(sessionId!),
    queryFn: () => getQuizSessionDetails(sessionId!),
    enabled: !!sessionId,
    staleTime: Infinity, // Past results never change
    ...options,
  });
}

// =============================================================================
// Bookmark & Reset Hooks
// =============================================================================

/**
 * Toggle bookmark status for an instrument.
 */
export function useToggleInstrumentBookmark(
  options?: UseMutationOptions<InstrumentProgress, Error, { instrumentId: string; bookmarked: boolean }>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: ({ instrumentId, bookmarked }) => 
      toggleInstrumentBookmark(instrumentId, bookmarked),
    onMutate: async ({ instrumentId, bookmarked }) => {
      // Cancel outgoing refetches
      await queryClient.cancelQueries({ 
        queryKey: quizKeys.instrumentProgress(instrumentId) 
      });
      
      // Snapshot previous value
      const previousProgress = queryClient.getQueryData<InstrumentProgress>(
        quizKeys.instrumentProgress(instrumentId)
      );
      
      // Optimistically update
      if (previousProgress) {
        queryClient.setQueryData<InstrumentProgress>(
          quizKeys.instrumentProgress(instrumentId),
          { ...previousProgress, is_bookmarked: bookmarked }
        );
      }
      
      return { previousProgress };
    },
    onError: (_, variables, context) => {
      // Rollback on error
      if (context?.previousProgress) {
        queryClient.setQueryData(
          quizKeys.instrumentProgress(variables.instrumentId),
          context.previousProgress
        );
      }
    },
    onSettled: (_, __, variables) => {
      // Always refetch to sync with server
      queryClient.invalidateQueries({ 
        queryKey: quizKeys.instrumentProgress(variables.instrumentId) 
      });
    },
    ...options,
  });
}

/**
 * Reset progress for a single instrument.
 */
export function useResetInstrumentProgress(
  options?: UseMutationOptions<void, Error, string>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: resetInstrumentProgress,
    onSuccess: (_, instrumentId) => {
      queryClient.invalidateQueries({ 
        queryKey: quizKeys.instrumentProgress(instrumentId) 
      });
      queryClient.invalidateQueries({ queryKey: quizKeys.studyProgress() });
      queryClient.invalidateQueries({ queryKey: quizKeys.dueForReview() });
    },
    ...options,
  });
}

/**
 * Reset all study progress.
 * USE WITH CAUTION - prompts confirmation before executing.
 */
export function useResetAllProgress(
  options?: UseMutationOptions<void, Error, void>
) {
  const queryClient = useQueryClient();
  
  return useMutation({
    mutationFn: resetAllProgress,
    onSuccess: () => {
      // Invalidate all quiz-related queries
      queryClient.invalidateQueries({ queryKey: quizKeys.all });
    },
    ...options,
  });
}

// =============================================================================
// Quiz Limits Hook
// =============================================================================

/**
 * Fetch user's quiz limits and premium status.
 * Used to check if user can start more quizzes.
 */
export function useQuizLimits(
  options?: Omit<UseQueryOptions<QuizLimits>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: quizKeys.limits(),
    queryFn: getQuizLimits,
    staleTime: 60 * 1000, // 1 minute
    ...options,
  });
}

// =============================================================================
// Prefetch Helpers
// =============================================================================

/**
 * Prefetch study progress for immediate display.
 */
export function usePrefetchStudyProgress() {
  const queryClient = useQueryClient();
  
  return () => {
    queryClient.prefetchQuery({
      queryKey: quizKeys.studyProgress(),
      queryFn: getStudyProgress,
      staleTime: 5 * 60 * 1000,
    });
  };
}

/**
 * Prefetch due-for-review items.
 */
export function usePrefetchDueForReview() {
  const queryClient = useQueryClient();
  
  return (params?: DueForReviewParams) => {
    queryClient.prefetchQuery({
      queryKey: quizKeys.dueForReview(params),
      queryFn: () => getDueForReview(params),
      staleTime: 2 * 60 * 1000,
    });
  };
}

// =============================================================================
// Export all hooks
// =============================================================================

export const quizHooks = {
  // Progress
  useStudyProgress,
  useInstrumentProgress,
  useDueForReview,
  useDueForReviewInfinite,
  
  // Quiz sessions
  useQuizSession,
  useStartQuizSession,
  useSubmitQuizAnswer,
  useEndQuizSession,
  useAbandonQuizSession,
  
  // Flashcard sessions
  useFlashcardSession,
  useStartFlashcardSession,
  useRecordFlashcardResult,
  useEndFlashcardSession,
  useFlashcardDeck,
  
  // History
  useQuizHistory,
  useQuizHistoryInfinite,
  useQuizSessionDetails,
  
  // Actions
  useToggleInstrumentBookmark,
  useResetInstrumentProgress,
  useResetAllProgress,
  
  // Limits
  useQuizLimits,
  
  // Prefetch
  usePrefetchStudyProgress,
  usePrefetchDueForReview,
};
