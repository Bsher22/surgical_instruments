# Stage 12: Launch Preparation - Implementation Outline

## Overview

Stage 12 prepares SurgicalPrep for app store submission. This includes creating all store assets, legal documents, setting up monitoring/analytics, configuring production builds, and submitting to both Apple App Store and Google Play Store.

---

## 12A: App Store Assets

### App Identity
- **App Name**: SurgicalPrep - Instrument Study
- **Subtitle** (iOS): Flashcards & Preference Cards
- **Short Description** (Android, 80 chars): Master surgical instruments with flashcards, quizzes & preference cards

### App Icon
- Required: 1024x1024px PNG (no alpha/transparency)
- Generate all sizes using EAS or App Icon Generator
- Design considerations:
  - Simple, recognizable at small sizes
  - Medical/surgical theme (scalpel, instruments, OR colors)
  - Avoid text (illegible at small sizes)

### Screenshots
Required sizes:
- **iOS**:
  - 6.7" (iPhone 15 Pro Max): 1290 x 2796
  - 6.5" (iPhone 14 Plus): 1284 x 2778
  - 5.5" (iPhone 8 Plus): 1242 x 2208
  - iPad Pro 12.9": 2048 x 2732
- **Android**:
  - Phone: 1080 x 1920 (minimum)
  - Tablet 7": 1200 x 1920
  - Tablet 10": 1920 x 1200

Screenshot content (5-8 per platform):
1. Instrument browser with search
2. Instrument detail view
3. Preference card list
4. Preference card detail/editor
5. Flashcard study mode
6. Multiple choice quiz
7. Quiz results/progress stats
8. Profile/subscription screen

### App Store Description

**Full Description** (4000 char max):
```
SurgicalPrep is the ultimate study companion for surgical technologists, OR nurses, and surgical technology students. Master surgical instruments, create preference cards, and track your learning progress with our comprehensive study tools.

📚 INSTRUMENT DATABASE
• Browse 200+ surgical instruments across all specialties
• High-quality images with zoom capability
• Detailed descriptions, uses, and handling notes
• Full-text search and category filtering
• Common procedures and aliases for each instrument

📋 PREFERENCE CARDS
• Create digital preference cards for any procedure
• Add instruments from our database or custom items
• Organize by surgeon, procedure, and specialty
• Attach setup photos for visual reference
• Duplicate and customize existing cards
• Access template cards for common procedures

🧠 STUDY TOOLS
• Flashcard mode with swipe-to-learn interface
• Multiple choice quizzes with instant feedback
• Spaced repetition algorithm for optimal retention
• Track your progress and study streaks
• Review instruments due for practice

✨ PREMIUM FEATURES
• Unlimited preference cards (Free: 5 cards)
• Unlimited daily quizzes (Free: 3/day)
• Access to all instrument details
• Priority support

Perfect for:
• Surgical Technologists preparing for certification
• CST exam preparation
• OR Nurses expanding their knowledge
• Surgical Technology students
• Healthcare professionals in the operating room

Start your surgical prep journey today!

Questions or feedback? Contact us at support@surgicalprep.app
```

### Keywords (iOS, 100 char max)
```
surgical instruments,scrub tech,preference cards,flashcards,CST exam,OR nursing,surgery,medical
```

### Categories
- **Primary**: Medical (iOS) / Medical (Android)
- **Secondary**: Education

---

## 12B: Legal & Compliance

### Privacy Policy
Location: `https://surgicalprep.app/privacy` or `https://yourname.github.io/surgicalprep-legal/privacy`

Required disclosures:
- Data collected (email, name, usage data)
- How data is used
- Third-party services (Supabase, Stripe, analytics)
- Data retention and deletion
- User rights (access, deletion, portability)
- Children's privacy (13+/16+ age restrictions)
- Contact information

### Terms of Service
Location: `https://surgicalprep.app/terms`

Key sections:
- Acceptance of terms
- Account responsibilities
- Subscription and payments
- Intellectual property
- Medical disclaimer (CRITICAL)
- Limitation of liability
- Termination
- Governing law

### Medical Disclaimer (Include in Terms AND in-app)
```
IMPORTANT MEDICAL DISCLAIMER

SurgicalPrep is designed for educational purposes only. This application is not intended to replace:
• Professional medical training
• Institutional protocols and policies
• Manufacturer instructions for use
• Direct supervision by qualified professionals

Always follow your facility's policies and procedures. The information provided in this app should not be used as the sole basis for clinical decision-making.

By using this app, you acknowledge that you understand these limitations and agree to use the information responsibly within the scope of your training and licensure.
```

### EULA (End User License Agreement)
- Apple requires apps with subscriptions to use their standard EULA or provide a custom one
- Can use Apple's standard EULA for simplicity
- Custom EULA should mirror Terms of Service

### Data Safety Form (Google Play)
Required declarations:
- Data collected: Email, name, usage data, photos (user-generated)
- Data shared: Payment processing (Stripe)
- Security practices: Data encrypted in transit
- Data deletion: Users can request account deletion

### App Privacy Details (iOS)
Required declarations:
- Data used to track you: None
- Data linked to you: Contact info (email), Identifiers (user ID)
- Data not linked to you: Usage data, diagnostics

---

## 12C: Monitoring Setup

### Analytics (Firebase Analytics recommended)
Track key events:
- `sign_up` - User registration
- `login` - User login
- `instrument_view` - Instrument detail opened
- `card_create` - Preference card created
- `card_edit` - Preference card edited
- `quiz_start` - Quiz session started
- `quiz_complete` - Quiz session completed
- `flashcard_session` - Flashcard session completed
- `subscription_start` - Premium subscription started
- `subscription_cancel` - Subscription cancelled

User properties:
- `subscription_tier` - "free" or "premium"
- `user_role` - Surgical Tech, OR Nurse, Student, etc.
- `cards_count` - Number of preference cards
- `instruments_studied` - Total instruments studied

### Error Monitoring (Sentry)
Configuration:
- Capture unhandled exceptions
- Capture API errors (4xx, 5xx)
- Include user context (anonymized)
- Source maps for readable stack traces
- Release tracking for version correlation

### Uptime Monitoring (UptimeRobot - Free tier)
Monitors to set up:
- API health endpoint: `https://api.surgicalprep.app/health`
- Frequency: Every 5 minutes
- Alert via email on downtime

### Backend Monitoring
- Railway/Render built-in metrics (CPU, memory, requests)
- Supabase dashboard (database connections, storage usage)
- Stripe dashboard (subscription metrics, failed payments)

---

## 12D: Build & Submission

### EAS Build Configuration
```bash
# Install EAS CLI globally
npm install -g eas-cli

# Login to Expo account
eas login

# Configure builds (creates eas.json)
eas build:configure
```

### Production Build
```bash
# Build for both platforms
eas build --platform all --profile production

# Or build separately
eas build --platform ios --profile production
eas build --platform android --profile production
```

### iOS Submission
1. Build production IPA: `eas build --platform ios --profile production`
2. Submit to App Store Connect: `eas submit --platform ios`
3. In App Store Connect:
   - Create new app
   - Fill in app information
   - Upload screenshots
   - Set pricing (Free with IAP)
   - Configure In-App Purchases
   - Submit for review

### Android Submission
1. Build production AAB: `eas build --platform android --profile production`
2. Submit to Google Play: `eas submit --platform android`
3. In Google Play Console:
   - Create new app
   - Complete store listing
   - Upload screenshots
   - Fill data safety form
   - Set up internal/closed testing first
   - Submit for review

### Common Rejection Reasons & Fixes

**iOS Common Issues**:
- Login required without demo account → Provide test credentials in App Review Information
- Incomplete metadata → Fill all required fields
- Broken links → Verify all URLs work
- Crash on launch → Test on actual devices
- Missing permission descriptions → Add all Info.plist usage descriptions

**Android Common Issues**:
- Data safety form incomplete → Declare all data collection
- Target API level too low → Ensure SDK 34+
- Missing content rating → Complete questionnaire
- Deceptive behavior → Clear subscription terms

---

## File Structure

```
stage-12-launch-prep/
├── STAGE_12_OUTLINE.md
├── config/
│   ├── eas.json                    # EAS Build configuration
│   ├── app.config.ts               # Dynamic Expo config
│   └── app.json.example            # Example app.json with all fields
├── legal/
│   ├── privacy-policy.html         # Privacy Policy page
│   ├── terms-of-service.html       # Terms of Service page
│   ├── medical-disclaimer.html     # Medical disclaimer page
│   └── README.md                   # Hosting instructions
├── store-assets/
│   ├── metadata/
│   │   ├── ios-metadata.json       # iOS App Store metadata
│   │   └── android-metadata.json   # Google Play metadata
│   ├── screenshots/
│   │   └── README.md               # Screenshot requirements
│   └── icon/
│       └── README.md               # Icon requirements
├── monitoring/
│   ├── analytics.ts                # Firebase Analytics setup
│   ├── sentry.ts                   # Sentry error monitoring
│   ├── analyticsEvents.ts          # Event constants and types
│   └── hooks/
│       └── useAnalytics.ts         # Analytics hook
├── scripts/
│   ├── build-production.sh         # Production build script
│   ├── submit-stores.sh            # Store submission script
│   └── pre-submission-checklist.md # Manual checklist
└── components/
    └── MedicalDisclaimer.tsx       # In-app disclaimer component
```

---

## Implementation Order

1. **Legal documents first** (required for submission)
   - Privacy Policy
   - Terms of Service
   - Host on GitHub Pages or your domain

2. **Monitoring setup** (catch issues at launch)
   - Firebase Analytics integration
   - Sentry error tracking
   - Uptime monitoring

3. **Store assets**
   - Finalize app icon
   - Create screenshots
   - Write descriptions

4. **Build configuration**
   - Configure eas.json
   - Test production builds
   - Verify all features work

5. **Submission**
   - iOS first (longer review time)
   - Android second
   - Monitor for feedback

---

## Timeline Estimate

| Task | Time |
|------|------|
| Legal documents | 2-3 hours |
| Analytics setup | 2-3 hours |
| Error monitoring | 1-2 hours |
| Store assets (text) | 2-3 hours |
| Screenshots | 3-4 hours |
| Build config | 1-2 hours |
| Submission | 2-3 hours |
| **Total** | **13-20 hours** |

Plus 1-7 days waiting for app review (iOS typically 1-3 days, Android 1-7 days).

---

## Post-Submission

- Monitor app review status daily
- Respond promptly to any reviewer questions
- Prepare hotfix process for critical issues
- Plan launch marketing activities
- Set up app store review response process
