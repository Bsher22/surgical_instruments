// src/stores/authStore.ts
// Zustand store for authentication state management

import { create } from 'zustand';
import { subscribeWithSelector } from 'zustand/middleware';
import {
  User,
  AuthTokens,
  LoginCredentials,
  SignupData,
} from '../types/auth';
import {
  storeTokens,
  getStoredTokens,
  clearTokens,
  updateAccessToken,
  isTokenExpired,
  getRefreshToken,
} from '../utils/tokenStorage';
import {
  login as apiLogin,
  signup as apiSignup,
  logout as apiLogout,
  refreshAccessToken as apiRefreshToken,
  getCurrentUser,
  AuthApiError,
} from '../api/auth';

interface AuthState {
  // State
  user: User | null;
  tokens: AuthTokens | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isInitialized: boolean;
  error: string | null;

  // Actions
  initialize: () => Promise<void>;
  login: (credentials: LoginCredentials) => Promise<void>;
  signup: (data: SignupData) => Promise<void>;
  logout: () => Promise<void>;
  refreshToken: () => Promise<boolean>;
  updateUser: (user: Partial<User>) => void;
  clearError: () => void;
  setError: (error: string) => void;
}

export const useAuthStore = create<AuthState>()(
  subscribeWithSelector((set, get) => ({
    // Initial state
    user: null,
    tokens: null,
    isAuthenticated: false,
    isLoading: false,
    isInitialized: false,
    error: null,

    /**
     * Initialize auth state on app start
     * Checks for stored tokens and validates them
     */
    initialize: async () => {
      // Prevent multiple initializations
      if (get().isInitialized || get().isLoading) {
        return;
      }

      set({ isLoading: true, error: null });

      try {
        // Check for stored tokens
        const storedTokens = await getStoredTokens();

        if (!storedTokens) {
          // No stored tokens - user needs to log in
          set({
            isInitialized: true,
            isLoading: false,
            isAuthenticated: false,
          });
          return;
        }

        // Check if token is expired
        const expired = await isTokenExpired();

        if (expired) {
          // Try to refresh the token
          const refreshed = await get().refreshToken();

          if (!refreshed) {
            // Refresh failed - user needs to log in again
            await clearTokens();
            set({
              isInitialized: true,
              isLoading: false,
              isAuthenticated: false,
              user: null,
              tokens: null,
            });
            return;
          }
        } else {
          // Token is still valid - set it in state
          set({ tokens: storedTokens });
        }

        // Fetch current user profile
        const currentTokens = get().tokens || storedTokens;
        const user = await getCurrentUser(currentTokens.access_token);

        set({
          user,
          isAuthenticated: true,
          isInitialized: true,
          isLoading: false,
        });
      } catch (error) {
        console.error('Auth initialization failed:', error);

        // Clear invalid tokens
        await clearTokens();

        set({
          user: null,
          tokens: null,
          isAuthenticated: false,
          isInitialized: true,
          isLoading: false,
          error: error instanceof Error ? error.message : 'Authentication failed',
        });
      }
    },

    /**
     * Login with email and password
     */
    login: async (credentials: LoginCredentials) => {
      set({ isLoading: true, error: null });

      try {
        const response = await apiLogin(credentials);

        // Store tokens securely
        await storeTokens(response.tokens);

        set({
          user: response.user,
          tokens: response.tokens,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });
      } catch (error) {
        const errorMessage =
          error instanceof AuthApiError
            ? error.message
            : 'Login failed. Please try again.';

        set({
          isLoading: false,
          error: errorMessage,
        });

        throw error;
      }
    },

    /**
     * Register a new user
     */
    signup: async (data: SignupData) => {
      set({ isLoading: true, error: null });

      try {
        const response = await apiSignup(data);

        // Store tokens securely
        await storeTokens(response.tokens);

        set({
          user: response.user,
          tokens: response.tokens,
          isAuthenticated: true,
          isLoading: false,
          error: null,
        });
      } catch (error) {
        const errorMessage =
          error instanceof AuthApiError
            ? error.message
            : 'Registration failed. Please try again.';

        set({
          isLoading: false,
          error: errorMessage,
        });

        throw error;
      }
    },

    /**
     * Logout and clear all auth state
     */
    logout: async () => {
      const { tokens } = get();

      set({ isLoading: true });

      try {
        // Notify server (best effort)
        if (tokens?.access_token) {
          await apiLogout(tokens.access_token);
        }
      } catch (error) {
        console.warn('Server logout failed:', error);
      } finally {
        // Always clear local state
        await clearTokens();

        set({
          user: null,
          tokens: null,
          isAuthenticated: false,
          isLoading: false,
          error: null,
        });
      }
    },

    /**
     * Refresh the access token
     * Returns true if refresh was successful
     */
    refreshToken: async () => {
      try {
        const refreshToken = await getRefreshToken();

        if (!refreshToken) {
          return false;
        }

        const response = await apiRefreshToken(refreshToken);

        // Update stored access token
        await updateAccessToken(response.access_token, response.expires_in);

        // Update state with new access token
        set((state) => ({
          tokens: state.tokens
            ? {
                ...state.tokens,
                access_token: response.access_token,
                expires_in: response.expires_in,
              }
            : null,
        }));

        return true;
      } catch (error) {
        console.error('Token refresh failed:', error);

        // If refresh fails with 401, clear auth state
        if (error instanceof AuthApiError && error.statusCode === 401) {
          await clearTokens();
          set({
            user: null,
            tokens: null,
            isAuthenticated: false,
            error: 'Session expired. Please log in again.',
          });
        }

        return false;
      }
    },

    /**
     * Update user profile in state
     */
    updateUser: (userData: Partial<User>) => {
      set((state) => ({
        user: state.user ? { ...state.user, ...userData } : null,
      }));
    },

    /**
     * Clear any auth error
     */
    clearError: () => {
      set({ error: null });
    },

    /**
     * Set an auth error
     */
    setError: (error: string) => {
      set({ error });
    },
  }))
);

/**
 * Selector hooks for common state slices
 */
export const useIsAuthenticated = () =>
  useAuthStore((state) => state.isAuthenticated);

export const useUser = () => useAuthStore((state) => state.user);

export const useAuthLoading = () => useAuthStore((state) => state.isLoading);

export const useAuthError = () => useAuthStore((state) => state.error);

export const useAuthInitialized = () =>
  useAuthStore((state) => state.isInitialized);

/**
 * Get access token for API requests (non-reactive)
 */
export const getAccessToken = () => useAuthStore.getState().tokens?.access_token;

/**
 * Check if user has premium subscription
 */
export const useIsPremium = () =>
  useAuthStore(
    (state) =>
      state.user?.subscription_tier === 'premium' &&
      (!state.user.subscription_expires_at ||
        new Date(state.user.subscription_expires_at) > new Date())
  );
