# Stage 10 Dependencies

## New Dependencies to Install

Run the following commands to install dependencies required for Stage 10:

```bash
# Performance - Optimized image loading
npx expo install expo-image

# Haptic feedback
npx expo install expo-haptics

# Network status detection
npx expo install @react-native-community/netinfo

# Animations (if not already installed)
npx expo install react-native-reanimated

# Gesture handling (if not already installed)
npx expo install react-native-gesture-handler

# Linear gradient for skeleton shimmer
npx expo install expo-linear-gradient

# Safe area context (if not already installed)
npx expo install react-native-safe-area-context

# Splash screen control
npx expo install expo-splash-screen
```

## Full Installation Command

```bash
npx expo install expo-image expo-haptics @react-native-community/netinfo react-native-reanimated react-native-gesture-handler expo-linear-gradient react-native-safe-area-context expo-splash-screen
```

## Babel Configuration

Ensure `react-native-reanimated` plugin is in your `babel.config.js`:

```javascript
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      'react-native-reanimated/plugin', // Must be last
    ],
  };
};
```

## Package Versions Reference

These are the recommended versions (check for latest):

```json
{
  "dependencies": {
    "expo-image": "~1.12.0",
    "expo-haptics": "~13.0.0",
    "@react-native-community/netinfo": "11.3.0",
    "react-native-reanimated": "~3.10.0",
    "react-native-gesture-handler": "~2.16.0",
    "expo-linear-gradient": "~13.0.0",
    "react-native-safe-area-context": "4.10.0",
    "expo-splash-screen": "~0.27.0"
  }
}
```

## Existing Dependencies Used

These should already be installed from previous stages:

- `@tanstack/react-query` - Data fetching and caching
- `zustand` - State management
- `axios` - HTTP client
- `expo-router` - Navigation
- `expo-secure-store` - Secure storage
- `@expo/vector-icons` - Icons

## Notes

1. After installing `react-native-reanimated`, you may need to clear the bundler cache:
   ```bash
   npx expo start --clear
   ```

2. On iOS, you may need to run `pod install` in the `ios` directory if using bare workflow.

3. For Android, the gesture handler requires additional setup in `MainActivity.java` if using bare workflow (not needed with Expo Go).
