/**
 * React Query Hooks for Preference Cards
 * 
 * Provides data fetching, caching, and mutation hooks for:
 * - useCards - Paginated list with search/filter
 * - useCard - Single card with details
 * - useTemplates - Public template cards
 * - useCreateCard, useUpdateCard, useDeleteCard - Mutations
 * - useCardLimit - Check free tier limits
 */

import {
  useQuery,
  useMutation,
  useQueryClient,
  useInfiniteQuery,
  UseQueryOptions,
  UseMutationOptions,
} from '@tanstack/react-query';

import * as cardsApi from '../api/cards';
import type {
  PreferenceCard,
  PreferenceCardCreate,
  PreferenceCardUpdate,
  CardWithDetails,
  GetCardsParams,
  PaginatedCardsResponse,
  CardPhotoCreate,
  CardPhoto,
  Specialty,
} from '../types/cards';

// ============================================================================
// Query Keys Factory
// ============================================================================

export const cardKeys = {
  all: ['cards'] as const,
  lists: () => [...cardKeys.all, 'list'] as const,
  list: (params: GetCardsParams) => [...cardKeys.lists(), params] as const,
  details: () => [...cardKeys.all, 'detail'] as const,
  detail: (id: string) => [...cardKeys.details(), id] as const,
  templates: () => [...cardKeys.all, 'templates'] as const,
  templatesBySpecialty: (specialty?: string) => 
    [...cardKeys.templates(), specialty] as const,
  limit: () => [...cardKeys.all, 'limit'] as const,
  count: () => [...cardKeys.all, 'count'] as const,
  search: (query: string) => [...cardKeys.all, 'search', query] as const,
};

// ============================================================================
// Read Hooks
// ============================================================================

/**
 * Fetch paginated list of user's preference cards
 * Supports search, filtering, and sorting
 */
export function useCards(
  params: GetCardsParams = {},
  options?: Omit<UseQueryOptions<PaginatedCardsResponse>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: cardKeys.list(params),
    queryFn: () => cardsApi.getCards(params),
    staleTime: 1000 * 60 * 2, // 2 minutes
    ...options,
  });
}

/**
 * Infinite scroll version of useCards
 * Automatically handles pagination
 */
export function useInfiniteCards(
  params: Omit<GetCardsParams, 'page'> = {}
) {
  return useInfiniteQuery({
    queryKey: cardKeys.list({ ...params, infinite: true } as GetCardsParams),
    queryFn: ({ pageParam = 1 }) => 
      cardsApi.getCards({ ...params, page: pageParam }),
    getNextPageParam: (lastPage) =>
      lastPage.has_next ? lastPage.page + 1 : undefined,
    getPreviousPageParam: (firstPage) =>
      firstPage.has_prev ? firstPage.page - 1 : undefined,
    initialPageParam: 1,
    staleTime: 1000 * 60 * 2,
  });
}

/**
 * Fetch a single preference card with all details
 */
export function useCard(
  cardId: string,
  options?: Omit<UseQueryOptions<CardWithDetails>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: cardKeys.detail(cardId),
    queryFn: () => cardsApi.getCard(cardId),
    enabled: !!cardId,
    staleTime: 1000 * 60 * 5, // 5 minutes
    ...options,
  });
}

/**
 * Fetch public template cards
 * Optionally filter by specialty
 */
export function useTemplates(
  specialty?: Specialty,
  options?: Omit<UseQueryOptions<PreferenceCard[]>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: cardKeys.templatesBySpecialty(specialty),
    queryFn: () => cardsApi.getTemplates(specialty),
    staleTime: 1000 * 60 * 30, // 30 minutes (templates don't change often)
    ...options,
  });
}

/**
 * Search cards by query
 */
export function useSearchCards(
  query: string,
  options?: Omit<UseQueryOptions<PreferenceCard[]>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: cardKeys.search(query),
    queryFn: () => cardsApi.searchCards(query),
    enabled: query.length >= 2,
    staleTime: 1000 * 60,
    ...options,
  });
}

/**
 * Check if user can create more cards (free tier limit)
 */
export function useCardLimit(
  options?: Omit<
    UseQueryOptions<{ canCreate: boolean; current: number; limit: number }>,
    'queryKey' | 'queryFn'
  >
) {
  return useQuery({
    queryKey: cardKeys.limit(),
    queryFn: () => cardsApi.checkCardLimit(),
    staleTime: 1000 * 60 * 5,
    ...options,
  });
}

/**
 * Get user's total card count
 */
export function useCardCount(
  options?: Omit<UseQueryOptions<number>, 'queryKey' | 'queryFn'>
) {
  return useQuery({
    queryKey: cardKeys.count(),
    queryFn: () => cardsApi.getCardCount(),
    staleTime: 1000 * 60,
    ...options,
  });
}

// ============================================================================
// Mutation Hooks
// ============================================================================

/**
 * Create a new preference card
 */
export function useCreateCard(
  options?: UseMutationOptions<CardWithDetails, Error, PreferenceCardCreate>
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: cardsApi.createCard,
    onSuccess: (newCard) => {
      // Add to cache
      queryClient.setQueryData(cardKeys.detail(newCard.id), newCard);
      // Invalidate lists to refetch
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
      queryClient.invalidateQueries({ queryKey: cardKeys.count() });
      queryClient.invalidateQueries({ queryKey: cardKeys.limit() });
    },
    ...options,
  });
}

/**
 * Update an existing preference card
 */
export function useUpdateCard(
  options?: UseMutationOptions<
    CardWithDetails,
    Error,
    { cardId: string; data: PreferenceCardUpdate }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, data }) => cardsApi.updateCard(cardId, data),
    onSuccess: (updatedCard) => {
      // Update cache
      queryClient.setQueryData(cardKeys.detail(updatedCard.id), updatedCard);
      // Invalidate lists
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
    },
    ...options,
  });
}

/**
 * Delete a preference card
 */
export function useDeleteCard(
  options?: UseMutationOptions<void, Error, string>
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: cardsApi.deleteCard,
    onSuccess: (_, cardId) => {
      // Remove from cache
      queryClient.removeQueries({ queryKey: cardKeys.detail(cardId) });
      // Invalidate lists
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
      queryClient.invalidateQueries({ queryKey: cardKeys.count() });
      queryClient.invalidateQueries({ queryKey: cardKeys.limit() });
    },
    ...options,
  });
}

/**
 * Duplicate an existing card
 */
export function useDuplicateCard(
  options?: UseMutationOptions<CardWithDetails, Error, string>
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: cardsApi.duplicateCard,
    onSuccess: (newCard) => {
      // Add to cache
      queryClient.setQueryData(cardKeys.detail(newCard.id), newCard);
      // Invalidate lists
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
      queryClient.invalidateQueries({ queryKey: cardKeys.count() });
      queryClient.invalidateQueries({ queryKey: cardKeys.limit() });
    },
    ...options,
  });
}

// ============================================================================
// Card Item Mutation Hooks
// ============================================================================

/**
 * Add an item to a card
 */
export function useAddCardItem(
  options?: UseMutationOptions<
    CardWithDetails,
    Error,
    {
      cardId: string;
      item: {
        name: string;
        quantity: number;
        size?: string;
        notes?: string;
        category: string;
        instrument_id?: string;
      };
    }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, item }) => cardsApi.addCardItem(cardId, item),
    onSuccess: (updatedCard) => {
      queryClient.setQueryData(cardKeys.detail(updatedCard.id), updatedCard);
    },
    ...options,
  });
}

/**
 * Update an item on a card
 */
export function useUpdateCardItem(
  options?: UseMutationOptions<
    CardWithDetails,
    Error,
    {
      cardId: string;
      itemId: string;
      data: {
        quantity?: number;
        size?: string;
        notes?: string;
        category?: string;
        sort_order?: number;
      };
    }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, itemId, data }) =>
      cardsApi.updateCardItem(cardId, itemId, data),
    onSuccess: (updatedCard) => {
      queryClient.setQueryData(cardKeys.detail(updatedCard.id), updatedCard);
    },
    ...options,
  });
}

/**
 * Remove an item from a card
 */
export function useRemoveCardItem(
  options?: UseMutationOptions<void, Error, { cardId: string; itemId: string }>
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, itemId }) => cardsApi.removeCardItem(cardId, itemId),
    onSuccess: (_, { cardId }) => {
      // Invalidate the card detail to refetch
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
    ...options,
  });
}

/**
 * Reorder items on a card
 */
export function useReorderCardItems(
  options?: UseMutationOptions<
    CardWithDetails,
    Error,
    { cardId: string; itemIds: string[] }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, itemIds }) =>
      cardsApi.reorderCardItems(cardId, itemIds),
    onSuccess: (updatedCard) => {
      queryClient.setQueryData(cardKeys.detail(updatedCard.id), updatedCard);
    },
    ...options,
  });
}

// ============================================================================
// Card Photo Mutation Hooks
// ============================================================================

/**
 * Add a photo to a card
 */
export function useAddCardPhoto(
  options?: UseMutationOptions<
    CardPhoto,
    Error,
    { cardId: string; photo: CardPhotoCreate }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, photo }) => cardsApi.addCardPhoto(cardId, photo),
    onSuccess: (_, { cardId }) => {
      // Invalidate card detail to refetch with new photo
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
    ...options,
  });
}

/**
 * Update a photo's caption or order
 */
export function useUpdateCardPhoto(
  options?: UseMutationOptions<
    CardPhoto,
    Error,
    {
      cardId: string;
      photoId: string;
      data: { caption?: string; sort_order?: number };
    }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, photoId, data }) =>
      cardsApi.updateCardPhoto(cardId, photoId, data),
    onSuccess: (_, { cardId }) => {
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
    ...options,
  });
}

/**
 * Delete a photo from a card
 */
export function useDeleteCardPhoto(
  options?: UseMutationOptions<
    void,
    Error,
    { cardId: string; photoId: string }
  >
) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ cardId, photoId }) =>
      cardsApi.deleteCardPhoto(cardId, photoId),
    onSuccess: (_, { cardId }) => {
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
    ...options,
  });
}

// ============================================================================
// Prefetching Utilities
// ============================================================================

/**
 * Prefetch a card detail (for hover/focus states)
 */
export function usePrefetchCard() {
  const queryClient = useQueryClient();

  return (cardId: string) => {
    queryClient.prefetchQuery({
      queryKey: cardKeys.detail(cardId),
      queryFn: () => cardsApi.getCard(cardId),
      staleTime: 1000 * 60 * 5,
    });
  };
}

/**
 * Prefetch templates
 */
export function usePrefetchTemplates() {
  const queryClient = useQueryClient();

  return (specialty?: Specialty) => {
    queryClient.prefetchQuery({
      queryKey: cardKeys.templatesBySpecialty(specialty),
      queryFn: () => cardsApi.getTemplates(specialty),
      staleTime: 1000 * 60 * 30,
    });
  };
}
