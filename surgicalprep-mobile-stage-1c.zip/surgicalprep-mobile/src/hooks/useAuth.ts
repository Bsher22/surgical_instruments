import { useEffect } from 'react';
import { useAuthStore } from '@/stores';

export function useAuth() {
  const store = useAuthStore();

  // Check auth status on mount
  useEffect(() => {
    store.checkAuth();
  }, []);

  return {
    user: store.user,
    isLoading: store.isLoading,
    isAuthenticated: store.isAuthenticated,
    error: store.error,
    login: store.login,
    signup: store.signup,
    logout: store.logout,
    clearError: store.clearError,
    isPremium: store.user?.is_premium ?? false,
  };
}
