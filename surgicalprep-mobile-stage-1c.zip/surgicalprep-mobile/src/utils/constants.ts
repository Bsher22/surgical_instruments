// API Configuration
export const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000';
export const SUPABASE_URL = process.env.EXPO_PUBLIC_SUPABASE_URL || '';
export const SUPABASE_ANON_KEY = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY || '';

// App Configuration
export const APP_NAME = 'SurgicalPrep';
export const APP_VERSION = '1.0.0';

// Feature Limits (Free Tier)
export const FREE_TIER_LIMITS = {
  maxCards: 5,
  dailyQuizzes: 3,
  maxBookmarks: 20,
};

// API Endpoints
export const ENDPOINTS = {
  // Auth
  login: '/auth/login',
  signup: '/auth/signup',
  me: '/auth/me',
  refreshToken: '/auth/refresh',

  // Instruments
  instruments: '/instruments',
  instrumentSearch: '/instruments/search',

  // Preference Cards
  cards: '/cards',
  cardTemplates: '/cards/templates',

  // Quiz
  quizSessions: '/quiz/sessions',
  studyProgress: '/quiz/progress',

  // User
  profile: '/users/me',
  subscription: '/users/subscription',
};

// Categories
export const INSTRUMENT_CATEGORIES = [
  'Cutting & Dissecting',
  'Clamping & Occluding',
  'Grasping & Holding',
  'Retracting & Exposing',
  'Suturing & Stapling',
  'Suctioning',
  'Dilating & Probing',
  'Specialty',
] as const;

export const SURGICAL_SPECIALTIES = [
  'General Surgery',
  'Orthopedic',
  'Cardiovascular',
  'Neurosurgery',
  'OB/GYN',
  'Urology',
  'ENT',
  'Plastic Surgery',
  'Ophthalmology',
  'Other',
] as const;

// Theme Colors
export const COLORS = {
  primary: '#1a5f7a',
  primaryLight: '#2d7d9a',
  primaryDark: '#0d4a5f',
  secondary: '#57c5b6',
  accent: '#159895',
  background: '#f8fafc',
  surface: '#ffffff',
  text: '#1e293b',
  textSecondary: '#64748b',
  border: '#e2e8f0',
  error: '#ef4444',
  success: '#22c55e',
  warning: '#f59e0b',
};
