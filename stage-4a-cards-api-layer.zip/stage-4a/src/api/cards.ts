/**
 * Cards API Client
 * 
 * Handles all preference card API operations including:
 * - Fetching user's cards (paginated, with search/filter)
 * - Fetching single card with full details
 * - Fetching public template cards
 * - CRUD operations (create, update, delete, duplicate)
 * - Photo management
 */

import { apiClient } from './client';
import type {
  PreferenceCard,
  PreferenceCardCreate,
  PreferenceCardUpdate,
  CardWithDetails,
  GetCardsParams,
  PaginatedCardsResponse,
  CardPhoto,
  CardPhotoCreate,
} from '../types/cards';

// ============================================================================
// Cards - Read Operations
// ============================================================================

/**
 * Get paginated list of user's preference cards
 * Supports search, filtering by specialty/surgeon, and sorting
 */
export async function getCards(params: GetCardsParams = {}): Promise<PaginatedCardsResponse> {
  const searchParams = new URLSearchParams();
  
  if (params.search) searchParams.append('search', params.search);
  if (params.specialty) searchParams.append('specialty', params.specialty);
  if (params.surgeon_name) searchParams.append('surgeon_name', params.surgeon_name);
  if (params.is_template !== undefined) searchParams.append('is_template', String(params.is_template));
  if (params.page) searchParams.append('page', String(params.page));
  if (params.limit) searchParams.append('limit', String(params.limit));
  if (params.sort_by) searchParams.append('sort_by', params.sort_by);
  if (params.sort_order) searchParams.append('sort_order', params.sort_order);
  
  const queryString = searchParams.toString();
  const url = queryString ? `/cards?${queryString}` : '/cards';
  
  const response = await apiClient.get<PaginatedCardsResponse>(url);
  return response.data;
}

/**
 * Get a single preference card with all details (items, photos)
 */
export async function getCard(cardId: string): Promise<CardWithDetails> {
  const response = await apiClient.get<CardWithDetails>(`/cards/${cardId}`);
  return response.data;
}

/**
 * Get public template cards for starting points
 * Templates are pre-made cards for common procedures
 */
export async function getTemplates(specialty?: string): Promise<PreferenceCard[]> {
  const params = specialty ? `?specialty=${specialty}` : '';
  const response = await apiClient.get<PreferenceCard[]>(`/cards/templates${params}`);
  return response.data;
}

/**
 * Search cards by procedure, surgeon name, or title
 * Returns a simplified list for quick lookups
 */
export async function searchCards(query: string): Promise<PreferenceCard[]> {
  const response = await apiClient.get<PreferenceCard[]>(
    `/cards/search?q=${encodeURIComponent(query)}`
  );
  return response.data;
}

// ============================================================================
// Cards - Write Operations
// ============================================================================

/**
 * Create a new preference card
 * Can include items in the same request
 */
export async function createCard(data: PreferenceCardCreate): Promise<CardWithDetails> {
  const response = await apiClient.post<CardWithDetails>('/cards', data);
  return response.data;
}

/**
 * Update an existing preference card
 * Supports partial updates - only send fields that changed
 * Items can be updated by including them in the request
 */
export async function updateCard(
  cardId: string,
  data: PreferenceCardUpdate
): Promise<CardWithDetails> {
  const response = await apiClient.put<CardWithDetails>(`/cards/${cardId}`, data);
  return response.data;
}

/**
 * Delete a preference card
 * This also deletes all associated items and photos
 */
export async function deleteCard(cardId: string): Promise<void> {
  await apiClient.delete(`/cards/${cardId}`);
}

/**
 * Duplicate an existing card
 * Creates a copy with "(Copy)" appended to the title
 * Returns the new card with all items duplicated
 */
export async function duplicateCard(cardId: string): Promise<CardWithDetails> {
  const response = await apiClient.post<CardWithDetails>(`/cards/${cardId}/duplicate`);
  return response.data;
}

// ============================================================================
// Card Items Operations
// ============================================================================

/**
 * Add an item to a card (from instruments database or custom)
 */
export async function addCardItem(
  cardId: string,
  item: {
    name: string;
    quantity: number;
    size?: string;
    notes?: string;
    category: string;
    instrument_id?: string;
  }
): Promise<CardWithDetails> {
  const response = await apiClient.post<CardWithDetails>(
    `/cards/${cardId}/items`,
    item
  );
  return response.data;
}

/**
 * Update an item on a card
 */
export async function updateCardItem(
  cardId: string,
  itemId: string,
  data: {
    quantity?: number;
    size?: string;
    notes?: string;
    category?: string;
    sort_order?: number;
  }
): Promise<CardWithDetails> {
  const response = await apiClient.put<CardWithDetails>(
    `/cards/${cardId}/items/${itemId}`,
    data
  );
  return response.data;
}

/**
 * Remove an item from a card
 */
export async function removeCardItem(cardId: string, itemId: string): Promise<void> {
  await apiClient.delete(`/cards/${cardId}/items/${itemId}`);
}

/**
 * Reorder items on a card
 * Accepts array of item IDs in the new order
 */
export async function reorderCardItems(
  cardId: string,
  itemIds: string[]
): Promise<CardWithDetails> {
  const response = await apiClient.put<CardWithDetails>(
    `/cards/${cardId}/items/reorder`,
    { item_ids: itemIds }
  );
  return response.data;
}

// ============================================================================
// Card Photos Operations
// ============================================================================

/**
 * Upload a photo to a card
 * Expects the image_url after uploading to Supabase Storage
 */
export async function addCardPhoto(
  cardId: string,
  photo: CardPhotoCreate
): Promise<CardPhoto> {
  const response = await apiClient.post<CardPhoto>(
    `/cards/${cardId}/photos`,
    photo
  );
  return response.data;
}

/**
 * Update photo caption or order
 */
export async function updateCardPhoto(
  cardId: string,
  photoId: string,
  data: { caption?: string; sort_order?: number }
): Promise<CardPhoto> {
  const response = await apiClient.put<CardPhoto>(
    `/cards/${cardId}/photos/${photoId}`,
    data
  );
  return response.data;
}

/**
 * Delete a photo from a card
 */
export async function deleteCardPhoto(cardId: string, photoId: string): Promise<void> {
  await apiClient.delete(`/cards/${cardId}/photos/${photoId}`);
}

// ============================================================================
// Utility Functions
// ============================================================================

/**
 * Check if user has reached their card limit (free tier)
 * Returns { canCreate: boolean, current: number, limit: number }
 */
export async function checkCardLimit(): Promise<{
  canCreate: boolean;
  current: number;
  limit: number;
}> {
  const response = await apiClient.get<{
    canCreate: boolean;
    current: number;
    limit: number;
  }>('/cards/limit');
  return response.data;
}

/**
 * Get card count for current user
 */
export async function getCardCount(): Promise<number> {
  const response = await apiClient.get<{ count: number }>('/cards/count');
  return response.data.count;
}
