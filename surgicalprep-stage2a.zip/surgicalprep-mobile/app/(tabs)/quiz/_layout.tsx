import { Stack } from 'expo-router';

export default function QuizLayout() {
  return (
    <Stack screenOptions={{ headerShown: false }}>
      <Stack.Screen name="index" />
      <Stack.Screen 
        name="flashcards" 
        options={{ 
          headerShown: true,
          headerTitle: 'Flashcards',
          headerBackTitle: 'Back',
          presentation: 'modal',
        }} 
      />
      <Stack.Screen 
        name="session" 
        options={{ 
          headerShown: true,
          headerTitle: 'Quiz',
          headerBackTitle: 'Exit',
          presentation: 'fullScreenModal',
        }} 
      />
    </Stack>
  );
}
