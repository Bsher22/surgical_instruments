// src/components/EmptyState.tsx
import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons';

type IconName = keyof typeof Ionicons.glyphMap;

interface EmptyStateProps {
  icon?: IconName;
  title: string;
  subtitle?: string;
  actionLabel?: string;
  onAction?: () => void;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  icon = 'search-outline',
  title,
  subtitle,
  actionLabel,
  onAction,
}) => {
  return (
    <View style={styles.container}>
      <View style={styles.iconContainer}>
        <Ionicons name={icon} size={48} color="#9CA3AF" />
      </View>
      
      <Text style={styles.title}>{title}</Text>
      
      {subtitle && <Text style={styles.subtitle}>{subtitle}</Text>}
      
      {actionLabel && onAction && (
        <TouchableOpacity style={styles.button} onPress={onAction}>
          <Text style={styles.buttonText}>{actionLabel}</Text>
        </TouchableOpacity>
      )}
    </View>
  );
};

// Pre-configured variants for common use cases
export const NoSearchResults: React.FC<{ onClear?: () => void }> = ({
  onClear,
}) => (
  <EmptyState
    icon="search-outline"
    title="No instruments found"
    subtitle="Try adjusting your search or filters"
    actionLabel={onClear ? 'Clear filters' : undefined}
    onAction={onClear}
  />
);

export const NoInstruments: React.FC = () => (
  <EmptyState
    icon="medical-outline"
    title="No instruments yet"
    subtitle="Instruments will appear here once added to the database"
  />
);

export const NetworkError: React.FC<{ onRetry?: () => void }> = ({
  onRetry,
}) => (
  <EmptyState
    icon="cloud-offline-outline"
    title="Connection issue"
    subtitle="Unable to load instruments. Please check your connection."
    actionLabel={onRetry ? 'Try again' : undefined}
    onAction={onRetry}
  />
);

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 32,
    paddingVertical: 48,
  },
  iconContainer: {
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 16,
  },
  title: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1F2937',
    textAlign: 'center',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 14,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 20,
    marginBottom: 24,
  },
  button: {
    backgroundColor: '#2563EB',
    paddingHorizontal: 24,
    paddingVertical: 12,
    borderRadius: 8,
  },
  buttonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#FFFFFF',
  },
});

export default EmptyState;
