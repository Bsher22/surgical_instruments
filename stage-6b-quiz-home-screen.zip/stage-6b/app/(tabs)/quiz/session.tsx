// ============================================================================
// Quiz Session Screen (Placeholder - Full implementation in Stage 6D)
// ============================================================================

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity, Alert } from 'react-native';
import { useRouter, useLocalSearchParams } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { colors, spacing, typography } from '../../../src/utils/theme';

/**
 * Quiz Session Screen
 * 
 * This is a placeholder screen. Full implementation will include:
 * - Multiple choice questions
 * - Timer functionality
 * - Progress bar
 * - Answer feedback
 * - Question navigation
 * 
 * See Stage 6D for full implementation details.
 */
export default function QuizSessionScreen() {
  const router = useRouter();
  const { sessionId } = useLocalSearchParams<{ sessionId: string }>();

  const handleClose = () => {
    Alert.alert(
      'Quit Quiz?',
      'Your progress will be saved but the quiz will be marked as abandoned.',
      [
        { text: 'Continue Quiz', style: 'cancel' },
        { 
          text: 'Quit', 
          style: 'destructive',
          onPress: () => router.back(),
        },
      ]
    );
  };

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={handleClose}
        >
          <Ionicons name="close" size={28} color={colors.text} />
        </TouchableOpacity>
        <View style={styles.progressContainer}>
          <View style={styles.progressBar}>
            <View style={[styles.progressFill, { width: '30%' }]} />
          </View>
          <Text style={styles.progressText}>3/10</Text>
        </View>
        <View style={styles.placeholder} />
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Ionicons name="clipboard-outline" size={80} color={colors.textTertiary} />
        <Text style={styles.placeholderTitle}>Quiz Mode</Text>
        <Text style={styles.placeholderText}>
          Session ID: {sessionId || 'N/A'}
        </Text>
        <Text style={styles.placeholderSubtext}>
          Full implementation coming in Stage 6D
        </Text>
        <Text style={styles.placeholderFeatures}>
          Features will include:{'\n'}
          • Multiple choice questions{'\n'}
          • Optional timer per question{'\n'}
          • Immediate answer feedback{'\n'}
          • Progress tracking{'\n'}
          • Results summary
        </Text>
      </View>

      {/* Mock Answer Buttons */}
      <View style={styles.mockAnswers}>
        <View style={styles.mockAnswer}>
          <Text style={styles.mockAnswerText}>A. Kelly Hemostats</Text>
        </View>
        <View style={styles.mockAnswer}>
          <Text style={styles.mockAnswerText}>B. Mosquito Clamp</Text>
        </View>
        <View style={styles.mockAnswer}>
          <Text style={styles.mockAnswerText}>C. Allis Clamp</Text>
        </View>
        <View style={styles.mockAnswer}>
          <Text style={styles.mockAnswerText}>D. Kocher Clamp</Text>
        </View>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  closeButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  progressContainer: {
    flex: 1,
    alignItems: 'center',
    paddingHorizontal: spacing.lg,
  },
  progressBar: {
    width: '100%',
    height: 8,
    backgroundColor: colors.border,
    borderRadius: 4,
    overflow: 'hidden',
  },
  progressFill: {
    height: '100%',
    backgroundColor: colors.primary,
    borderRadius: 4,
  },
  progressText: {
    fontSize: typography.sizes.xs,
    color: colors.textSecondary,
    marginTop: 4,
  },
  placeholder: {
    width: 44,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    gap: spacing.sm,
  },
  placeholderTitle: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginTop: spacing.md,
  },
  placeholderText: {
    fontSize: typography.sizes.sm,
    color: colors.primary,
    fontFamily: 'monospace',
  },
  placeholderSubtext: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  placeholderFeatures: {
    fontSize: typography.sizes.sm,
    color: colors.textTertiary,
    textAlign: 'center',
    lineHeight: 24,
    marginTop: spacing.md,
  },
  mockAnswers: {
    padding: spacing.md,
    gap: spacing.sm,
  },
  mockAnswer: {
    backgroundColor: colors.surface,
    padding: spacing.md,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: colors.border,
  },
  mockAnswerText: {
    fontSize: typography.sizes.md,
    color: colors.text,
  },
});
