import Constants from 'expo-constants';

// API Configuration
export const API_URL = Constants.expoConfig?.extra?.apiUrl 
  || process.env.EXPO_PUBLIC_API_URL 
  || 'http://localhost:8000';

// App Configuration
export const APP_NAME = 'SurgicalPrep';
export const APP_VERSION = Constants.expoConfig?.version || '1.0.0';

// Feature Limits (Free Tier)
export const FREE_TIER_LIMITS = {
  maxCards: 5,
  dailyQuizzes: 3,
  maxBookmarks: 20,
};

// Premium Tier (unlimited)
export const PREMIUM_TIER = {
  maxCards: Infinity,
  dailyQuizzes: Infinity,
  maxBookmarks: Infinity,
};

// Instrument Categories
export const INSTRUMENT_CATEGORIES = [
  { id: 'cutting', label: 'Cutting & Dissecting', icon: 'cut-outline' },
  { id: 'grasping', label: 'Grasping & Holding', icon: 'hand-left-outline' },
  { id: 'clamping', label: 'Clamping & Occluding', icon: 'lock-closed-outline' },
  { id: 'retracting', label: 'Retracting', icon: 'expand-outline' },
  { id: 'suturing', label: 'Suturing', icon: 'git-merge-outline' },
  { id: 'specialty', label: 'Specialty', icon: 'star-outline' },
  { id: 'other', label: 'Other', icon: 'ellipsis-horizontal-outline' },
] as const;

// Specialties
export const SPECIALTIES = [
  'General Surgery',
  'Orthopedic',
  'OB/GYN',
  'Neurosurgery',
  'Cardiovascular',
  'Plastic Surgery',
  'Urology',
  'ENT',
  'Ophthalmology',
  'Pediatric',
  'Trauma',
  'Transplant',
  'Other',
] as const;

// User Roles
export const USER_ROLES = [
  { value: 'surgical_tech', label: 'Surgical Technologist' },
  { value: 'student', label: 'Surgical Tech Student' },
  { value: 'or_nurse', label: 'OR Nurse' },
  { value: 'circulator', label: 'Circulating Nurse' },
  { value: 'surgeon', label: 'Surgeon' },
  { value: 'resident', label: 'Surgical Resident' },
  { value: 'educator', label: 'Educator/Instructor' },
  { value: 'other', label: 'Other' },
] as const;

// Quiz Configuration
export const QUIZ_CONFIG = {
  defaultQuestionCount: 10,
  questionTypes: ['image_to_name', 'name_to_use', 'image_to_category'],
  timerSeconds: 30,
};

// Theme Colors
export const COLORS = {
  primary: '#2563eb',
  primaryDark: '#1d4ed8',
  secondary: '#64748b',
  success: '#22c55e',
  warning: '#f59e0b',
  error: '#dc2626',
  background: '#f9fafb',
  surface: '#ffffff',
  text: '#1a1a2e',
  textSecondary: '#666666',
  border: '#e5e5e5',
};

// Spacing
export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

// Debounce timing
export const DEBOUNCE_MS = 300;
