import { useQuery, useMutation, useQueryClient, useInfiniteQuery } from '@tanstack/react-query';
import { cardsApi } from '@/api';
import { CreateCardRequest, UpdateCardRequest, AddItemRequest } from '@/types';

// Query keys
export const cardKeys = {
  all: ['cards'] as const,
  lists: () => [...cardKeys.all, 'list'] as const,
  list: (search?: string) => [...cardKeys.lists(), search] as const,
  details: () => [...cardKeys.all, 'detail'] as const,
  detail: (id: string) => [...cardKeys.details(), id] as const,
  templates: () => [...cardKeys.all, 'templates'] as const,
};

// Fetch user's cards with infinite scroll
export function useCards(search?: string) {
  return useInfiniteQuery({
    queryKey: cardKeys.list(search),
    queryFn: ({ pageParam = 1 }) =>
      cardsApi.getCards({
        page: pageParam,
        limit: 20,
        search,
      }),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => {
      if (lastPage.page < lastPage.pages) {
        return lastPage.page + 1;
      }
      return undefined;
    },
  });
}

// Fetch single card
export function useCard(id: string) {
  return useQuery({
    queryKey: cardKeys.detail(id),
    queryFn: () => cardsApi.getCard(id),
    enabled: !!id,
  });
}

// Fetch templates
export function useCardTemplates() {
  return useQuery({
    queryKey: cardKeys.templates(),
    queryFn: () => cardsApi.getTemplates(),
    staleTime: 1000 * 60 * 10, // 10 minutes
  });
}

// Create card mutation
export function useCreateCard() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: CreateCardRequest) => cardsApi.createCard(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
    },
  });
}

// Update card mutation
export function useUpdateCard(id: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: UpdateCardRequest) => cardsApi.updateCard(id, data),
    onSuccess: (updatedCard) => {
      queryClient.setQueryData(cardKeys.detail(id), updatedCard);
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
    },
  });
}

// Delete card mutation
export function useDeleteCard() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => cardsApi.deleteCard(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
    },
  });
}

// Duplicate card mutation
export function useDuplicateCard() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id: string) => cardsApi.duplicateCard(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: cardKeys.lists() });
    },
  });
}

// Add item to card
export function useAddCardItem(cardId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (data: AddItemRequest) => cardsApi.addItem(cardId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
  });
}

// Update card item
export function useUpdateCardItem(cardId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ itemId, data }: { itemId: string; data: Partial<AddItemRequest> }) =>
      cardsApi.updateItem(cardId, itemId, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
  });
}

// Delete card item
export function useDeleteCardItem(cardId: string) {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (itemId: string) => cardsApi.deleteItem(cardId, itemId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: cardKeys.detail(cardId) });
    },
  });
}
