# SurgicalPrep Mobile App

A React Native (Expo) mobile application for surgical technicians to study surgical instruments and manage preference cards.

## Stage 1C: Local Development Environment

This is the foundation setup for the mobile app including:

- ✅ Expo project with TypeScript template
- ✅ Core dependencies installed (expo-router, react-query, zustand, expo-secure-store)
- ✅ Project structure with routing
- ✅ API client with auth token management
- ✅ Zustand stores for state management
- ✅ React Query hooks for data fetching
- ✅ Reusable UI components
- ✅ Authentication flow (login/signup)
- ✅ Tab navigation placeholder screens

## Prerequisites

- Node.js 18+ 
- npm or yarn
- Expo CLI: `npm install -g expo-cli`
- EAS CLI (for builds): `npm install -g eas-cli`
- iOS Simulator (Mac) or Android Studio emulator
- Expo Go app on your physical device

## Getting Started

### 1. Install Dependencies

```bash
cd surgicalprep-mobile
npm install
```

### 2. Configure Environment

Copy the example environment file and fill in your values:

```bash
cp .env.example .env.local
```

Edit `.env.local` with your API URL:

```
EXPO_PUBLIC_API_URL=http://localhost:8000
EXPO_PUBLIC_SUPABASE_URL=https://your-project.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Start the Development Server

```bash
npx expo start
```

Then:
- Press `i` to open iOS Simulator
- Press `a` to open Android Emulator
- Scan QR code with Expo Go app on your phone

## Project Structure

```
surgicalprep-mobile/
├── app/                      # Expo Router (file-based routing)
│   ├── (auth)/               # Auth screens (login, signup)
│   ├── (tabs)/               # Main app tabs
│   │   ├── instruments/      # Instruments browsing
│   │   ├── cards/            # Preference cards
│   │   ├── quiz/             # Study & quiz
│   │   └── profile/          # User profile
│   ├── _layout.tsx           # Root layout with providers
│   └── index.tsx             # Entry point (auth redirect)
├── src/
│   ├── api/                  # API client and endpoints
│   ├── stores/               # Zustand state stores
│   ├── components/           # Reusable components
│   │   └── ui/               # Base UI components
│   ├── hooks/                # Custom React hooks
│   ├── types/                # TypeScript type definitions
│   └── utils/                # Constants and utilities
├── assets/                   # Images, fonts
├── app.json                  # Expo configuration
├── package.json              # Dependencies
└── tsconfig.json             # TypeScript config
```

## Available Scripts

- `npm start` - Start Expo development server
- `npm run ios` - Start on iOS Simulator
- `npm run android` - Start on Android Emulator
- `npm run lint` - Run ESLint
- `npm run typecheck` - Run TypeScript type checking

## Next Steps

After completing Stage 1C, proceed to:

- **Stage 2**: Complete auth flow, add protected routes
- **Stage 3**: Build instrument list and detail screens
- **Stage 4-5**: Implement preference cards CRUD
- **Stage 6**: Add quiz and study features

## Dependencies

### Core
- `expo` ~50.0.0
- `expo-router` ~3.4.0
- `react-native` 0.73.2
- `typescript` ^5.3.0

### Navigation
- `@react-navigation/native`
- `@react-navigation/bottom-tabs`
- `react-native-screens`
- `react-native-safe-area-context`

### State & Data
- `zustand` ^4.4.7 - State management
- `@tanstack/react-query` ^5.17.0 - Data fetching & caching
- `axios` ^1.6.5 - HTTP client

### Utilities
- `expo-secure-store` - Secure token storage
- `expo-image-picker` - Photo capture
- `expo-image` - Optimized image component
- `react-native-gesture-handler` - Gestures
- `react-native-reanimated` - Animations

## Notes

- The app currently shows placeholder screens for features coming in later stages
- Authentication is fully functional and persists between app restarts
- The API client handles token refresh automatically
- All types match the FastAPI backend Pydantic schemas
