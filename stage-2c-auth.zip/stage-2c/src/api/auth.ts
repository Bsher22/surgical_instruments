// src/api/auth.ts
// Authentication API functions

import {
  AuthResponse,
  LoginCredentials,
  SignupData,
  RefreshTokenResponse,
  User,
  AuthError,
} from '../types/auth';
import { API_BASE_URL } from '../utils/constants';

/**
 * Base fetch wrapper with error handling
 */
async function authFetch<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const url = `${API_BASE_URL}${endpoint}`;

  const response = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });

  if (!response.ok) {
    const errorData: AuthError = await response.json().catch(() => ({
      detail: 'An unexpected error occurred',
    }));

    throw new AuthApiError(
      errorData.detail || 'Request failed',
      response.status
    );
  }

  return response.json();
}

/**
 * Custom error class for auth API errors
 */
export class AuthApiError extends Error {
  constructor(
    message: string,
    public statusCode: number
  ) {
    super(message);
    this.name = 'AuthApiError';
  }
}

/**
 * Login with email and password
 */
export async function login(credentials: LoginCredentials): Promise<AuthResponse> {
  // FastAPI OAuth2 expects form data for token endpoint
  const formData = new URLSearchParams();
  formData.append('username', credentials.email); // OAuth2 uses 'username' field
  formData.append('password', credentials.password);

  const response = await fetch(`${API_BASE_URL}/auth/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: formData.toString(),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({
      detail: 'Login failed',
    }));

    if (response.status === 401) {
      throw new AuthApiError('Invalid email or password', 401);
    }

    throw new AuthApiError(errorData.detail || 'Login failed', response.status);
  }

  return response.json();
}

/**
 * Register a new user
 */
export async function signup(data: SignupData): Promise<AuthResponse> {
  return authFetch<AuthResponse>('/auth/register', {
    method: 'POST',
    body: JSON.stringify(data),
  });
}

/**
 * Refresh the access token using refresh token
 */
export async function refreshAccessToken(
  refreshToken: string
): Promise<RefreshTokenResponse> {
  const response = await fetch(`${API_BASE_URL}/auth/refresh`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ refresh_token: refreshToken }),
  });

  if (!response.ok) {
    if (response.status === 401) {
      throw new AuthApiError('Refresh token expired or invalid', 401);
    }

    const errorData = await response.json().catch(() => ({
      detail: 'Token refresh failed',
    }));

    throw new AuthApiError(
      errorData.detail || 'Token refresh failed',
      response.status
    );
  }

  return response.json();
}

/**
 * Get current user profile
 */
export async function getCurrentUser(accessToken: string): Promise<User> {
  const response = await fetch(`${API_BASE_URL}/auth/me`, {
    headers: {
      Authorization: `Bearer ${accessToken}`,
    },
  });

  if (!response.ok) {
    if (response.status === 401) {
      throw new AuthApiError('Not authenticated', 401);
    }

    throw new AuthApiError('Failed to get user profile', response.status);
  }

  return response.json();
}

/**
 * Logout (invalidate refresh token on server)
 */
export async function logout(accessToken: string): Promise<void> {
  try {
    await fetch(`${API_BASE_URL}/auth/logout`, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${accessToken}`,
      },
    });
  } catch (error) {
    // Logout should succeed locally even if server call fails
    console.warn('Server logout failed:', error);
  }
}

/**
 * Request password reset email
 */
export async function requestPasswordReset(email: string): Promise<void> {
  await authFetch('/auth/forgot-password', {
    method: 'POST',
    body: JSON.stringify({ email }),
  });
}

/**
 * Reset password with token
 */
export async function resetPassword(
  token: string,
  newPassword: string
): Promise<void> {
  await authFetch('/auth/reset-password', {
    method: 'POST',
    body: JSON.stringify({ token, new_password: newPassword }),
  });
}

/**
 * Change password (authenticated)
 */
export async function changePassword(
  accessToken: string,
  currentPassword: string,
  newPassword: string
): Promise<void> {
  const response = await fetch(`${API_BASE_URL}/auth/change-password`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${accessToken}`,
    },
    body: JSON.stringify({
      current_password: currentPassword,
      new_password: newPassword,
    }),
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({
      detail: 'Password change failed',
    }));

    throw new AuthApiError(
      errorData.detail || 'Password change failed',
      response.status
    );
  }
}
