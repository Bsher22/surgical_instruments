import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { instrumentsApi } from '../api/instruments';
import { Instrument, PaginatedResponse } from '../types';

interface UseInstrumentsParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
}

/**
 * Hook for fetching paginated instruments list
 */
export function useInstruments(params: UseInstrumentsParams = {}) {
  return useQuery<PaginatedResponse<Instrument>>({
    queryKey: ['instruments', params],
    queryFn: () => instrumentsApi.getInstruments(params),
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

/**
 * Hook for fetching a single instrument
 */
export function useInstrument(id: string) {
  return useQuery<Instrument>({
    queryKey: ['instrument', id],
    queryFn: () => instrumentsApi.getInstrument(id),
    enabled: !!id,
    staleTime: 1000 * 60 * 10, // 10 minutes
  });
}

/**
 * Hook for searching instruments
 */
export function useInstrumentSearch(query: string) {
  return useQuery<Instrument[]>({
    queryKey: ['instrumentSearch', query],
    queryFn: () => instrumentsApi.searchInstruments(query),
    enabled: query.length >= 2,
    staleTime: 1000 * 60 * 5,
  });
}

/**
 * Hook for bookmarking/unbookmarking instruments
 */
export function useInstrumentBookmark() {
  const queryClient = useQueryClient();

  const bookmark = useMutation({
    mutationFn: (id: string) => instrumentsApi.bookmarkInstrument(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instruments'] });
      queryClient.invalidateQueries({ queryKey: ['bookmarkedInstruments'] });
    },
  });

  const unbookmark = useMutation({
    mutationFn: (id: string) => instrumentsApi.unbookmarkInstrument(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['instruments'] });
      queryClient.invalidateQueries({ queryKey: ['bookmarkedInstruments'] });
    },
  });

  return { bookmark, unbookmark };
}
