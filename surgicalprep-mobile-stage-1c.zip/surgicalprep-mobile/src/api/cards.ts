import apiClient from './client';
import { ENDPOINTS } from '@/utils/constants';
import {
  PreferenceCard,
  CreateCardRequest,
  UpdateCardRequest,
  AddItemRequest,
  PreferenceCardItem,
  PaginatedResponse,
} from '@/types';

export const cardsApi = {
  async getCards(params?: {
    page?: number;
    limit?: number;
    search?: string;
  }): Promise<PaginatedResponse<PreferenceCard>> {
    const response = await apiClient.get<PaginatedResponse<PreferenceCard>>(ENDPOINTS.cards, {
      params: {
        page: params?.page || 1,
        limit: params?.limit || 20,
        q: params?.search,
      },
    });
    return response.data;
  },

  async getCard(id: string): Promise<PreferenceCard> {
    const response = await apiClient.get<PreferenceCard>(`${ENDPOINTS.cards}/${id}`);
    return response.data;
  },

  async createCard(data: CreateCardRequest): Promise<PreferenceCard> {
    const response = await apiClient.post<PreferenceCard>(ENDPOINTS.cards, data);
    return response.data;
  },

  async updateCard(id: string, data: UpdateCardRequest): Promise<PreferenceCard> {
    const response = await apiClient.put<PreferenceCard>(`${ENDPOINTS.cards}/${id}`, data);
    return response.data;
  },

  async deleteCard(id: string): Promise<void> {
    await apiClient.delete(`${ENDPOINTS.cards}/${id}`);
  },

  async duplicateCard(id: string): Promise<PreferenceCard> {
    const response = await apiClient.post<PreferenceCard>(`${ENDPOINTS.cards}/${id}/duplicate`);
    return response.data;
  },

  async getTemplates(): Promise<PreferenceCard[]> {
    const response = await apiClient.get<PreferenceCard[]>(ENDPOINTS.cardTemplates);
    return response.data;
  },

  // Card Items
  async addItem(cardId: string, data: AddItemRequest): Promise<PreferenceCardItem> {
    const response = await apiClient.post<PreferenceCardItem>(
      `${ENDPOINTS.cards}/${cardId}/items`,
      data
    );
    return response.data;
  },

  async updateItem(
    cardId: string,
    itemId: string,
    data: Partial<AddItemRequest>
  ): Promise<PreferenceCardItem> {
    const response = await apiClient.put<PreferenceCardItem>(
      `${ENDPOINTS.cards}/${cardId}/items/${itemId}`,
      data
    );
    return response.data;
  },

  async deleteItem(cardId: string, itemId: string): Promise<void> {
    await apiClient.delete(`${ENDPOINTS.cards}/${cardId}/items/${itemId}`);
  },

  async reorderItems(cardId: string, itemIds: string[]): Promise<void> {
    await apiClient.put(`${ENDPOINTS.cards}/${cardId}/items/reorder`, { item_ids: itemIds });
  },
};
