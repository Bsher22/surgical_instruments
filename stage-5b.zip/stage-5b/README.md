# Stage 5B: Card Create/Edit Screen - Basic Info

This stage implements the Card Create/Edit screen with basic information form fields for the SurgicalPrep mobile application.

## Features Implemented

- ✅ New card creation screen (`/cards/new`)
- ✅ Edit existing card screen (`/cards/edit/[id]`)
- ✅ Form fields for basic card information:
  - Title (required)
  - Surgeon name
  - Procedure name
  - Specialty dropdown
  - General notes
  - Setup notes
- ✅ Form validation with inline error messages
- ✅ Character count indicators
- ✅ Unsaved changes warning
- ✅ Draft auto-save to AsyncStorage
- ✅ Draft recovery on app restart
- ✅ Zustand store for form state management
- ✅ API integration for create/update operations
- ✅ Platform-specific specialty picker (ActionSheet iOS, Modal Android)

## Installation

### 1. Install Dependencies

Make sure you have the following dependencies installed:

```bash
# Core dependencies (should already be installed from Stage 2)
npx expo install @tanstack/react-query zustand axios expo-secure-store

# Additional dependencies for this stage
npx expo install @react-native-async-storage/async-storage
```

### 2. Copy Files

Copy the following directories/files to your project:

```
src/
├── api/
│   ├── client.ts        (if not already present)
│   ├── cards.ts         (new)
│   └── index.ts         (update)
├── components/
│   ├── cards/
│   │   ├── CardForm.tsx
│   │   ├── CardFormHeader.tsx
│   │   ├── SpecialtyPicker.tsx
│   │   └── index.ts
│   └── ui/
│       ├── FormInput.tsx
│       ├── FormTextArea.tsx
│       ├── FormPicker.tsx
│       ├── FormSection.tsx
│       └── index.ts
├── hooks/
│   └── useCardForm.ts
├── stores/
│   └── cardFormStore.ts
├── types/
│   ├── cardForm.ts
│   └── index.ts         (update)
└── utils/
    ├── cardValidation.ts
    └── specialties.ts

app/
└── (tabs)/
    └── cards/
        ├── new.tsx
        └── edit/
            └── [id].tsx
```

### 3. Update Existing Files

If you have existing type definitions in `src/types/index.ts`, merge the card-related types.

### 4. Environment Variables

Ensure your `.env` file has the API URL configured:

```env
EXPO_PUBLIC_API_URL=http://localhost:8000
```

## Usage

### Create New Card

Navigate to the new card screen:

```typescript
import { router } from 'expo-router';

// From a button or link
router.push('/cards/new');
```

### Edit Existing Card

Navigate to the edit card screen with the card ID:

```typescript
import { router } from 'expo-router';

// From card detail or list
router.push(`/cards/edit/${cardId}`);
```

### Add Create Button to Cards List

Add this to your cards list screen:

```tsx
import { Pressable } from 'react-native';
import { router } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

<Pressable
  onPress={() => router.push('/cards/new')}
  style={styles.createButton}
>
  <Ionicons name="add" size={24} color="#FFFFFF" />
</Pressable>
```

## File Structure

```
Stage 5B Files
├── src/
│   ├── api/
│   │   ├── client.ts        # Axios client with auth interceptors
│   │   ├── cards.ts         # Card API functions
│   │   └── index.ts         # API exports
│   ├── components/
│   │   ├── cards/
│   │   │   ├── CardForm.tsx         # Main form component
│   │   │   ├── CardFormHeader.tsx   # Header with save/cancel
│   │   │   ├── SpecialtyPicker.tsx  # Specialty dropdown
│   │   │   └── index.ts
│   │   └── ui/
│   │       ├── FormInput.tsx        # Text input component
│   │       ├── FormTextArea.tsx     # Multi-line input
│   │       ├── FormPicker.tsx       # Dropdown picker
│   │       ├── FormSection.tsx      # Section wrapper
│   │       └── index.ts
│   ├── hooks/
│   │   └── useCardForm.ts   # Form logic hook
│   ├── stores/
│   │   └── cardFormStore.ts # Zustand form store
│   ├── types/
│   │   ├── cardForm.ts      # Form-specific types
│   │   └── index.ts         # All types
│   └── utils/
│       ├── cardValidation.ts # Validation logic
│       └── specialties.ts    # Specialties list
└── app/
    └── (tabs)/
        └── cards/
            ├── new.tsx      # Create card screen
            └── edit/
                └── [id].tsx # Edit card screen
```

## API Endpoints Used

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/preference-cards` | Create new card |
| PUT | `/api/v1/preference-cards/{id}` | Update existing card |
| GET | `/api/v1/preference-cards/{id}` | Get card details |

## Form Validation Rules

| Field | Required | Min | Max | Notes |
|-------|----------|-----|-----|-------|
| Title | Yes | 3 | 100 | |
| Surgeon Name | No | - | 100 | |
| Procedure Name | No | - | 150 | |
| Specialty | No | - | - | Must be from predefined list |
| General Notes | No | - | 2000 | |
| Setup Notes | No | - | 2000 | |

## Placeholder Sections

The form includes placeholder sections for features implemented in later stages:

- **Items Section** (Stage 5C): Instruments, supplies, equipment management
- **Photos Section** (Stage 5D): Setup photo uploads

## Testing Checklist

- [ ] Create new card with all fields filled
- [ ] Create new card with only required title field
- [ ] Form validation shows error for empty title
- [ ] Form validation shows error for title < 3 characters
- [ ] Character counts display and update correctly
- [ ] Specialty picker works on iOS (ActionSheet)
- [ ] Specialty picker works on Android (Modal)
- [ ] Edit existing card loads data correctly
- [ ] Unsaved changes warning appears when leaving
- [ ] Draft auto-saves after 30 seconds
- [ ] Draft recovery prompt appears on restart
- [ ] Save button disabled until title is valid
- [ ] Loading state shows while saving
- [ ] Error handling displays appropriate messages
- [ ] Cancel returns to previous screen
- [ ] Successful save navigates to card detail

## Next Steps

After completing this stage, continue to:

- **Stage 5C**: Item Management (add/edit/delete items on cards)
- **Stage 5D**: Photo Upload (camera and gallery integration)
- **Stage 5E**: Card Operations (duplicate, delete with confirmation)
