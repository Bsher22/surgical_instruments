# Stage 10: Polish & Performance - Implementation Outline

**Goal**: Transform the SurgicalPrep app into a production-quality, performant, and accessible experience.

---

## Overview

Stage 10 focuses on four critical areas that elevate the app from functional to professional:

| Sub-Stage | Focus Area | Key Deliverables |
|-----------|------------|------------------|
| 10A | Performance | Image caching, list virtualization, query optimization |
| 10B | Error Handling | Error boundaries, toasts, offline detection, retry logic |
| 10C | UI Polish | Design system, animations, haptics, keyboard handling |
| 10D | Accessibility | Screen reader support, touch targets, font scaling |

---

## Stage 10A: Performance Optimization

### 1. Image Optimization with expo-image

**File**: `src/components/ui/OptimizedImage.tsx`

Replace React Native's `Image` with `expo-image` for superior caching and performance:

- **Memory caching**: Images stored in memory for instant re-display
- **Disk caching**: Persistent cache survives app restarts
- **Placeholder support**: Blurhash or low-res placeholders during load
- **Progressive loading**: Show low-quality first, then sharp image
- **Automatic format selection**: WebP when supported

```typescript
// Key features implemented:
- CachePolicy configuration (memory, disk, memoryAndDisk)
- Blurhash placeholder generation
- Transition animations between placeholder and loaded image
- Priority hints (low, normal, high)
- Recycling for lists (improves scroll performance)
```

### 2. FlatList Optimization

**File**: `src/components/ui/OptimizedFlatList.tsx`

Production-grade list with all performance optimizations:

- **getItemLayout**: Skip measurement for fixed-height items
- **windowSize**: Control render window (default 21 screens)
- **maxToRenderPerBatch**: Limit items rendered per frame
- **removeClippedSubviews**: Unmount off-screen items (Android)
- **updateCellsBatchingPeriod**: Debounce updates
- **Memoization**: Prevent unnecessary re-renders

```typescript
// Optimization settings implemented:
windowSize: 5              // Render 5 screens worth
maxToRenderPerBatch: 10    // 10 items per frame
updateCellsBatchingPeriod: 50  // 50ms batching
initialNumToRender: 10     // Initial render count
```

### 3. React Query Cache Configuration

**File**: `src/api/queryClient.ts`

Optimized caching strategy for the API layer:

```typescript
// Cache times by data type:
- Static data (instruments): 24 hours stale, 7 days cache
- User data (cards, progress): 5 minutes stale, 1 hour cache
- Real-time data (quiz sessions): No cache
```

Features:
- **Stale-while-revalidate**: Show cached data immediately, refresh in background
- **Query deduplication**: Single request for concurrent calls
- **Prefetching**: Load data before user navigates
- **Garbage collection**: Automatic cleanup of unused queries
- **Retry with exponential backoff**: Configurable retry logic

### 4. Bundle Size Analysis

**File**: `scripts/analyze-bundle.sh`

Tools and scripts for bundle optimization:

- expo-bundle-analyzer integration
- Tree-shaking verification
- Large dependency identification
- Code splitting recommendations

---

## Stage 10B: Error Handling

### 1. Global Error Boundary

**File**: `src/components/ErrorBoundary.tsx`

React error boundary with graceful recovery:

```typescript
// Features:
- Catches render errors in component tree
- Shows user-friendly error screen
- "Try Again" button to reset
- Reports errors to monitoring (Sentry-ready)
- Preserves navigation state when possible
```

### 2. Toast Notification System

**File**: `src/components/ui/Toast.tsx` & `src/stores/toastStore.ts`

Centralized notification system:

```typescript
// Toast types:
- success (green, checkmark icon)
- error (red, X icon)
- warning (amber, warning icon)
- info (blue, info icon)

// Features:
- Queue management (max 3 visible)
- Auto-dismiss with configurable duration
- Swipe to dismiss
- Action buttons (optional)
- Safe area aware positioning
```

### 3. API Error Interceptor

**File**: `src/api/errorInterceptor.ts`

Centralized API error handling:

```typescript
// Error handling by status:
- 401: Token refresh or redirect to login
- 403: Show premium upgrade prompt
- 404: Navigate to not found screen
- 422: Parse validation errors
- 429: Rate limit warning
- 500+: Generic server error toast

// Features:
- Automatic toast display
- Error normalization
- User-friendly messages
- Debug info in development
```

### 4. Offline Detection

**File**: `src/hooks/useNetworkStatus.ts` & `src/components/OfflineBanner.tsx`

Network-aware UI:

```typescript
// Features:
- Real-time connection monitoring
- Persistent banner when offline
- Automatic retry when back online
- Queue mutations for sync
- Visual indicators on actions
```

### 5. Retry Logic

**File**: `src/utils/retry.ts`

Configurable retry with exponential backoff:

```typescript
// Default configuration:
- maxRetries: 3
- initialDelay: 1000ms
- maxDelay: 10000ms
- backoffMultiplier: 2
- Retryable status codes: [408, 429, 500, 502, 503, 504]
```

---

## Stage 10C: UI Polish

### 1. Design System / Theme

**File**: `src/theme/index.ts`

Comprehensive design tokens:

```typescript
// Spacing scale (4px base):
xs: 4, sm: 8, md: 16, lg: 24, xl: 32, xxl: 48

// Typography:
- Font families (System, monospace)
- Size scale (12-32px)
- Line heights
- Letter spacing
- Font weights

// Colors:
- Primary palette (blue/teal medical theme)
- Semantic colors (success, error, warning)
- Neutral grays
- Dark mode variants

// Shadows:
- Elevation scale (sm, md, lg, xl)

// Border radii:
- none, sm, md, lg, full

// Animation durations:
- fast: 150ms, normal: 300ms, slow: 500ms
```

### 2. Loading Animations

**File**: `src/components/ui/LoadingSpinner.tsx` & `src/components/ui/SkeletonLoader.tsx`

Polished loading states:

```typescript
// Spinner variants:
- Small (16px) - inline loading
- Medium (24px) - button loading
- Large (48px) - full screen

// Skeleton components:
- Text lines (various widths)
- Cards (instrument, preference card)
- List items
- Images with aspect ratio
- Shimmer animation effect
```

### 3. Haptic Feedback

**File**: `src/utils/haptics.ts`

Strategic haptic feedback:

```typescript
// Haptic types:
- light: Tab selection, toggles
- medium: Button press, card flip
- heavy: Errors, important actions
- success: Quiz correct, save complete
- warning: Validation errors
- error: Failed actions

// Integration points:
- Button onPress
- Swipe gestures
- Quiz answers
- Card operations
- Navigation tabs
```

### 4. Pull-to-Refresh

**File**: `src/components/ui/RefreshableScrollView.tsx`

Consistent refresh behavior:

```typescript
// Features:
- Custom refresh indicator
- Haptic feedback on pull
- Loading state management
- Error recovery
- Configurable threshold
```

### 5. Keyboard Handling

**File**: `src/components/ui/KeyboardAvoidingWrapper.tsx`

Cross-platform keyboard handling:

```typescript
// Features:
- Platform-specific behavior
- Scroll to focused input
- Dismiss on tap outside
- Safe area integration
- Toolbar for iOS
```

### 6. Safe Area Handling

**File**: `src/components/ui/SafeContainer.tsx`

Consistent edge handling:

```typescript
// Features:
- Notch avoidance
- Home indicator padding
- Tab bar awareness
- Header integration
- Edge-to-edge option
```

---

## Stage 10D: Accessibility

### 1. Accessibility Utilities

**File**: `src/utils/accessibility.ts`

Helper functions for a11y:

```typescript
// Utilities:
- generateAccessibilityLabel(items)
- combineAccessibilityHints(hints)
- formatForScreenReader(text, type)
- announceForAccessibility(message)
```

### 2. Accessible Components

Updates to existing components with proper a11y props:

```typescript
// Required props:
- accessibilityLabel: Describes the element
- accessibilityRole: button, image, header, etc.
- accessibilityHint: Describes what happens on interaction
- accessibilityState: disabled, selected, checked, etc.

// Touch targets:
- Minimum 44x44 points
- hitSlop for tight layouts
```

### 3. Focus Management

**File**: `src/hooks/useFocus.ts`

Screen reader focus utilities:

```typescript
// Features:
- setAccessibilityFocus(ref)
- Focus on modal open
- Focus restoration on close
- Focus order customization
```

### 4. Dynamic Font Scaling

**File**: `src/hooks/useDynamicFontSize.ts`

Respects system font size:

```typescript
// Features:
- PixelRatio.getFontScale()
- Scaled typography
- Max scale limits
- Layout adjustments
```

### 5. Color Contrast

**File**: `src/utils/colorContrast.ts`

WCAG compliance utilities:

```typescript
// Features:
- getContrastRatio(fg, bg)
- meetsWCAG_AA(ratio)
- meetsWCAG_AAA(ratio)
- suggestAccessibleColor(color, bg)
```

### 6. Reduce Motion

**File**: `src/hooks/useReduceMotion.ts`

Respects system motion preferences:

```typescript
// Features:
- AccessibilityInfo.isReduceMotionEnabled()
- Conditional animations
- Fallback transitions
- Disable parallax effects
```

---

## File Structure

```
src/
├── api/
│   ├── queryClient.ts          # Optimized React Query config
│   └── errorInterceptor.ts     # Centralized error handling
├── components/
│   ├── ErrorBoundary.tsx       # Global error boundary
│   ├── OfflineBanner.tsx       # Network status banner
│   └── ui/
│       ├── OptimizedImage.tsx  # expo-image wrapper
│       ├── OptimizedFlatList.tsx
│       ├── Toast.tsx           # Toast notifications
│       ├── ToastContainer.tsx  # Toast renderer
│       ├── LoadingSpinner.tsx  # Animated spinner
│       ├── SkeletonLoader.tsx  # Skeleton components
│       ├── RefreshableScrollView.tsx
│       ├── KeyboardAvoidingWrapper.tsx
│       └── SafeContainer.tsx   # Safe area wrapper
├── hooks/
│   ├── useNetworkStatus.ts     # Online/offline detection
│   ├── useFocus.ts             # Accessibility focus
│   ├── useDynamicFontSize.ts   # Font scaling
│   └── useReduceMotion.ts      # Motion preferences
├── stores/
│   └── toastStore.ts           # Toast state management
├── theme/
│   ├── index.ts                # Main theme export
│   ├── colors.ts               # Color tokens
│   ├── spacing.ts              # Spacing scale
│   ├── typography.ts           # Text styles
│   └── shadows.ts              # Elevation shadows
└── utils/
    ├── haptics.ts              # Haptic feedback
    ├── retry.ts                # Retry with backoff
    ├── accessibility.ts        # A11y helpers
    └── colorContrast.ts        # WCAG utilities
```

---

## Dependencies to Install

```bash
# Performance
npx expo install expo-image

# Haptics
npx expo install expo-haptics

# Network detection
npx expo install @react-native-community/netinfo

# Animations (if not already installed)
npx expo install react-native-reanimated

# Accessibility
# (Built into React Native, no additional deps)
```

---

## Integration Points

### 1. App Root (`app/_layout.tsx`)

```typescript
// Wrap with providers:
<ErrorBoundary>
  <QueryClientProvider client={queryClient}>
    <SafeAreaProvider>
      <ToastContainer />
      <OfflineBanner />
      <Stack />
    </SafeAreaProvider>
  </QueryClientProvider>
</ErrorBoundary>
```

### 2. List Screens

Replace `FlatList` with `OptimizedFlatList` in:
- Instruments list
- Cards list
- Quiz history

### 3. Image Components

Replace `Image` with `OptimizedImage` in:
- InstrumentCard
- Instrument detail
- Card photos
- Flashcards

### 4. Interactive Elements

Add haptic feedback to:
- All buttons
- Tab navigation
- Swipe gestures
- Quiz answers

### 5. Forms

Wrap with `KeyboardAvoidingWrapper`:
- Login/signup
- Card create/edit
- Profile edit

---

## Testing Checklist

### Performance
- [ ] Images load quickly on slow networks
- [ ] Lists scroll at 60fps
- [ ] No jank during navigation
- [ ] Memory usage stays stable
- [ ] Bundle size under 10MB

### Error Handling
- [ ] Errors show user-friendly toasts
- [ ] Offline mode shows banner
- [ ] Failed requests retry automatically
- [ ] 401 redirects to login
- [ ] Crashes show recovery screen

### UI Polish
- [ ] Consistent spacing throughout
- [ ] Smooth animations
- [ ] Haptics feel natural
- [ ] Keyboard doesn't cover inputs
- [ ] Notch/home indicator handled

### Accessibility
- [ ] VoiceOver reads all elements
- [ ] TalkBack works on Android
- [ ] Touch targets ≥44x44
- [ ] Colors meet WCAG AA
- [ ] Large text doesn't break layout

---

## Next Steps

After completing Stage 10:
1. **Stage 11**: Testing & QA
2. Run full manual test suite
3. Beta testing with real users
4. Collect performance metrics
