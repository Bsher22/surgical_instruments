import Constants from 'expo-constants';

// API URL - from environment or default to localhost for dev
export const API_URL =
  Constants.expoConfig?.extra?.apiUrl ||
  process.env.EXPO_PUBLIC_API_URL ||
  'http://localhost:8000/api/v1';

// App configuration
export const APP_CONFIG = {
  // Instrument categories for filtering
  INSTRUMENT_CATEGORIES: [
    { value: 'cutting', label: 'Cutting' },
    { value: 'clamping', label: 'Clamping' },
    { value: 'grasping', label: 'Grasping' },
    { value: 'retracting', label: 'Retracting' },
    { value: 'suturing', label: 'Suturing' },
    { value: 'suctioning', label: 'Suctioning' },
    { value: 'dilating', label: 'Dilating' },
    { value: 'probing', label: 'Probing' },
    { value: 'measuring', label: 'Measuring' },
    { value: 'specialty', label: 'Specialty' },
  ],

  // Pagination defaults
  DEFAULT_PAGE_SIZE: 20,
  MAX_PAGE_SIZE: 50,

  // Free tier limits
  FREE_TIER_LIMITS: {
    maxCards: 5,
    dailyQuizzes: 3,
    maxBookmarks: 20,
  },

  // Search configuration
  SEARCH_DEBOUNCE_MS: 300,
  SEARCH_MIN_CHARS: 2,

  // Image dimensions
  IMAGE_SIZES: {
    thumbnail: { width: 400, height: 300 },
    full: { width: 800, height: 600 },
  },
} as const;

// Colors used throughout the app
export const COLORS = {
  primary: '#3B82F6',
  primaryDark: '#2563EB',
  secondary: '#64748B',
  success: '#059669',
  warning: '#D97706',
  error: '#DC2626',
  premium: '#F59E0B',

  background: '#F8FAFC',
  surface: '#FFFFFF',
  border: '#E2E8F0',

  textPrimary: '#0F172A',
  textSecondary: '#334155',
  textMuted: '#64748B',
} as const;
