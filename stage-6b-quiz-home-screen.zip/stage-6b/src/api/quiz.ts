// ============================================================================
// Quiz API Client
// ============================================================================

import { apiClient } from './client';
import type {
  StudyStatsResponse,
  QuizHistoryResponse,
  DueForReviewResponse,
  CategoriesResponse,
  QuizConfig,
  QuizSession,
  QuizQuestion,
  AnswerSubmission,
  AnswerResult,
  QuizResult,
  FlashcardItem,
  FlashcardResult,
  QuizLimit,
} from '../types/quiz';

// ============================================================================
// Study Stats & Progress
// ============================================================================

/**
 * Get user's study statistics and quiz limits
 */
export async function getStudyStats(): Promise<StudyStatsResponse> {
  const response = await apiClient.get<StudyStatsResponse>('/api/v1/quiz/stats');
  return response.data;
}

/**
 * Get current quiz limit status for free tier
 */
export async function getQuizLimit(): Promise<QuizLimit> {
  const response = await apiClient.get<QuizLimit>('/api/v1/quiz/limit');
  return response.data;
}

// ============================================================================
// Due for Review (Spaced Repetition)
// ============================================================================

/**
 * Get instruments due for review based on spaced repetition
 */
export async function getDueForReview(params?: {
  categoryIds?: string[];
  limit?: number;
}): Promise<DueForReviewResponse> {
  const response = await apiClient.get<DueForReviewResponse>('/api/v1/quiz/due-for-review', {
    params: {
      category_ids: params?.categoryIds?.join(','),
      limit: params?.limit,
    },
  });
  return response.data;
}

// ============================================================================
// Quiz History
// ============================================================================

/**
 * Get user's quiz session history
 */
export async function getQuizHistory(params?: {
  page?: number;
  pageSize?: number;
  quizType?: string;
  status?: string;
}): Promise<QuizHistoryResponse> {
  const response = await apiClient.get<QuizHistoryResponse>('/api/v1/quiz/history', {
    params: {
      page: params?.page ?? 1,
      page_size: params?.pageSize ?? 10,
      quiz_type: params?.quizType,
      status: params?.status,
    },
  });
  return response.data;
}

// ============================================================================
// Categories
// ============================================================================

/**
 * Get available instrument categories for quiz filtering
 */
export async function getCategories(): Promise<CategoriesResponse> {
  const response = await apiClient.get<CategoriesResponse>('/api/v1/instruments/categories');
  return response.data;
}

// ============================================================================
// Quiz Session Management
// ============================================================================

/**
 * Start a new quiz session
 */
export async function startQuizSession(config: QuizConfig): Promise<{
  session: QuizSession;
  firstQuestion: QuizQuestion;
}> {
  const response = await apiClient.post('/api/v1/quiz/sessions', {
    quiz_type: config.quizType,
    question_types: config.questionTypes,
    category_ids: config.categoryIds.length > 0 ? config.categoryIds : undefined,
    question_count: config.questionCount,
    timer_enabled: config.timerEnabled,
    time_per_question: config.timerEnabled ? config.timePerQuestion : undefined,
  });
  return response.data;
}

/**
 * Submit an answer for a quiz question
 */
export async function submitAnswer(
  sessionId: string,
  answer: AnswerSubmission
): Promise<AnswerResult> {
  const response = await apiClient.post<AnswerResult>(
    `/api/v1/quiz/sessions/${sessionId}/answers`,
    {
      question_id: answer.questionId,
      selected_option_id: answer.selectedOptionId,
      response_time_ms: answer.responseTimeMs,
    }
  );
  return response.data;
}

/**
 * End a quiz session (complete or abandon)
 */
export async function endQuizSession(
  sessionId: string,
  status: 'completed' | 'abandoned' = 'completed'
): Promise<QuizResult> {
  const response = await apiClient.post<QuizResult>(
    `/api/v1/quiz/sessions/${sessionId}/end`,
    { status }
  );
  return response.data;
}

/**
 * Get a specific quiz session details
 */
export async function getQuizSession(sessionId: string): Promise<QuizSession> {
  const response = await apiClient.get<QuizSession>(`/api/v1/quiz/sessions/${sessionId}`);
  return response.data;
}

/**
 * Get quiz results for a completed session
 */
export async function getQuizResults(sessionId: string): Promise<QuizResult> {
  const response = await apiClient.get<QuizResult>(`/api/v1/quiz/sessions/${sessionId}/results`);
  return response.data;
}

// ============================================================================
// Flashcard Mode
// ============================================================================

/**
 * Get flashcards for a study session
 */
export async function getFlashcards(params: {
  categoryIds?: string[];
  count?: number;
  dueOnly?: boolean;
}): Promise<{ cards: FlashcardItem[]; total: number }> {
  const response = await apiClient.get('/api/v1/quiz/flashcards', {
    params: {
      category_ids: params.categoryIds?.join(','),
      count: params.count ?? 10,
      due_only: params.dueOnly ?? false,
    },
  });
  return response.data;
}

/**
 * Submit flashcard study result
 */
export async function submitFlashcardResult(result: FlashcardResult): Promise<{
  success: boolean;
  nextReviewAt: string;
  masteryLevel: number;
}> {
  const response = await apiClient.post('/api/v1/quiz/flashcards/result', {
    instrument_id: result.instrumentId,
    response: result.response,
    time_spent_ms: result.timeSpentMs,
  });
  return response.data;
}

/**
 * Submit batch flashcard results (at end of session)
 */
export async function submitFlashcardResults(results: FlashcardResult[]): Promise<{
  success: boolean;
  studiedCount: number;
  masteredCount: number;
  needsReviewCount: number;
  xpEarned: number;
}> {
  const response = await apiClient.post('/api/v1/quiz/flashcards/batch-result', {
    results: results.map((r) => ({
      instrument_id: r.instrumentId,
      response: r.response,
      time_spent_ms: r.timeSpentMs,
    })),
  });
  return response.data;
}

// ============================================================================
// Review Due (Quick Action)
// ============================================================================

/**
 * Start a review session for due instruments
 */
export async function startReviewSession(): Promise<{
  session: QuizSession;
  cards: FlashcardItem[];
  dueCount: number;
}> {
  const response = await apiClient.post('/api/v1/quiz/review/start');
  return response.data;
}

// ============================================================================
// Study Progress
// ============================================================================

/**
 * Get detailed progress for a specific instrument
 */
export async function getInstrumentProgress(instrumentId: string): Promise<{
  instrumentId: string;
  timesStudied: number;
  correctCount: number;
  incorrectCount: number;
  accuracy: number;
  masteryLevel: number;
  lastStudiedAt: string | null;
  nextReviewAt: string | null;
}> {
  const response = await apiClient.get(`/api/v1/quiz/progress/instruments/${instrumentId}`);
  return response.data;
}

/**
 * Bookmark an instrument for study
 */
export async function bookmarkInstrument(instrumentId: string): Promise<{ success: boolean }> {
  const response = await apiClient.post(`/api/v1/instruments/${instrumentId}/bookmark`);
  return response.data;
}

/**
 * Remove bookmark from an instrument
 */
export async function unbookmarkInstrument(instrumentId: string): Promise<{ success: boolean }> {
  const response = await apiClient.delete(`/api/v1/instruments/${instrumentId}/bookmark`);
  return response.data;
}

/**
 * Get bookmarked instruments
 */
export async function getBookmarkedInstruments(params?: {
  page?: number;
  pageSize?: number;
}): Promise<{
  instruments: Array<{
    id: string;
    name: string;
    imageUrl: string | null;
    category: string;
    bookmarkedAt: string;
  }>;
  total: number;
  hasMore: boolean;
}> {
  const response = await apiClient.get('/api/v1/instruments/bookmarked', {
    params: {
      page: params?.page ?? 1,
      page_size: params?.pageSize ?? 20,
    },
  });
  return response.data;
}
