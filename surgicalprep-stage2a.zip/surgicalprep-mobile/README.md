# SurgicalPrep Mobile App

A React Native (Expo) mobile application for surgical technicians to study surgical instruments and manage preference cards.

## Stage 2A: Project Structure

This is the foundational project structure for the SurgicalPrep mobile app. It includes:

### Directory Structure

```
surgicalprep-mobile/
├── app/                          # Expo Router (file-based routing)
│   ├── (auth)/                   # Auth screens (login, signup)
│   │   ├── _layout.tsx
│   │   ├── login.tsx
│   │   └── signup.tsx
│   ├── (tabs)/                   # Main app tabs
│   │   ├── _layout.tsx           # Tab navigator
│   │   ├── instruments/
│   │   │   ├── _layout.tsx
│   │   │   ├── index.tsx         # Instrument list
│   │   │   └── [id].tsx          # Instrument detail
│   │   ├── cards/
│   │   │   ├── _layout.tsx
│   │   │   ├── index.tsx         # Card list
│   │   │   ├── [id].tsx          # Card detail/edit
│   │   │   └── new.tsx           # Create card
│   │   ├── quiz/
│   │   │   ├── _layout.tsx
│   │   │   ├── index.tsx         # Quiz home
│   │   │   ├── flashcards.tsx
│   │   │   └── session.tsx       # Active quiz
│   │   └── profile/
│   │       └── index.tsx
│   ├── _layout.tsx               # Root layout
│   └── index.tsx                 # Entry redirect
├── src/
│   ├── api/                      # API client
│   │   ├── client.ts             # Axios/fetch setup
│   │   ├── auth.ts
│   │   ├── instruments.ts
│   │   ├── cards.ts
│   │   ├── quiz.ts
│   │   └── index.ts
│   ├── stores/                   # Zustand stores
│   │   ├── authStore.ts
│   │   └── quizStore.ts
│   ├── components/               # Reusable components
│   │   ├── ui/                   # Button, Input, etc.
│   │   ├── InstrumentCard.tsx
│   │   ├── PreferenceCardItem.tsx
│   │   └── FlashCard.tsx
│   ├── hooks/                    # Custom hooks
│   │   ├── useAuth.ts
│   │   └── useInstruments.ts
│   ├── types/                    # TypeScript types
│   │   └── index.ts
│   └── utils/
│       └── constants.ts
├── assets/                       # Images, fonts
├── app.json                      # Expo configuration
├── package.json
└── tsconfig.json
```

## Setup Instructions

### Prerequisites

- Node.js 20+ and npm
- Expo CLI: `npm install -g expo-cli`
- EAS CLI: `npm install -g eas-cli`
- iOS Simulator (Mac) or Android Studio emulator
- Expo Go app on physical device (optional)

### Installation

1. Install dependencies:
   ```bash
   cd surgicalprep-mobile
   npm install
   ```

2. Create `.env.local` file:
   ```bash
   cp .env.example .env.local
   ```
   
3. Update `.env.local` with your API URL:
   ```
   EXPO_PUBLIC_API_URL=http://localhost:8000
   ```

4. Start the development server:
   ```bash
   npm start
   ```

5. Press `i` for iOS simulator, `a` for Android emulator, or scan QR with Expo Go.

## Next Steps

After completing Stage 2A (this structure), proceed to:

- **Stage 2B**: API Client - Set up typed axios/fetch client with React Query
- **Stage 2C**: Authentication Store & Flow - Complete Zustand auth implementation
- **Stage 2D**: Auth Screens - Finalize login/signup with validation

## Key Technologies

- **Expo Router**: File-based routing with nested layouts
- **React Query**: Server state management and caching
- **Zustand**: Client state management (auth, quiz state)
- **Expo Secure Store**: Secure JWT token storage
- **TypeScript**: Full type safety

## Environment Variables

| Variable | Description |
|----------|-------------|
| `EXPO_PUBLIC_API_URL` | Backend API URL |

## Available Scripts

- `npm start` - Start Expo development server
- `npm run ios` - Start on iOS simulator
- `npm run android` - Start on Android emulator
- `npm run web` - Start web version
- `npm run lint` - Run linter
- `npm test` - Run tests
