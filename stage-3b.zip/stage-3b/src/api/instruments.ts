// src/api/instruments.ts
// API hooks for instruments - assumes Stage 3A implementation
// This file shows the expected interface from Stage 3A

import {
  useInfiniteQuery,
  useQuery,
  UseInfiniteQueryResult,
  UseQueryResult,
} from '@tanstack/react-query';
import { apiClient } from './client';
import type {
  Instrument,
  InstrumentQueryParams,
  PaginatedResponse,
} from '../types/instruments';

/**
 * Fetch paginated instruments with optional search/filter
 * Used by the instrument list screen with infinite scroll
 */
export function useInstruments(
  params: InstrumentQueryParams
): UseInfiniteQueryResult<PaginatedResponse<Instrument>, Error> {
  return useInfiniteQuery({
    queryKey: ['instruments', params],
    queryFn: async ({ pageParam = 1 }) => {
      const response = await apiClient.get<PaginatedResponse<Instrument>>(
        '/instruments',
        {
          params: {
            ...params,
            page: pageParam,
          },
        }
      );
      return response.data;
    },
    getNextPageParam: (lastPage) => {
      if (lastPage.page < lastPage.total_pages) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });
}

/**
 * Fetch a single instrument by ID
 * Used by the instrument detail screen
 */
export function useInstrument(id: string): UseQueryResult<Instrument, Error> {
  return useQuery({
    queryKey: ['instrument', id],
    queryFn: async () => {
      const response = await apiClient.get<Instrument>(`/instruments/${id}`);
      return response.data;
    },
    enabled: !!id,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });
}

/**
 * Search instruments with full-text search
 * Used for autocomplete and quick search
 */
export function useInstrumentSearch(
  query: string
): UseQueryResult<Instrument[], Error> {
  return useQuery({
    queryKey: ['instruments', 'search', query],
    queryFn: async () => {
      const response = await apiClient.get<Instrument[]>('/instruments/search', {
        params: { q: query },
      });
      return response.data;
    },
    enabled: query.length >= 2,
    staleTime: 60 * 1000, // 1 minute
  });
}

// ============================================================
// MOCK IMPLEMENTATION FOR TESTING (remove in production)
// ============================================================

/**
 * Mock data generator for testing without backend
 * Replace with real API calls once backend is ready
 */
const MOCK_INSTRUMENTS: Instrument[] = [
  {
    id: '1',
    name: 'Mayo Scissors',
    aliases: ['Mayo Dissecting Scissors', 'Mayo-Stille Scissors'],
    category: 'cutting',
    description: 'Heavy scissors used for cutting fascia and other dense tissues.',
    primary_uses: ['Cutting fascia', 'Dissection of tough tissues', 'Cutting sutures'],
    common_procedures: ['Abdominal surgery', 'Orthopedic procedures'],
    handling_notes: 'Available in straight and curved varieties',
    image_url: null,
    thumbnail_url: null,
    is_premium: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  {
    id: '2',
    name: 'Kelly Clamp',
    aliases: ['Kelly Forceps', 'Kelly Hemostat'],
    category: 'clamping',
    description: 'A surgical clamp used to control bleeding by clamping blood vessels.',
    primary_uses: ['Hemostasis', 'Clamping vessels', 'Tissue manipulation'],
    common_procedures: ['General surgery', 'Vascular procedures'],
    handling_notes: 'Partially serrated, available in straight and curved',
    image_url: null,
    thumbnail_url: null,
    is_premium: false,
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
  // Add more mock instruments as needed for testing...
];

/**
 * Mock hook for development/testing
 * Simulates paginated API response
 */
export function useMockInstruments(
  params: InstrumentQueryParams
): UseInfiniteQueryResult<PaginatedResponse<Instrument>, Error> {
  return useInfiniteQuery({
    queryKey: ['instruments', 'mock', params],
    queryFn: async ({ pageParam = 1 }) => {
      // Simulate network delay
      await new Promise((resolve) => setTimeout(resolve, 500));

      // Filter by search
      let filtered = MOCK_INSTRUMENTS;
      if (params.search) {
        const searchLower = params.search.toLowerCase();
        filtered = filtered.filter(
          (i) =>
            i.name.toLowerCase().includes(searchLower) ||
            i.aliases.some((a) => a.toLowerCase().includes(searchLower))
        );
      }

      // Filter by category
      if (params.category) {
        filtered = filtered.filter((i) => i.category === params.category);
      }

      // Paginate
      const pageSize = params.page_size || 20;
      const start = (pageParam - 1) * pageSize;
      const items = filtered.slice(start, start + pageSize);

      return {
        items,
        total: filtered.length,
        page: pageParam,
        page_size: pageSize,
        total_pages: Math.ceil(filtered.length / pageSize),
      };
    },
    getNextPageParam: (lastPage) => {
      if (lastPage.page < lastPage.total_pages) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    initialPageParam: 1,
  });
}
