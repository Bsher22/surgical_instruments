/**
 * SurgicalPrep Type Definitions
 *
 * Core types used throughout the mobile application.
 * These should match the backend Pydantic schemas.
 */

// ============================================
// User & Authentication Types
// ============================================

export type UserRole = 'student' | 'surgical_tech' | 'nurse' | 'educator' | 'other';

export interface RoleOption {
  value: UserRole;
  label: string;
  description: string;
}

export const ROLE_OPTIONS: RoleOption[] = [
  {
    value: 'student',
    label: 'Surgical Tech Student',
    description: 'Currently enrolled in a surgical technology program',
  },
  {
    value: 'surgical_tech',
    label: 'Certified Surgical Technologist',
    description: 'Working as a CST in a healthcare facility',
  },
  {
    value: 'nurse',
    label: 'OR Nurse / Perioperative Nurse',
    description: 'RN working in the operating room',
  },
  {
    value: 'educator',
    label: 'Surgical Tech Educator',
    description: 'Teaching or training surgical technologists',
  },
  {
    value: 'other',
    label: 'Other Healthcare Professional',
    description: 'Other role in surgical or healthcare setting',
  },
];

export type SubscriptionTier = 'free' | 'premium';

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  institution?: string;
  subscription_tier: SubscriptionTier;
  subscription_expires_at?: string;
  created_at: string;
  updated_at: string;
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
  expires_in: number;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  name: string;
  email: string;
  password: string;
  role: UserRole;
  institution?: string;
}

export interface AuthResponse {
  user: User;
  tokens: AuthTokens;
}

// ============================================
// API Response Types
// ============================================

export interface ApiError {
  detail: string;
  code?: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  size: number;
  pages: number;
}

// ============================================
// Instrument Types
// ============================================

export type InstrumentCategory =
  | 'cutting'
  | 'grasping'
  | 'clamping'
  | 'retracting'
  | 'probing'
  | 'suturing'
  | 'dilating'
  | 'suctioning'
  | 'specialty'
  | 'other';

export interface Instrument {
  id: string;
  name: string;
  aliases: string[];
  category: InstrumentCategory;
  description: string;
  primary_uses: string[];
  common_procedures: string[];
  handling_notes?: string;
  image_url?: string;
  thumbnail_url?: string;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

// ============================================
// Preference Card Types
// ============================================

export type ItemCategory =
  | 'instruments'
  | 'supplies'
  | 'sutures'
  | 'implants'
  | 'special';

export interface PreferenceCardItem {
  id: string;
  instrument_id?: string;
  name: string;
  quantity: number;
  size?: string;
  notes?: string;
  category: ItemCategory;
  order_index: number;
}

export interface PreferenceCard {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: string;
  general_notes?: string;
  setup_notes?: string;
  photo_urls: string[];
  is_template: boolean;
  is_public: boolean;
  items: PreferenceCardItem[];
  created_at: string;
  updated_at: string;
}

// ============================================
// Quiz & Study Types
// ============================================

export type QuestionType = 'image_to_name' | 'name_to_use' | 'image_to_category';

export interface QuizQuestion {
  id: string;
  type: QuestionType;
  instrument_id: string;
  question_text: string;
  image_url?: string;
  options: string[];
  correct_answer: string;
}

export interface QuizSession {
  id: string;
  user_id: string;
  question_type?: QuestionType;
  categories?: InstrumentCategory[];
  total_questions: number;
  correct_answers: number;
  started_at: string;
  completed_at?: string;
}

export interface UserInstrumentProgress {
  user_id: string;
  instrument_id: string;
  times_studied: number;
  times_correct: number;
  times_incorrect: number;
  last_studied_at: string;
  next_review_at: string;
  ease_factor: number;
  interval_days: number;
}

// ============================================
// Navigation Types
// ============================================

export type RootStackParamList = {
  '(auth)': undefined;
  '(tabs)': undefined;
  login: undefined;
  signup: undefined;
  'instruments/index': undefined;
  'instruments/[id]': { id: string };
  'cards/index': undefined;
  'cards/[id]': { id: string };
  'cards/new': undefined;
  'quiz/index': undefined;
  'quiz/flashcards': { category?: InstrumentCategory };
  'quiz/session': { sessionId: string };
  'profile/index': undefined;
};
