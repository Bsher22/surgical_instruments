/**
 * Card Form State Management Types
 * 
 * These types are specifically for the form state and differ from
 * the API types to handle UI-specific concerns like draft state,
 * temporary IDs, and deletion markers.
 */

import { Specialty } from './index';

/**
 * Item category for grouping card items
 */
export enum ItemCategory {
  INSTRUMENT = 'instrument',
  SUPPLY = 'supply',
  SUTURE = 'suture',
  IMPLANT = 'implant',
  SPECIAL = 'special',
  OTHER = 'other',
}

/**
 * Individual item in the preference card form
 */
export interface CardFormItem {
  /** Unique ID - UUID for new items, actual ID for existing */
  id: string;
  /** Linked instrument ID (optional - null for custom items) */
  instrumentId: string | null;
  /** Item name (required) */
  name: string;
  /** Quantity needed (default: 1) */
  quantity: number;
  /** Size specification (optional) */
  size: string;
  /** Item-specific notes (optional) */
  notes: string;
  /** Category for grouping */
  category: ItemCategory;
  /** Whether this is a manually entered custom item */
  isCustom: boolean;
  /** Display order (0-indexed) */
  order: number;
  /** Whether this is a newly added item (not yet saved) */
  isNew: boolean;
  /** Whether this item is marked for deletion */
  isDeleted: boolean;
}

/**
 * Photo metadata for the card form
 */
export interface CardFormPhoto {
  /** Unique ID */
  id: string;
  /** Local file URI or remote URL */
  uri: string;
  /** Whether this is a newly added photo (not yet uploaded) */
  isNew: boolean;
  /** Whether this photo is marked for deletion */
  isDeleted: boolean;
  /** Upload progress (0-100) for new photos */
  uploadProgress?: number;
  /** Remote URL after upload (for new photos) */
  remoteUrl?: string;
}

/**
 * Main form data structure for preference card creation/editing
 */
export interface CardFormData {
  /** Card ID - undefined for new cards */
  id?: string;
  /** Card title (required) */
  title: string;
  /** Surgeon name */
  surgeonName: string;
  /** Procedure name */
  procedureName: string;
  /** Selected specialty */
  specialty: Specialty | null;
  /** General notes textarea */
  generalNotes: string;
  /** Setup notes textarea */
  setupNotes: string;
  /** Array of items on the card */
  items: CardFormItem[];
  /** Array of photos */
  photos: CardFormPhoto[];
}

/**
 * Validation errors for form fields
 */
export interface FormValidationErrors {
  title?: string;
  surgeonName?: string;
  procedureName?: string;
  items?: string;
  general?: string;
}

/**
 * Draft metadata stored alongside form data
 */
export interface CardDraftMetadata {
  /** When the draft was last saved */
  savedAt: string;
  /** Card ID if editing, undefined if new */
  cardId?: string;
  /** User-friendly card title for display */
  cardTitle: string;
  /** Draft version for conflict detection */
  version: number;
}

/**
 * Complete draft object stored in AsyncStorage
 */
export interface CardDraft {
  metadata: CardDraftMetadata;
  formData: CardFormData;
}

/**
 * Card form store state
 */
export interface CardFormState {
  /** Current form data */
  formData: CardFormData;
  /** Original data for change detection (null for new cards) */
  originalData: CardFormData | null;
  /** Whether form has unsaved changes */
  isDirty: boolean;
  /** Loading state (initializing from card/draft) */
  isLoading: boolean;
  /** Save in progress */
  isSaving: boolean;
  /** Last auto-save timestamp */
  lastSavedAt: Date | null;
  /** Current validation errors */
  validationErrors: FormValidationErrors;
  /** AsyncStorage key for current draft */
  draftKey: string | null;
  /** Whether we're editing an existing card */
  isEditing: boolean;
}

/**
 * Card form store actions
 */
export interface CardFormActions {
  /** Reset to blank form for new card */
  initializeNewCard: () => void;
  /** Load existing card for editing */
  initializeFromCard: (card: PreferenceCardWithItems) => void;
  /** Restore from saved draft */
  initializeFromDraft: (draft: CardDraft) => Promise<void>;
  /** Update a single form field */
  updateField: <K extends keyof CardFormData>(
    field: K,
    value: CardFormData[K]
  ) => void;
  /** Add item to card */
  addItem: (item: Partial<CardFormItem>) => void;
  /** Update existing item */
  updateItem: (itemId: string, updates: Partial<CardFormItem>) => void;
  /** Remove item from card (marks for deletion if existing) */
  removeItem: (itemId: string) => void;
  /** Reorder items via drag-and-drop */
  reorderItems: (fromIndex: number, toIndex: number) => void;
  /** Add photo to card */
  addPhoto: (uri: string) => void;
  /** Remove photo from card (marks for deletion if existing) */
  removePhoto: (photoId: string) => void;
  /** Update photo (e.g., after upload) */
  updatePhoto: (photoId: string, updates: Partial<CardFormPhoto>) => void;
  /** Run validation, return success */
  validate: () => boolean;
  /** Clear validation errors */
  clearValidationErrors: () => void;
  /** Save current state to AsyncStorage */
  saveDraft: () => Promise<void>;
  /** Remove draft from AsyncStorage */
  clearDraft: () => Promise<void>;
  /** Clear all form state */
  reset: () => void;
  /** Update originalData, clear dirty flag (after successful save) */
  markAsSaved: () => void;
  /** Set loading state */
  setIsLoading: (loading: boolean) => void;
  /** Set saving state */
  setIsSaving: (saving: boolean) => void;
}

/**
 * Combined store type
 */
export type CardFormStore = CardFormState & CardFormActions;

/**
 * Preference card with items - matches API response structure
 * This should align with your existing types in src/types/index.ts
 */
export interface PreferenceCardWithItems {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: Specialty;
  general_notes?: string;
  setup_notes?: string;
  is_template: boolean;
  is_public: boolean;
  created_at: string;
  updated_at: string;
  items: PreferenceCardItem[];
  photos?: PreferenceCardPhoto[];
}

/**
 * Preference card item from API
 */
export interface PreferenceCardItem {
  id: string;
  card_id: string;
  instrument_id?: string;
  custom_item_name?: string;
  quantity: number;
  size?: string;
  notes?: string;
  category: string;
  display_order: number;
  instrument?: {
    id: string;
    name: string;
    category: string;
  };
}

/**
 * Preference card photo from API
 */
export interface PreferenceCardPhoto {
  id: string;
  card_id: string;
  photo_url: string;
  caption?: string;
  display_order: number;
  created_at: string;
}

/**
 * Request type for creating a preference card
 */
export interface CreatePreferenceCardRequest {
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: Specialty;
  general_notes?: string;
  setup_notes?: string;
  items: CreateCardItemRequest[];
}

/**
 * Request type for creating a card item
 */
export interface CreateCardItemRequest {
  instrument_id?: string;
  custom_item_name?: string;
  quantity: number;
  size?: string;
  notes?: string;
  category: string;
  display_order: number;
}

/**
 * Request type for updating a preference card
 */
export interface UpdatePreferenceCardRequest {
  title?: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: Specialty;
  general_notes?: string;
  setup_notes?: string;
  items?: UpdateCardItemRequest[];
  deleted_item_ids?: string[];
}

/**
 * Request type for updating/creating card items
 */
export interface UpdateCardItemRequest {
  id?: string; // If provided, update; if not, create
  instrument_id?: string;
  custom_item_name?: string;
  quantity: number;
  size?: string;
  notes?: string;
  category: string;
  display_order: number;
}
