/**
 * Application Constants
 * Environment configuration and static values
 */
import Constants from 'expo-constants';

// API Configuration
export const API_URL = Constants.expoConfig?.extra?.apiUrl || process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000';

// Storage Keys
export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'surgicalprep_access_token',
  REFRESH_TOKEN: 'surgicalprep_refresh_token',
  USER_DATA: 'surgicalprep_user_data',
  ONBOARDING_COMPLETE: 'surgicalprep_onboarding_complete',
  THEME_PREFERENCE: 'surgicalprep_theme',
  QUIZ_SETTINGS: 'surgicalprep_quiz_settings',
  DRAFT_CARD: 'surgicalprep_draft_card',
  RECENT_SEARCHES: 'surgicalprep_recent_searches',
} as const;

// Subscription Tiers
export const SUBSCRIPTION_TIERS = {
  FREE: 'free',
  PREMIUM: 'premium',
} as const;

// Free Tier Limits
export const FREE_TIER_LIMITS = {
  MAX_CARDS: 5,
  MAX_QUIZZES_PER_DAY: 3,
  MAX_INSTRUMENTS_DETAIL: 20,
} as const;

// Pagination
export const PAGINATION = {
  DEFAULT_PAGE_SIZE: 20,
  INSTRUMENTS_PAGE_SIZE: 20,
  CARDS_PAGE_SIZE: 10,
} as const;

// Quiz Configuration
export const QUIZ_CONFIG = {
  DEFAULT_QUESTION_COUNT: 10,
  MIN_QUESTION_COUNT: 5,
  MAX_QUESTION_COUNT: 50,
  TIME_PER_QUESTION_SECONDS: 30,
  FLASHCARD_BATCH_SIZE: 20,
} as const;

// Image Configuration
export const IMAGE_CONFIG = {
  MAX_UPLOAD_SIZE_MB: 5,
  THUMBNAIL_SIZE: 200,
  FULL_SIZE: 800,
  SUPPORTED_FORMATS: ['image/jpeg', 'image/png', 'image/webp'],
} as const;

// Specialties List
export const SPECIALTIES = [
  'General Surgery',
  'Orthopedic',
  'Cardiac/Cardiovascular',
  'Neurosurgery',
  'Plastic Surgery',
  'Urology',
  'OB/GYN',
  'ENT',
  'Ophthalmology',
  'Vascular',
  'Thoracic',
  'Pediatric',
  'Trauma',
  'Transplant',
  'Other',
] as const;

// Instrument Categories
export const INSTRUMENT_CATEGORIES = [
  { key: 'cutting', label: 'Cutting & Dissecting' },
  { key: 'grasping', label: 'Grasping & Holding' },
  { key: 'clamping', label: 'Clamping & Occluding' },
  { key: 'retracting', label: 'Retracting & Exposing' },
  { key: 'suturing', label: 'Suturing & Stapling' },
  { key: 'specialty', label: 'Specialty' },
  { key: 'other', label: 'Other' },
] as const;

// Item Categories for Preference Cards
export const ITEM_CATEGORIES = [
  { key: 'instrument', label: 'Instruments' },
  { key: 'supply', label: 'Supplies' },
  { key: 'suture', label: 'Sutures' },
  { key: 'implant', label: 'Implants/Special' },
  { key: 'other', label: 'Other' },
] as const;

// User Roles
export const USER_ROLES = [
  { key: 'surgical_tech_student', label: 'Surgical Tech Student' },
  { key: 'certified_surgical_tech', label: 'Certified Surgical Technologist' },
  { key: 'or_nurse', label: 'OR Nurse' },
  { key: 'surgical_tech_educator', label: 'Surgical Tech Educator' },
  { key: 'other', label: 'Other' },
] as const;

// Debounce Timings (ms)
export const DEBOUNCE = {
  SEARCH: 300,
  AUTOSAVE: 1000,
  BUTTON_PRESS: 200,
} as const;

// Animation Durations (ms)
export const ANIMATION_DURATION = {
  FAST: 150,
  NORMAL: 250,
  SLOW: 400,
} as const;

// SM-2 Spaced Repetition Constants
export const SM2_CONFIG = {
  INITIAL_EASE_FACTOR: 2.5,
  MIN_EASE_FACTOR: 1.3,
  INITIAL_INTERVAL_DAYS: 1,
  GRADUATING_INTERVAL_DAYS: 6,
} as const;
