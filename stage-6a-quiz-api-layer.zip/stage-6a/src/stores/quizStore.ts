/**
 * Quiz Store
 * SurgicalPrep - Stage 6A
 * 
 * Zustand store for managing active quiz/flashcard session state.
 * Handles local state that doesn't need to be persisted to the server
 * on every change (timer, current question UI state, etc.)
 */

import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

import type {
  QuizSession,
  FlashcardSession,
  QuizQuestion,
  FlashcardItem,
  AnswerResult,
  QuizConfig,
  FlashcardConfig,
  SessionStatus,
} from '../types/quiz';

// =============================================================================
// Types
// =============================================================================

interface QuizSessionState {
  // Active session data
  sessionId: string | null;
  sessionType: 'quiz' | 'flashcard' | null;
  status: SessionStatus | null;
  
  // Quiz-specific state
  quizSession: QuizSession | null;
  currentQuestion: QuizQuestion | null;
  currentQuestionIndex: number;
  selectedAnswer: string | null;
  lastAnswerResult: AnswerResult | null;
  showingFeedback: boolean;
  
  // Flashcard-specific state
  flashcardSession: FlashcardSession | null;
  currentCard: FlashcardItem | null;
  currentCardIndex: number;
  isCardFlipped: boolean;
  
  // Timer state
  timerEnabled: boolean;
  timerSeconds: number;
  timerPaused: boolean;
  questionStartTime: number | null;
  
  // UI state
  isLoading: boolean;
  error: string | null;
  
  // Stats for current session
  correctStreak: number;
  longestStreak: number;
  totalTimeSpent: number;
}

interface QuizActions {
  // Session lifecycle
  initQuizSession: (session: QuizSession, config: QuizConfig) => void;
  initFlashcardSession: (session: FlashcardSession, config: FlashcardConfig) => void;
  clearSession: () => void;
  
  // Quiz actions
  setSelectedAnswer: (optionId: string | null) => void;
  processAnswerResult: (result: AnswerResult) => void;
  nextQuestion: () => void;
  showFeedback: (show: boolean) => void;
  
  // Flashcard actions
  flipCard: () => void;
  nextCard: () => void;
  recordCardResult: (result: 'got_it' | 'study_more') => void;
  
  // Timer actions
  setTimerEnabled: (enabled: boolean) => void;
  startTimer: () => void;
  pauseTimer: () => void;
  resumeTimer: () => void;
  tickTimer: () => void;
  resetTimer: () => void;
  getElapsedTime: () => number;
  
  // State management
  setLoading: (loading: boolean) => void;
  setError: (error: string | null) => void;
  updateSessionStatus: (status: SessionStatus) => void;
}

type QuizStore = QuizSessionState & QuizActions;

// =============================================================================
// Initial State
// =============================================================================

const initialState: QuizSessionState = {
  sessionId: null,
  sessionType: null,
  status: null,
  
  quizSession: null,
  currentQuestion: null,
  currentQuestionIndex: 0,
  selectedAnswer: null,
  lastAnswerResult: null,
  showingFeedback: false,
  
  flashcardSession: null,
  currentCard: null,
  currentCardIndex: 0,
  isCardFlipped: false,
  
  timerEnabled: false,
  timerSeconds: 0,
  timerPaused: false,
  questionStartTime: null,
  
  isLoading: false,
  error: null,
  
  correctStreak: 0,
  longestStreak: 0,
  totalTimeSpent: 0,
};

// =============================================================================
// Store
// =============================================================================

export const useQuizStore = create<QuizStore>()(
  devtools(
    persist(
      (set, get) => ({
        ...initialState,

        // =====================================================================
        // Session Lifecycle
        // =====================================================================

        initQuizSession: (session: QuizSession, config: QuizConfig) => {
          const timerEnabled = !!config.time_limit_seconds;
          set({
            sessionId: session.id,
            sessionType: 'quiz',
            status: 'in_progress',
            quizSession: session,
            currentQuestion: session.questions[0] || null,
            currentQuestionIndex: 0,
            selectedAnswer: null,
            lastAnswerResult: null,
            showingFeedback: false,
            timerEnabled,
            timerSeconds: config.time_limit_seconds || 0,
            timerPaused: false,
            questionStartTime: Date.now(),
            isLoading: false,
            error: null,
            correctStreak: 0,
            longestStreak: 0,
            totalTimeSpent: 0,
          });
        },

        initFlashcardSession: (session: FlashcardSession, _config: FlashcardConfig) => {
          set({
            sessionId: session.id,
            sessionType: 'flashcard',
            status: 'in_progress',
            flashcardSession: session,
            currentCard: session.cards[0] || null,
            currentCardIndex: 0,
            isCardFlipped: false,
            timerEnabled: false,
            questionStartTime: Date.now(),
            isLoading: false,
            error: null,
            totalTimeSpent: 0,
          });
        },

        clearSession: () => {
          set(initialState);
        },

        // =====================================================================
        // Quiz Actions
        // =====================================================================

        setSelectedAnswer: (optionId: string | null) => {
          set({ selectedAnswer: optionId });
        },

        processAnswerResult: (result: AnswerResult) => {
          const state = get();
          const elapsed = state.questionStartTime 
            ? Math.floor((Date.now() - state.questionStartTime) / 1000)
            : 0;
          
          let newStreak = result.is_correct ? state.correctStreak + 1 : 0;
          let newLongestStreak = Math.max(state.longestStreak, newStreak);
          
          set({
            lastAnswerResult: result,
            showingFeedback: true,
            correctStreak: newStreak,
            longestStreak: newLongestStreak,
            totalTimeSpent: state.totalTimeSpent + elapsed,
            timerPaused: true,
          });
        },

        nextQuestion: () => {
          const state = get();
          const session = state.quizSession;
          
          if (!session) return;
          
          const nextIndex = state.currentQuestionIndex + 1;
          const nextQuestion = session.questions[nextIndex] || null;
          const isComplete = nextIndex >= session.total_questions;
          
          set({
            currentQuestionIndex: nextIndex,
            currentQuestion: nextQuestion,
            selectedAnswer: null,
            lastAnswerResult: null,
            showingFeedback: false,
            timerSeconds: state.timerEnabled ? (state.quizSession?.config.time_limit_seconds || 0) : 0,
            timerPaused: false,
            questionStartTime: isComplete ? null : Date.now(),
            status: isComplete ? 'completed' : 'in_progress',
          });
        },

        showFeedback: (show: boolean) => {
          set({ showingFeedback: show });
        },

        // =====================================================================
        // Flashcard Actions
        // =====================================================================

        flipCard: () => {
          set((state) => ({ isCardFlipped: !state.isCardFlipped }));
        },

        nextCard: () => {
          const state = get();
          const session = state.flashcardSession;
          
          if (!session) return;
          
          const nextIndex = state.currentCardIndex + 1;
          const nextCard = session.cards[nextIndex] || null;
          const isComplete = nextIndex >= session.cards.length;
          
          const elapsed = state.questionStartTime 
            ? Math.floor((Date.now() - state.questionStartTime) / 1000)
            : 0;
          
          set({
            currentCardIndex: nextIndex,
            currentCard: nextCard,
            isCardFlipped: false,
            questionStartTime: isComplete ? null : Date.now(),
            totalTimeSpent: state.totalTimeSpent + elapsed,
            status: isComplete ? 'completed' : 'in_progress',
          });
        },

        recordCardResult: (result: 'got_it' | 'study_more') => {
          const state = get();
          const session = state.flashcardSession;
          
          if (!session) return;
          
          // Update local session state
          const updatedSession: FlashcardSession = {
            ...session,
            cards_completed: session.cards_completed + 1,
            cards_got_it: result === 'got_it' ? session.cards_got_it + 1 : session.cards_got_it,
            cards_study_more: result === 'study_more' ? session.cards_study_more + 1 : session.cards_study_more,
          };
          
          set({ flashcardSession: updatedSession });
        },

        // =====================================================================
        // Timer Actions
        // =====================================================================

        setTimerEnabled: (enabled: boolean) => {
          set({ timerEnabled: enabled });
        },

        startTimer: () => {
          const state = get();
          set({
            questionStartTime: Date.now(),
            timerSeconds: state.quizSession?.config.time_limit_seconds || 30,
            timerPaused: false,
          });
        },

        pauseTimer: () => {
          set({ timerPaused: true });
        },

        resumeTimer: () => {
          set({ timerPaused: false });
        },

        tickTimer: () => {
          const state = get();
          if (state.timerPaused || state.timerSeconds <= 0) return;
          
          const newSeconds = state.timerSeconds - 1;
          set({ timerSeconds: newSeconds });
          
          // Timer expired - auto-submit null answer
          if (newSeconds <= 0 && state.sessionType === 'quiz') {
            // This should trigger a timeout submission in the UI
            set({ timerPaused: true });
          }
        },

        resetTimer: () => {
          const state = get();
          set({
            timerSeconds: state.quizSession?.config.time_limit_seconds || 30,
            timerPaused: false,
            questionStartTime: Date.now(),
          });
        },

        getElapsedTime: () => {
          const state = get();
          if (!state.questionStartTime) return 0;
          return Math.floor((Date.now() - state.questionStartTime) / 1000);
        },

        // =====================================================================
        // State Management
        // =====================================================================

        setLoading: (loading: boolean) => {
          set({ isLoading: loading });
        },

        setError: (error: string | null) => {
          set({ error });
        },

        updateSessionStatus: (status: SessionStatus) => {
          set({ status });
        },
      }),
      {
        name: 'quiz-session-storage',
        storage: {
          getItem: async (name) => {
            const value = await AsyncStorage.getItem(name);
            return value ? JSON.parse(value) : null;
          },
          setItem: async (name, value) => {
            await AsyncStorage.setItem(name, JSON.stringify(value));
          },
          removeItem: async (name) => {
            await AsyncStorage.removeItem(name);
          },
        },
        // Only persist session IDs for recovery, not full session data
        partialize: (state) => ({
          sessionId: state.sessionId,
          sessionType: state.sessionType,
          currentQuestionIndex: state.currentQuestionIndex,
          currentCardIndex: state.currentCardIndex,
          totalTimeSpent: state.totalTimeSpent,
          longestStreak: state.longestStreak,
        }),
      }
    ),
    { name: 'QuizStore' }
  )
);

// =============================================================================
// Selectors
// =============================================================================

/**
 * Check if a session is currently active
 */
export const selectHasActiveSession = (state: QuizStore): boolean => 
  state.sessionId !== null && state.status === 'in_progress';

/**
 * Get progress percentage for current session
 */
export const selectSessionProgress = (state: QuizStore): number => {
  if (state.sessionType === 'quiz' && state.quizSession) {
    return (state.currentQuestionIndex / state.quizSession.total_questions) * 100;
  }
  if (state.sessionType === 'flashcard' && state.flashcardSession) {
    return (state.currentCardIndex / state.flashcardSession.cards.length) * 100;
  }
  return 0;
};

/**
 * Get remaining items count
 */
export const selectRemainingItems = (state: QuizStore): number => {
  if (state.sessionType === 'quiz' && state.quizSession) {
    return state.quizSession.total_questions - state.currentQuestionIndex;
  }
  if (state.sessionType === 'flashcard' && state.flashcardSession) {
    return state.flashcardSession.cards.length - state.currentCardIndex;
  }
  return 0;
};

/**
 * Check if current session is complete
 */
export const selectIsSessionComplete = (state: QuizStore): boolean => 
  state.status === 'completed';

/**
 * Get current score percentage
 */
export const selectCurrentScorePercentage = (state: QuizStore): number => {
  if (state.sessionType !== 'quiz' || !state.quizSession) return 0;
  const answered = state.quizSession.answers.length;
  if (answered === 0) return 0;
  return (state.quizSession.score / answered) * 100;
};

/**
 * Get flashcard "got it" rate
 */
export const selectFlashcardGotItRate = (state: QuizStore): number => {
  if (state.sessionType !== 'flashcard' || !state.flashcardSession) return 0;
  const completed = state.flashcardSession.cards_completed;
  if (completed === 0) return 0;
  return (state.flashcardSession.cards_got_it / completed) * 100;
};

// =============================================================================
// Export
// =============================================================================

export default useQuizStore;
