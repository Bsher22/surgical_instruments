-- SurgicalPrep Database Schema
-- Run this in Supabase SQL Editor after creating your project

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- =============================================
-- USERS TABLE
-- =============================================
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    email VARCHAR(255) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    role VARCHAR(50) DEFAULT 'surgical_tech',
    institution VARCHAR(200),
    
    -- Subscription
    subscription_tier VARCHAR(20) DEFAULT 'free',
    subscription_expires_at TIMESTAMPTZ,
    stripe_customer_id VARCHAR(100),
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_users_email ON users(email);

-- =============================================
-- INSTRUMENTS TABLE
-- =============================================
CREATE TABLE instruments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    aliases TEXT[],
    category VARCHAR(100) NOT NULL,
    description TEXT,
    primary_uses TEXT[],
    common_procedures TEXT[],
    handling_notes TEXT,
    image_url VARCHAR(500),
    thumbnail_url VARCHAR(500),
    
    -- Premium flag
    is_premium BOOLEAN DEFAULT FALSE,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_instruments_name ON instruments(name);
CREATE INDEX idx_instruments_category ON instruments(category);

-- Full-text search index
CREATE INDEX idx_instruments_search ON instruments 
    USING GIN (to_tsvector('english', name || ' ' || COALESCE(description, '')));

-- =============================================
-- PREFERENCE CARDS TABLE
-- =============================================
CREATE TABLE preference_cards (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Card info
    title VARCHAR(200) NOT NULL,
    surgeon_name VARCHAR(100),
    procedure_name VARCHAR(200),
    specialty VARCHAR(100),
    
    -- Notes
    general_notes TEXT,
    setup_notes TEXT,
    
    -- Items (JSON array)
    items JSONB DEFAULT '[]'::jsonb,
    
    -- Photos
    photo_urls TEXT[],
    
    -- Flags
    is_template BOOLEAN DEFAULT FALSE,
    is_public BOOLEAN DEFAULT FALSE,
    
    -- Timestamps
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_preference_cards_user ON preference_cards(user_id);
CREATE INDEX idx_preference_cards_specialty ON preference_cards(specialty);

-- =============================================
-- USER INSTRUMENT PROGRESS TABLE
-- =============================================
CREATE TABLE user_instrument_progress (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    instrument_id UUID NOT NULL REFERENCES instruments(id) ON DELETE CASCADE,
    
    -- Spaced repetition (SM-2)
    ease_factor FLOAT DEFAULT 2.5,
    interval_days INTEGER DEFAULT 1,
    repetitions INTEGER DEFAULT 0,
    next_review_at TIMESTAMPTZ,
    
    -- Stats
    times_studied INTEGER DEFAULT 0,
    times_correct INTEGER DEFAULT 0,
    last_studied_at TIMESTAMPTZ,
    
    -- Bookmark
    is_bookmarked BOOLEAN DEFAULT FALSE,
    
    UNIQUE(user_id, instrument_id)
);

CREATE INDEX idx_user_instrument_progress_user ON user_instrument_progress(user_id);
CREATE INDEX idx_user_instrument_progress_review ON user_instrument_progress(next_review_at);

-- =============================================
-- QUIZ SESSIONS TABLE
-- =============================================
CREATE TABLE quiz_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    
    -- Config
    quiz_type VARCHAR(50) NOT NULL,
    category_filter VARCHAR(100),
    question_count INTEGER DEFAULT 10,
    
    -- Results
    score INTEGER,
    total_questions INTEGER,
    time_spent_seconds INTEGER,
    
    -- Status
    status VARCHAR(20) DEFAULT 'in_progress',
    
    -- Questions and answers (JSON)
    questions JSONB,
    answers JSONB,
    
    -- Timestamps
    started_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE INDEX idx_quiz_sessions_user ON quiz_sessions(user_id);
CREATE INDEX idx_quiz_sessions_started ON quiz_sessions(started_at);

-- =============================================
-- ROW LEVEL SECURITY
-- =============================================
-- Enable RLS on user-specific tables
ALTER TABLE preference_cards ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_instrument_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE quiz_sessions ENABLE ROW LEVEL SECURITY;

-- Note: RLS policies depend on your auth setup
-- For API-managed auth (not Supabase Auth), you may skip these
-- or implement custom policies based on your JWT claims

-- =============================================
-- UPDATED_AT TRIGGER
-- =============================================
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_instruments_updated_at
    BEFORE UPDATE ON instruments
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_preference_cards_updated_at
    BEFORE UPDATE ON preference_cards
    FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

-- =============================================
-- SAMPLE DATA (Optional)
-- =============================================
-- Uncomment to add sample instruments

/*
INSERT INTO instruments (name, aliases, category, description, primary_uses, common_procedures, handling_notes, is_premium) VALUES
('Kelly Forceps', ARRAY['Kelly Clamp', 'Kelly Hemostat'], 'Clamps', 
 'Curved or straight hemostatic forceps used for clamping blood vessels and grasping tissue.',
 ARRAY['Clamping blood vessels', 'Grasping tissue', 'Blunt dissection'],
 ARRAY['General Surgery', 'Gynecology', 'Orthopedic'],
 'Available in curved and straight. Check ratchet mechanism before use.', FALSE),

('Metzenbaum Scissors', ARRAY['Metz', 'Metz Scissors'], 'Scissors',
 'Delicate scissors with long handles and short blades, used for cutting fine tissue.',
 ARRAY['Cutting delicate tissue', 'Dissection', 'Undermining'],
 ARRAY['Plastic Surgery', 'General Surgery', 'Gynecology'],
 'Keep tips sharp. Do not use on sutures.', FALSE),

('Debakey Forceps', ARRAY['DeBakey', 'Atraumatic Forceps'], 'Forceps',
 'Atraumatic tissue forceps with multiple fine teeth for gentle tissue handling.',
 ARRAY['Grasping vessels', 'Handling delicate tissue', 'Vascular surgery'],
 ARRAY['Cardiovascular', 'General Surgery', 'Vascular'],
 'Atraumatic design prevents tissue damage. Clean between teeth carefully.', FALSE);
*/
