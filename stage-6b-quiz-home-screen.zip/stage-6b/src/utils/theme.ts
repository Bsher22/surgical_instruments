// ============================================================================
// Theme Configuration & Styling Constants
// ============================================================================

import { Platform } from 'react-native';

// ============================================================================
// Color Palette
// ============================================================================

export const colors = {
  // Primary brand colors
  primary: '#2563EB',       // Blue 600
  primaryDark: '#1D4ED8',   // Blue 700
  primaryLight: '#3B82F6',  // Blue 500

  // Secondary colors
  secondary: '#7C3AED',     // Violet 600
  secondaryDark: '#6D28D9', // Violet 700
  secondaryLight: '#8B5CF6', // Violet 500

  // Semantic colors
  success: '#10B981',       // Emerald 500
  successLight: '#34D399',  // Emerald 400
  successDark: '#059669',   // Emerald 600

  warning: '#F59E0B',       // Amber 500
  warningLight: '#FBBF24',  // Amber 400
  warningDark: '#D97706',   // Amber 600

  error: '#EF4444',         // Red 500
  errorLight: '#F87171',    // Red 400
  errorDark: '#DC2626',     // Red 600

  info: '#0EA5E9',          // Sky 500
  infoLight: '#38BDF8',     // Sky 400
  infoDark: '#0284C7',      // Sky 600

  // Neutral colors
  white: '#FFFFFF',
  black: '#000000',
  
  // Background colors
  background: '#F8FAFC',    // Slate 50
  surface: '#FFFFFF',       // White
  surfaceSecondary: '#F1F5F9', // Slate 100

  // Text colors
  text: '#0F172A',          // Slate 900
  textSecondary: '#475569', // Slate 600
  textTertiary: '#94A3B8',  // Slate 400
  textInverse: '#FFFFFF',   // White

  // Border colors
  border: '#E2E8F0',        // Slate 200
  borderLight: '#F1F5F9',   // Slate 100
  borderDark: '#CBD5E1',    // Slate 300

  // Shadow
  shadow: '#000000',

  // Overlay
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',

  // Transparent
  transparent: 'transparent',
};

// ============================================================================
// Dark Mode Colors (for future implementation)
// ============================================================================

export const darkColors = {
  ...colors,
  background: '#0F172A',    // Slate 900
  surface: '#1E293B',       // Slate 800
  surfaceSecondary: '#334155', // Slate 700

  text: '#F8FAFC',          // Slate 50
  textSecondary: '#CBD5E1', // Slate 300
  textTertiary: '#64748B',  // Slate 500

  border: '#334155',        // Slate 700
  borderLight: '#1E293B',   // Slate 800
  borderDark: '#475569',    // Slate 600
};

// ============================================================================
// Spacing Scale
// ============================================================================

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
} as const;

// ============================================================================
// Border Radius
// ============================================================================

export const borderRadius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
} as const;

// ============================================================================
// Typography
// ============================================================================

export const typography = {
  // Font families
  fonts: {
    regular: Platform.select({
      ios: 'System',
      android: 'Roboto',
    }),
    medium: Platform.select({
      ios: 'System',
      android: 'Roboto-Medium',
    }),
    bold: Platform.select({
      ios: 'System',
      android: 'Roboto-Bold',
    }),
  },

  // Font sizes
  sizes: {
    xs: 12,
    sm: 14,
    md: 16,
    lg: 18,
    xl: 20,
    xxl: 24,
    xxxl: 32,
  },

  // Font weights
  weights: {
    regular: '400' as const,
    medium: '500' as const,
    semibold: '600' as const,
    bold: '700' as const,
  },

  // Line heights
  lineHeights: {
    tight: 1.2,
    normal: 1.5,
    relaxed: 1.75,
  },
} as const;

// ============================================================================
// Shadows
// ============================================================================

export const shadows = {
  sm: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  lg: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
  xl: {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: 8 },
    shadowOpacity: 0.2,
    shadowRadius: 16,
    elevation: 8,
  },
} as const;

// ============================================================================
// Animation Durations
// ============================================================================

export const animations = {
  fast: 150,
  normal: 300,
  slow: 500,
} as const;

// ============================================================================
// Hit Slop (for touch targets)
// ============================================================================

export const hitSlop = {
  top: 10,
  bottom: 10,
  left: 10,
  right: 10,
} as const;

// ============================================================================
// Z-Index Scale
// ============================================================================

export const zIndex = {
  base: 0,
  dropdown: 10,
  sticky: 20,
  fixed: 30,
  modal: 40,
  popover: 50,
  tooltip: 60,
} as const;

// ============================================================================
// Screen Breakpoints
// ============================================================================

export const breakpoints = {
  sm: 320,
  md: 375,
  lg: 428,
  xl: 768, // iPad
} as const;

// ============================================================================
// Helper Functions
// ============================================================================

/**
 * Generate elevation shadow based on level
 */
export function elevationShadow(elevation: number) {
  return {
    shadowColor: colors.shadow,
    shadowOffset: { width: 0, height: elevation },
    shadowOpacity: 0.1 + elevation * 0.03,
    shadowRadius: elevation * 2,
    elevation,
  };
}

/**
 * Get contrasting text color for a background
 */
export function getContrastColor(backgroundColor: string): string {
  // Simple luminance check
  const hex = backgroundColor.replace('#', '');
  const r = parseInt(hex.substr(0, 2), 16);
  const g = parseInt(hex.substr(2, 2), 16);
  const b = parseInt(hex.substr(4, 2), 16);
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  
  return luminance > 0.5 ? colors.text : colors.textInverse;
}

/**
 * Add alpha to a hex color
 */
export function withAlpha(color: string, alpha: number): string {
  if (color.startsWith('rgba')) return color;
  if (color.startsWith('#')) {
    const hex = color.replace('#', '');
    const r = parseInt(hex.substr(0, 2), 16);
    const g = parseInt(hex.substr(2, 2), 16);
    const b = parseInt(hex.substr(4, 2), 16);
    return `rgba(${r}, ${g}, ${b}, ${alpha})`;
  }
  return color;
}
