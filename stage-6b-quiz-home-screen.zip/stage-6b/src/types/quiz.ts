// ============================================================================
// Quiz & Study Types
// ============================================================================

/**
 * User's overall study statistics
 */
export interface StudyStats {
  instrumentsStudied: number;
  totalInstruments: number;
  averageScore: number; // 0-100 percentage
  dueForReviewCount: number;
  studyStreak: number; // consecutive days
  lastStudyDate: string | null; // ISO date string
  totalQuizzesTaken: number;
  totalCorrectAnswers: number;
  totalQuestionsAnswered: number;
}

/**
 * Quiz session types
 */
export type QuizType = 'flashcard' | 'multiple_choice' | 'mixed';

/**
 * Quiz question types
 */
export type QuestionType = 
  | 'image_to_name'      // Show image, pick name
  | 'name_to_use'        // Show name, pick primary use
  | 'image_to_category'; // Show image, pick category

/**
 * Quiz session status
 */
export type QuizSessionStatus = 'in_progress' | 'completed' | 'abandoned';

/**
 * Individual quiz session
 */
export interface QuizSession {
  id: string;
  userId: string;
  quizType: QuizType;
  questionTypes: QuestionType[];
  categoryIds: string[];
  totalQuestions: number;
  correctAnswers: number;
  score: number; // percentage 0-100
  status: QuizSessionStatus;
  timerEnabled: boolean;
  timePerQuestion: number | null; // seconds, null if no timer
  startedAt: string;
  completedAt: string | null;
  createdAt: string;
  updatedAt: string;
}

/**
 * Quiz history item for list display
 */
export interface QuizHistoryItem {
  id: string;
  quizType: QuizType;
  totalQuestions: number;
  correctAnswers: number;
  score: number;
  status: QuizSessionStatus;
  completedAt: string | null;
  createdAt: string;
  categoryNames: string[]; // For display purposes
}

/**
 * Configuration for starting a new quiz
 */
export interface QuizConfig {
  quizType: QuizType;
  questionTypes: QuestionType[];
  categoryIds: string[];
  questionCount: number;
  timerEnabled: boolean;
  timePerQuestion: number; // seconds
}

/**
 * Default quiz configuration
 */
export const DEFAULT_QUIZ_CONFIG: QuizConfig = {
  quizType: 'flashcard',
  questionTypes: ['image_to_name'],
  categoryIds: [], // Empty means all categories
  questionCount: 10,
  timerEnabled: false,
  timePerQuestion: 30,
};

/**
 * Instrument category for filtering
 */
export interface Category {
  id: string;
  name: string;
  instrumentCount: number;
}

/**
 * Instrument due for review (from spaced repetition)
 */
export interface InstrumentForReview {
  id: string;
  name: string;
  imageUrl: string | null;
  categoryId: string;
  categoryName: string;
  lastReviewedAt: string | null;
  nextReviewAt: string;
  masteryLevel: number; // 0-5 SM-2 level
}

/**
 * Daily quiz limit for free tier
 */
export interface QuizLimit {
  dailyLimit: number;
  quizzesUsedToday: number;
  remainingToday: number;
  isPremium: boolean;
  resetsAt: string; // ISO timestamp when limit resets
}

/**
 * API response wrappers
 */
export interface StudyStatsResponse {
  stats: StudyStats;
  quizLimit: QuizLimit;
}

export interface QuizHistoryResponse {
  sessions: QuizHistoryItem[];
  total: number;
  page: number;
  pageSize: number;
  hasMore: boolean;
}

export interface DueForReviewResponse {
  instruments: InstrumentForReview[];
  totalDue: number;
}

export interface CategoriesResponse {
  categories: Category[];
}

/**
 * Quiz question for active session
 */
export interface QuizQuestion {
  id: string;
  questionType: QuestionType;
  instrumentId: string;
  imageUrl: string | null;
  questionText: string;
  options: QuizOption[];
  correctOptionId: string;
}

export interface QuizOption {
  id: string;
  text: string;
  isCorrect: boolean;
}

/**
 * Answer submission
 */
export interface AnswerSubmission {
  questionId: string;
  selectedOptionId: string;
  responseTimeMs: number;
}

/**
 * Answer result from API
 */
export interface AnswerResult {
  isCorrect: boolean;
  correctOptionId: string;
  explanation: string | null;
  nextQuestion: QuizQuestion | null;
  sessionProgress: {
    currentQuestion: number;
    totalQuestions: number;
    correctSoFar: number;
  };
}

/**
 * Quiz session result
 */
export interface QuizResult {
  sessionId: string;
  quizType: QuizType;
  totalQuestions: number;
  correctAnswers: number;
  score: number;
  timeSpent: number; // seconds
  categoryBreakdown: CategoryScoreBreakdown[];
  mistakes: QuizMistake[];
  xpEarned: number;
  streakUpdated: boolean;
  newStreak: number;
}

export interface CategoryScoreBreakdown {
  categoryId: string;
  categoryName: string;
  correct: number;
  total: number;
  percentage: number;
}

export interface QuizMistake {
  questionId: string;
  instrumentId: string;
  instrumentName: string;
  questionType: QuestionType;
  userAnswer: string;
  correctAnswer: string;
}

/**
 * Flashcard specific types
 */
export interface FlashcardItem {
  id: string;
  instrumentId: string;
  front: {
    imageUrl: string | null;
    hint?: string;
  };
  back: {
    name: string;
    aliases: string[];
    description: string;
    primaryUses: string[];
    category: string;
  };
}

export type FlashcardResponse = 'got_it' | 'study_more';

export interface FlashcardResult {
  instrumentId: string;
  response: FlashcardResponse;
  timeSpentMs: number;
}

/**
 * Quick action types for the home screen
 */
export type QuickAction = 'review_due' | 'quick_10' | 'full_quiz';

export interface QuickActionConfig {
  action: QuickAction;
  label: string;
  description: string;
  icon: string;
  quizConfig: Partial<QuizConfig>;
}

export const QUICK_ACTIONS: QuickActionConfig[] = [
  {
    action: 'review_due',
    label: 'Review Due',
    description: 'Study instruments ready for review',
    icon: 'refresh-cw',
    quizConfig: {
      quizType: 'flashcard',
      // categoryIds will be populated with due instruments
    },
  },
  {
    action: 'quick_10',
    label: 'Quick 10',
    description: '10 random flashcards',
    icon: 'zap',
    quizConfig: {
      quizType: 'flashcard',
      questionCount: 10,
    },
  },
  {
    action: 'full_quiz',
    label: 'Full Quiz',
    description: 'Customizable quiz session',
    icon: 'clipboard-list',
    quizConfig: {
      quizType: 'multiple_choice',
    },
  },
];
