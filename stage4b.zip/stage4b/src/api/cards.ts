// Cards API Client - Stage 4A (included for completeness)
import { apiClient } from './client';
import {
  PreferenceCard,
  CardsListParams,
  CardsListResponse,
  UserCardLimits,
} from '../types/cards';

export const cardsApi = {
  /**
   * Get paginated list of user's preference cards
   */
  async getCards(params: CardsListParams = {}): Promise<CardsListResponse> {
    const queryParams = new URLSearchParams();
    
    if (params.search) queryParams.append('search', params.search);
    if (params.specialty) queryParams.append('specialty', params.specialty);
    if (params.page) queryParams.append('page', params.page.toString());
    if (params.limit) queryParams.append('limit', params.limit.toString());

    const queryString = queryParams.toString();
    const url = `/cards${queryString ? `?${queryString}` : ''}`;
    
    const response = await apiClient.get<CardsListResponse>(url);
    return response.data;
  },

  /**
   * Get a single preference card by ID with all items
   */
  async getCard(id: string): Promise<PreferenceCard> {
    const response = await apiClient.get<PreferenceCard>(`/cards/${id}`);
    return response.data;
  },

  /**
   * Get public template cards
   */
  async getTemplates(): Promise<PreferenceCard[]> {
    const response = await apiClient.get<PreferenceCard[]>('/cards/templates');
    return response.data;
  },

  /**
   * Create a new preference card
   */
  async createCard(card: Partial<PreferenceCard>): Promise<PreferenceCard> {
    const response = await apiClient.post<PreferenceCard>('/cards', card);
    return response.data;
  },

  /**
   * Update an existing preference card
   */
  async updateCard(id: string, card: Partial<PreferenceCard>): Promise<PreferenceCard> {
    const response = await apiClient.put<PreferenceCard>(`/cards/${id}`, card);
    return response.data;
  },

  /**
   * Delete a preference card
   */
  async deleteCard(id: string): Promise<void> {
    await apiClient.delete(`/cards/${id}`);
  },

  /**
   * Duplicate a preference card
   */
  async duplicateCard(id: string): Promise<PreferenceCard> {
    const response = await apiClient.post<PreferenceCard>(`/cards/${id}/duplicate`);
    return response.data;
  },

  /**
   * Get user's card limits (for free tier)
   */
  async getCardLimits(): Promise<UserCardLimits> {
    const response = await apiClient.get<UserCardLimits>('/cards/limits');
    return response.data;
  },
};

export default cardsApi;
