# Stage 5C: Item Management

This stage implements comprehensive item management for preference cards, including:

- **ItemSearchModal** - Search and add instruments from the database
- **ItemEditModal** - Edit item details (quantity, size, notes, category)
- **CustomItemForm** - Add custom items not in the database
- **DraggableItemList** - Drag-to-reorder items with swipe-to-delete
- **CardItemRow** - Individual item display with gestures

## Installation

### 1. Install Required Dependencies

```bash
# Drag and drop support
npx expo install react-native-draggable-flatlist

# Gesture handling (likely already installed)
npx expo install react-native-gesture-handler react-native-reanimated

# Async storage for draft persistence
npx expo install @react-native-async-storage/async-storage

# Haptic feedback
npx expo install expo-haptics

# Icons (likely already installed)
npx expo install @expo/vector-icons
```

### 2. Configure Reanimated

Add to your `babel.config.js`:

```javascript
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: ['react-native-reanimated/plugin'], // Must be last
  };
};
```

### 3. Copy Files

Copy the following files to your project:

```
src/
├── components/
│   ├── cards/
│   │   ├── index.ts
│   │   ├── CategoryBadge.tsx
│   │   ├── CardItemRow.tsx
│   │   ├── ItemSearchModal.tsx
│   │   ├── ItemEditModal.tsx
│   │   ├── CustomItemForm.tsx
│   │   └── DraggableItemList.tsx
│   └── ui/
│       └── BottomSheet.tsx
├── types/
│   └── cardItems.ts
├── hooks/
│   └── useCardItems.ts
└── utils/
    └── cardItemHelpers.ts
```

### 4. Connect to Your API

Update `ItemSearchModal.tsx` to use your actual API:

```typescript
// Replace the mock function with your actual API call
import { instrumentsApi } from '../../api/instruments';

async function searchInstruments(params) {
  const response = await instrumentsApi.search(params);
  return {
    data: response.items,
    hasMore: response.has_more,
  };
}
```

## Usage

### Basic Integration in Card Edit Screen

```tsx
import React, { useState } from 'react';
import { View } from 'react-native';
import {
  DraggableItemList,
  ItemSearchModal,
  ItemEditModal,
} from '../components/cards';
import { useCardItems } from '../hooks/useCardItems';
import type { CardItem, InstrumentSearchResult } from '../types/cardItems';

export function CardEditScreen({ cardId, initialItems }) {
  const [showSearchModal, setShowSearchModal] = useState(false);
  const [editingItem, setEditingItem] = useState<CardItem | null>(null);

  const {
    items,
    isModified,
    addInstrument,
    addCustomItem,
    updateItem,
    removeItem,
    reorderItems,
    isInstrumentAdded,
  } = useCardItems({
    cardId,
    initialItems,
  });

  return (
    <View style={{ flex: 1 }}>
      <DraggableItemList
        items={items}
        onReorder={reorderItems}
        onEditItem={(item) => setEditingItem(item)}
        onDeleteItem={(item) => removeItem(item.id)}
        onAddInstrument={() => setShowSearchModal(true)}
        onAddCustomItem={addCustomItem}
      />

      <ItemSearchModal
        visible={showSearchModal}
        onClose={() => setShowSearchModal(false)}
        onAddItem={(instrument, quantity, category) => {
          addInstrument(instrument, quantity, category);
        }}
        isInstrumentAdded={isInstrumentAdded}
      />

      <ItemEditModal
        visible={editingItem !== null}
        item={editingItem}
        onClose={() => setEditingItem(null)}
        onSave={(id, updates) => updateItem(id, updates)}
        onDelete={(id) => removeItem(id)}
      />
    </View>
  );
}
```

### Using the Hook Standalone

```tsx
const {
  items,              // Current items array
  isModified,         // True if items changed from original
  addInstrument,      // Add from database
  addCustomItem,      // Add custom item
  updateItem,         // Update existing item
  removeItem,         // Remove item
  reorderItems,       // Reorder (drag/drop)
  getChanges,         // Get items to sync { toCreate, toUpdate, toDelete }
  markAsSaved,        // Update original reference after save
  saveDraft,          // Save to AsyncStorage
  loadDraft,          // Load from AsyncStorage
  clearDraft,         // Clear saved draft
} = useCardItems({
  cardId: 'card-123',
  initialItems: existingItems,
  onItemsChange: (items) => console.log('Items changed:', items.length),
});
```

### Syncing Changes to Backend

```tsx
const handleSave = async () => {
  const { toCreate, toUpdate, toDelete } = getChanges();

  try {
    // Create new items
    const createdItems = await Promise.all(
      toCreate.map(item => cardsApi.createItem(cardId, draftToCreate(item)))
    );

    // Update existing items
    await Promise.all(
      toUpdate.map(item => cardsApi.updateItem(cardId, item.id, {
        quantity: item.quantity,
        size: item.size,
        notes: item.notes,
        category: item.category,
        sort_order: item.sort_order,
      }))
    );

    // Delete removed items
    await Promise.all(
      toDelete.map(id => cardsApi.deleteItem(cardId, id))
    );

    // Fetch fresh data and update state
    const freshItems = await cardsApi.getItems(cardId);
    markAsSaved(freshItems);
    await clearDraft();
  } catch (error) {
    console.error('Failed to save:', error);
  }
};
```

## Component Props

### DraggableItemList

| Prop | Type | Description |
|------|------|-------------|
| `items` | `CardItem[]` | Array of items to display |
| `onReorder` | `(from, to) => void` | Called when item is dragged to new position |
| `onEditItem` | `(item) => void` | Called when item is tapped |
| `onDeleteItem` | `(item) => void` | Called after swipe-to-delete |
| `onAddInstrument` | `() => void` | Called when "Add from Database" is tapped |
| `onAddCustomItem` | `(data) => Result` | Called when custom item form is submitted |
| `groupByCategory` | `boolean` | Group items by category (disables dragging) |
| `showAddButtons` | `boolean` | Show add buttons at top |

### ItemSearchModal

| Prop | Type | Description |
|------|------|-------------|
| `visible` | `boolean` | Modal visibility |
| `onClose` | `() => void` | Called to close modal |
| `onAddItem` | `(instrument, qty, cat?) => void` | Called when instrument is added |
| `isInstrumentAdded` | `(id) => boolean` | Check if instrument already in list |

### ItemEditModal

| Prop | Type | Description |
|------|------|-------------|
| `visible` | `boolean` | Modal visibility |
| `item` | `CardItem \| null` | Item being edited |
| `onClose` | `() => void` | Called to close modal |
| `onSave` | `(id, updates) => void` | Called when changes are saved |
| `onDelete` | `(id) => void` | Called when delete is confirmed |

## Item Categories

Items are organized into 5 categories:

| Category | Color | Use Case |
|----------|-------|----------|
| `instruments` | Blue (#3B82F6) | Surgical instruments |
| `supplies` | Green (#10B981) | Consumables, disposables |
| `sutures` | Purple (#8B5CF6) | Sutures, needles |
| `implants` | Amber (#F59E0B) | Implants, prosthetics |
| `special` | Red (#EF4444) | Special equipment |

## Features

### Drag to Reorder
- Long press on drag handle to activate
- Haptic feedback on start/end
- Smooth animations with react-native-reanimated

### Swipe to Delete
- Swipe left to reveal delete action
- Threshold-based activation
- Confirmation alert before deletion

### Draft Persistence
- Auto-saves to AsyncStorage every 2 seconds
- Load draft on screen mount
- Clear draft after successful save

### Optimistic Updates
- Immediate UI updates with temp IDs
- Track changes for backend sync
- Rollback support if save fails

## TypeScript Types

All types match the backend Pydantic schemas:

```typescript
interface CardItem {
  id: string;
  card_id: string;
  instrument_id?: string | null;
  custom_name?: string | null;
  quantity: number;
  size?: string | null;
  notes?: string | null;
  category: ItemCategory;
  sort_order: number;
  created_at: string;
  updated_at: string;
  instrument?: { ... } | null;
}
```

## Troubleshooting

### Gestures Not Working
Ensure `GestureHandlerRootView` is at the root of your navigation:

```tsx
import { GestureHandlerRootView } from 'react-native-gesture-handler';

function App() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      <NavigationContainer>
        {/* ... */}
      </NavigationContainer>
    </GestureHandlerRootView>
  );
}
```

### Animations Not Working
Clear cache and rebuild after adding reanimated plugin:

```bash
npx expo start -c
```

### Search Not Returning Results
1. Check API endpoint is configured correctly
2. Ensure minimum 2 characters for search
3. Check network connectivity
