# Stage 6D: Multiple Choice Quiz

This stage implements the complete multiple choice quiz system for SurgicalPrep, including question display, answer selection, timer functionality, immediate feedback, and results tracking.

## 📁 File Structure

```
stage-6d/
├── app/
│   └── (tabs)/
│       └── quiz/
│           ├── session.tsx          # Main quiz session screen
│           └── review.tsx           # Review missed questions screen
├── src/
│   ├── api/
│   │   └── quiz.ts                  # Quiz API client functions
│   ├── components/
│   │   ├── quiz/
│   │   │   ├── index.ts             # Quiz components barrel export
│   │   │   ├── QuizProgressBar.tsx  # Progress indicator
│   │   │   ├── QuizTimer.tsx        # Countdown timer (linear + circular)
│   │   │   ├── AnswerOption.tsx     # Individual answer button
│   │   │   ├── QuizQuestion.tsx     # Question display component
│   │   │   ├── AnswerFeedback.tsx   # Correct/incorrect feedback
│   │   │   └── QuizResults.tsx      # Final results screen
│   │   └── ui/
│   │       └── LoadingSpinner.tsx   # Reusable loading indicator
│   ├── hooks/
│   │   ├── index.ts
│   │   ├── useMultipleChoiceQuiz.ts # Main quiz hook with React Query
│   │   └── useQuizTimer.ts          # Timer management hook
│   ├── stores/
│   │   └── multipleChoiceQuizStore.ts # Zustand store for quiz state
│   └── types/
│       └── quiz.ts                  # TypeScript types for quiz system
└── README.md
```

## 🎯 Features Implemented

### Question Types
- **Image → Name**: Show instrument image, pick correct name
- **Name → Use**: Show instrument name, pick primary use
- **Image → Category**: Show instrument image, pick category

### Core Features
- ✅ Question display with image and text support
- ✅ 4 answer options with A, B, C, D labels
- ✅ Optional countdown timer per question
- ✅ Immediate feedback (correct/incorrect)
- ✅ Explanation display after answering
- ✅ Progress bar with question count
- ✅ Score tracking throughout quiz
- ✅ Results screen with breakdown
- ✅ Review mistakes functionality
- ✅ Category-based performance breakdown

### Animations & UX
- Smooth transitions between questions
- Answer option selection animations
- Shake animation for incorrect answers
- Celebration animation for correct answers
- Timer warning state (color change at 10s)
- Haptic feedback throughout

## 📦 Installation

### 1. Copy Files
Copy the contents of this package to your project:

```bash
# From project root
cp -r stage-6d/app/\(tabs\)/quiz/* mobile/app/\(tabs\)/quiz/
cp -r stage-6d/src/* mobile/src/
```

### 2. Install Dependencies
Ensure these packages are installed:

```bash
cd mobile
npx expo install react-native-reanimated react-native-gesture-handler expo-haptics
```

### 3. Configure Reanimated
In `babel.config.js`:
```js
module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: ['react-native-reanimated/plugin'],
  };
};
```

## 🔌 Integration

### API Client Setup
Ensure your `src/api/client.ts` is configured:

```typescript
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';
import { API_BASE_URL } from '../utils/constants';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: { 'Content-Type': 'application/json' },
});

// Add auth interceptor
apiClient.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('auth_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

### Navigation Setup
Add quiz routes to your tab layout if not already present:

```typescript
// app/(tabs)/quiz/_layout.tsx
import { Stack } from 'expo-router';

export default function QuizLayout() {
  return (
    <Stack>
      <Stack.Screen name="index" options={{ title: 'Quiz' }} />
      <Stack.Screen 
        name="session" 
        options={{ 
          headerShown: true,
          gestureEnabled: false 
        }} 
      />
      <Stack.Screen name="review" options={{ title: 'Review' }} />
    </Stack>
  );
}
```

### Starting a Quiz
From your quiz home screen (`app/(tabs)/quiz/index.tsx`):

```typescript
import { useRouter } from 'expo-router';

const router = useRouter();

// Start with default config
router.push('/(tabs)/quiz/session');

// Start with custom config
router.push({
  pathname: '/(tabs)/quiz/session',
  params: {
    questionCount: '15',
    categories: 'General Surgery,Orthopedic',
    timerEnabled: 'true',
    timerSeconds: '30',
    difficulty: 'medium',
  },
});
```

## 🧪 Backend API Requirements

The quiz system expects these API endpoints:

### POST `/quiz/multiple-choice/start`
Start a new quiz session.

**Request:**
```json
{
  "questionCount": 10,
  "questionTypes": ["image_to_name", "name_to_use", "image_to_category"],
  "categories": ["General Surgery"],
  "difficulty": "medium",
  "timerEnabled": true,
  "timerSeconds": 30
}
```

**Response:**
```json
{
  "sessionId": "uuid",
  "questions": [
    {
      "id": "q1",
      "type": "image_to_name",
      "instrumentId": "inst1",
      "instrumentName": "Kelly Clamp",
      "instrumentImageUrl": "https://...",
      "questionText": "What is this instrument?",
      "options": [
        { "id": "a", "text": "Kelly Clamp", "isCorrect": true },
        { "id": "b", "text": "Mosquito Clamp", "isCorrect": false },
        { "id": "c", "text": "Allis Clamp", "isCorrect": false },
        { "id": "d", "text": "Babcock Clamp", "isCorrect": false }
      ],
      "correctOptionId": "a",
      "explanation": "The Kelly clamp is identified by...",
      "difficulty": "medium",
      "category": "General Surgery"
    }
  ]
}
```

### POST `/quiz/sessions/{sessionId}/answer`
Submit an answer.

**Request:**
```json
{
  "questionId": "q1",
  "selectedOptionId": "a",
  "timeSpentMs": 5230
}
```

**Response:**
```json
{
  "isCorrect": true,
  "correctOptionId": "a",
  "explanation": "The Kelly clamp is identified by...",
  "updatedProgress": {
    "instrumentId": "inst1",
    "newConfidenceLevel": 0.8,
    "nextReviewDate": "2024-01-20T00:00:00Z"
  }
}
```

### POST `/quiz/sessions/{sessionId}/end`
End the quiz and get results.

**Response:**
```json
{
  "result": {
    "sessionId": "uuid",
    "totalQuestions": 10,
    "correctAnswers": 7,
    "incorrectAnswers": 3,
    "score": 70,
    "totalTimeMs": 120000,
    "averageTimePerQuestionMs": 12000,
    "breakdown": [
      { "category": "General Surgery", "correct": 5, "total": 6, "percentage": 83 },
      { "category": "Orthopedic", "correct": 2, "total": 4, "percentage": 50 }
    ],
    "missedQuestions": [...],
    "completedAt": "2024-01-15T14:30:00Z"
  }
}
```

### GET `/quiz/sessions/{sessionId}/missed`
Get missed questions for review.

## 🎨 Customization

### Colors
The quiz uses these primary colors (customizable in each component):
- Primary Blue: `#3B82F6`
- Success Green: `#10B981` / `#22C55E`
- Error Red: `#EF4444` / `#DC2626`
- Warning Yellow: `#F59E0B`
- Text Dark: `#1F2937`
- Text Gray: `#6B7280`

### Timer Settings
Default timer can be adjusted:
```typescript
const config: QuizConfig = {
  timerEnabled: true,
  timerSeconds: 30, // Change default time per question
};
```

### Warning Threshold
Change when timer shows warning:
```typescript
const timer = useQuizTimer({
  warningThreshold: 10, // Seconds before time up
});
```

## 📱 Screen Flow

```
Quiz Home → Start Quiz → Session → (Answer Questions) → Results
                                         ↓
                                    Review Mistakes → Back to Results
```

## ✅ Testing Checklist

- [ ] Quiz loads and displays first question
- [ ] Timer counts down (if enabled)
- [ ] Selecting answer shows feedback
- [ ] Correct/incorrect animations play
- [ ] Continue button advances to next question
- [ ] Progress bar updates correctly
- [ ] Results screen shows accurate score
- [ ] Category breakdown displays correctly
- [ ] Review mistakes loads missed questions
- [ ] Play again restarts quiz
- [ ] Exit button with confirmation works
- [ ] Haptic feedback triggers appropriately
- [ ] Timer warning state activates at threshold

## 🔗 Dependencies on Previous Stages

This stage builds on:
- **Stage 2**: Auth store and API client
- **Stage 3**: Instrument types and API
- **Stage 6A**: Quiz API layer foundation
- **Stage 6B/C**: Flashcard mode (shared components)

## 📝 Notes

1. The quiz store uses Zustand for local state management combined with React Query for API calls
2. Timer state is managed separately to allow pausing during feedback
3. Results are persisted server-side for history tracking
4. The review screen allows navigation to instrument details for further study
