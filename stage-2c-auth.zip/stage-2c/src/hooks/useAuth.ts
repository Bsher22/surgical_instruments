// src/hooks/useAuth.ts
// Convenience hook for authentication operations

import { useCallback, useEffect } from 'react';
import {
  useAuthStore,
  useIsAuthenticated,
  useUser,
  useAuthLoading,
  useAuthError,
  useAuthInitialized,
  useIsPremium,
} from '../stores/authStore';
import { LoginCredentials, SignupData, User } from '../types/auth';

interface UseAuthReturn {
  // State
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  isInitialized: boolean;
  isPremium: boolean;
  error: string | null;

  // Actions
  login: (credentials: LoginCredentials) => Promise<void>;
  signup: (data: SignupData) => Promise<void>;
  logout: () => Promise<void>;
  clearError: () => void;
  refreshSession: () => Promise<boolean>;
}

/**
 * Main authentication hook
 * Provides access to auth state and actions
 */
export function useAuth(): UseAuthReturn {
  const user = useUser();
  const isAuthenticated = useIsAuthenticated();
  const isLoading = useAuthLoading();
  const isInitialized = useAuthInitialized();
  const isPremium = useIsPremium();
  const error = useAuthError();

  const storeLogin = useAuthStore((state) => state.login);
  const storeSignup = useAuthStore((state) => state.signup);
  const storeLogout = useAuthStore((state) => state.logout);
  const storeClearError = useAuthStore((state) => state.clearError);
  const storeRefreshToken = useAuthStore((state) => state.refreshToken);

  // Memoize actions to prevent unnecessary re-renders
  const login = useCallback(
    async (credentials: LoginCredentials) => {
      await storeLogin(credentials);
    },
    [storeLogin]
  );

  const signup = useCallback(
    async (data: SignupData) => {
      await storeSignup(data);
    },
    [storeSignup]
  );

  const logout = useCallback(async () => {
    await storeLogout();
  }, [storeLogout]);

  const clearError = useCallback(() => {
    storeClearError();
  }, [storeClearError]);

  const refreshSession = useCallback(async () => {
    return await storeRefreshToken();
  }, [storeRefreshToken]);

  return {
    user,
    isAuthenticated,
    isLoading,
    isInitialized,
    isPremium,
    error,
    login,
    signup,
    logout,
    clearError,
    refreshSession,
  };
}

/**
 * Hook to initialize auth on app start
 * Should be called once in the root layout
 */
export function useAuthInitializer(): void {
  const initialize = useAuthStore((state) => state.initialize);
  const isInitialized = useAuthInitialized();

  useEffect(() => {
    if (!isInitialized) {
      initialize();
    }
  }, [initialize, isInitialized]);
}

/**
 * Hook to check if user can access premium features
 * Returns loading state while checking
 */
export function usePremiumAccess(): {
  canAccess: boolean;
  isLoading: boolean;
} {
  const isInitialized = useAuthInitialized();
  const isPremium = useIsPremium();

  return {
    canAccess: isPremium,
    isLoading: !isInitialized,
  };
}

/**
 * Hook for checking feature limits (free tier)
 */
export function useFeatureLimit(
  currentCount: number,
  maxCount: number
): {
  remaining: number;
  isAtLimit: boolean;
  canUseFeature: boolean;
  isPremium: boolean;
} {
  const isPremium = useIsPremium();

  if (isPremium) {
    return {
      remaining: Infinity,
      isAtLimit: false,
      canUseFeature: true,
      isPremium: true,
    };
  }

  const remaining = Math.max(0, maxCount - currentCount);

  return {
    remaining,
    isAtLimit: remaining === 0,
    canUseFeature: remaining > 0,
    isPremium: false,
  };
}

/**
 * Hook for getting auth header
 * Useful for manual API calls
 */
export function useAuthHeader(): { Authorization: string } | {} {
  const tokens = useAuthStore((state) => state.tokens);

  if (!tokens?.access_token) {
    return {};
  }

  return {
    Authorization: `Bearer ${tokens.access_token}`,
  };
}

export default useAuth;
