import apiClient from './client';
import { ENDPOINTS } from '@/utils/constants';
import { Instrument, InstrumentSearchParams, PaginatedResponse } from '@/types';

export const instrumentsApi = {
  async getInstruments(params?: InstrumentSearchParams): Promise<PaginatedResponse<Instrument>> {
    const response = await apiClient.get<PaginatedResponse<Instrument>>(ENDPOINTS.instruments, {
      params: {
        page: params?.page || 1,
        limit: params?.limit || 20,
        category: params?.category,
        q: params?.query,
      },
    });
    return response.data;
  },

  async getInstrument(id: string): Promise<Instrument> {
    const response = await apiClient.get<Instrument>(`${ENDPOINTS.instruments}/${id}`);
    return response.data;
  },

  async searchInstruments(query: string, limit?: number): Promise<Instrument[]> {
    const response = await apiClient.get<Instrument[]>(ENDPOINTS.instrumentSearch, {
      params: { q: query, limit: limit || 10 },
    });
    return response.data;
  },
};
