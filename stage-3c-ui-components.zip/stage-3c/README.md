# Stage 3C: UI Components for Instruments

This package contains reusable UI components for the SurgicalPrep Instruments feature.

## Overview

Stage 3C focuses on building the foundational UI components that will be used throughout the Instruments browsing feature. These components are designed to be:

- **Reusable** - Used across list screens, detail screens, and search results
- **Accessible** - Proper accessibility labels and touch targets
- **Performant** - Optimized animations and skeleton loading states
- **Styled consistently** - Following the app's design system

---

## Components Included

### 1. InstrumentCard (`InstrumentCard.tsx`)

Displays an instrument preview in list views.

**Features:**
- 80x80 thumbnail image with fallback placeholder
- Instrument name (2-line max with ellipsis)
- Optional alias display
- Color-coded category badge
- Touch feedback and accessibility labels

**Props:**
```typescript
interface InstrumentCardProps {
  instrument: Instrument;
  onPress: (instrument: Instrument) => void;
}
```

**Usage:**
```tsx
import { InstrumentCard } from '@/components';

<InstrumentCard 
  instrument={instrument} 
  onPress={(inst) => router.push(`/instruments/${inst.id}`)} 
/>
```

---

### 2. SearchBar (`SearchBar.tsx`)

Debounced search input with clear functionality.

**Features:**
- 300ms debounce (configurable)
- Clear button appears when text is entered
- Search icon prefix
- Submit on keyboard "Search" button
- Controlled or uncontrolled modes

**Props:**
```typescript
interface SearchBarProps {
  placeholder?: string;        // Default: "Search instruments..."
  onSearch: (query: string) => void;
  debounceMs?: number;         // Default: 300
  autoFocus?: boolean;         // Default: false
  value?: string;              // For controlled mode
}
```

**Usage:**
```tsx
import { SearchBar } from '@/components';

<SearchBar 
  placeholder="Search by name or alias..."
  onSearch={(query) => setSearchQuery(query)}
  debounceMs={300}
/>
```

---

### 3. CategoryChip & CategoryChipList (`CategoryChip.tsx`)

Toggleable filter pills for category selection.

**CategoryChip Props:**
```typescript
interface CategoryChipProps {
  label: string;
  selected: boolean;
  onPress: () => void;
  count?: number;    // Optional item count badge
}
```

**CategoryChipList Props:**
```typescript
interface CategoryChipListProps {
  categories: Array<{ id: string; label: string; count?: number }>;
  selectedIds: string[];
  onToggle: (id: string) => void;
  showAllOption?: boolean;  // Default: true
  allLabel?: string;        // Default: "All"
}
```

**Usage:**
```tsx
import { CategoryChipList } from '@/components';
import { INSTRUMENT_CATEGORIES } from '@/types';

const [selectedCategories, setSelectedCategories] = useState<string[]>([]);

const handleToggle = (id: string) => {
  setSelectedCategories(prev => 
    prev.includes(id) 
      ? prev.filter(c => c !== id)
      : [...prev, id]
  );
};

<CategoryChipList
  categories={INSTRUMENT_CATEGORIES}
  selectedIds={selectedCategories}
  onToggle={handleToggle}
/>
```

---

### 4. Loading Skeletons (`LoadingSkeleton.tsx`)

Shimmer-animated placeholders for loading states.

**Components:**
- `Skeleton` - Base skeleton with configurable dimensions
- `InstrumentCardSkeleton` - Matches InstrumentCard layout
- `InstrumentListSkeleton` - Full list with search, chips, and cards
- `CardDetailSkeleton` - Detail page skeleton

**Usage:**
```tsx
import { InstrumentListSkeleton, InstrumentCardSkeleton } from '@/components';

// Full list loading state
if (isLoading) {
  return <InstrumentListSkeleton count={5} />;
}

// Individual card skeleton
<InstrumentCardSkeleton />

// Custom skeleton
<Skeleton width={100} height={20} borderRadius={4} />
```

---

### 5. EmptyState (`EmptyState.tsx`)

Placeholder for empty lists with optional action.

**Pre-configured States:**
- `NoInstrumentsFound` - For empty search results
- `NoCardsYet` - For empty preference cards list
- `NoQuizHistory` - For empty quiz history
- `NoBookmarks` - For empty bookmarks list

**Usage:**
```tsx
import { EmptyState, NoInstrumentsFound } from '@/components';

// Using pre-configured state
if (instruments.length === 0) {
  return <NoInstrumentsFound />;
}

// Custom empty state
<EmptyState
  icon="flask-outline"
  title="No results"
  message="Try a different search term"
  action={<Button onPress={handleReset}>Clear filters</Button>}
/>
```

---

## File Structure

```
src/
├── components/
│   ├── index.ts              # Barrel exports
│   ├── InstrumentCard.tsx    # Instrument list item
│   ├── SearchBar.tsx         # Debounced search input
│   ├── CategoryChip.tsx      # Filter chips
│   ├── LoadingSkeleton.tsx   # Skeleton loaders
│   └── EmptyState.tsx        # Empty state placeholders
└── types/
    └── index.ts              # TypeScript type definitions
```

---

## Dependencies

These components require:

```json
{
  "expo": "~50.x",
  "@expo/vector-icons": "included with expo",
  "react-native-reanimated": "for advanced animations (optional)"
}
```

The `Ionicons` from `@expo/vector-icons` is used for icons.

---

## Category Color Mapping

Each instrument category has an associated color scheme:

| Category    | Background | Text      |
|-------------|------------|-----------|
| Cutting     | `#FEE2E2`  | `#DC2626` |
| Clamping    | `#DBEAFE`  | `#2563EB` |
| Grasping    | `#D1FAE5`  | `#059669` |
| Retracting  | `#FEF3C7`  | `#D97706` |
| Suturing    | `#E9D5FF`  | `#7C3AED` |
| Suctioning  | `#CFFAFE`  | `#0891B2` |
| Dilating    | `#FCE7F3`  | `#DB2777` |
| Probing     | `#F3E8FF`  | `#9333EA` |
| Measuring   | `#ECFCCB`  | `#65A30D` |
| Specialty   | `#E0E7FF`  | `#4F46E5` |

---

## Setup Notes

1. **Placeholder Image**: Create an `assets/placeholder-instrument.png` file (recommended 160x160px) for instruments without images.

2. **Font Scaling**: Components respect system font scaling for accessibility.

3. **Dark Mode**: Currently styled for light mode. Dark mode support planned for Stage 10.

---

## Next Steps

After Stage 3C, continue with:
- **Stage 3A**: Instruments API layer with React Query hooks
- **Stage 3B**: Instrument List screen implementation
- **Stage 3D**: Instrument Detail screen

These components will be assembled in the list and detail screens.
