# Stage 2B: API Client

This stage sets up the API client layer for SurgicalPrep, including typed axios client, React Query integration, and all API modules.

## Files Included

```
src/
├── api/
│   ├── index.ts          # Main exports
│   ├── client.ts         # Axios client with interceptors
│   ├── auth.ts           # Authentication endpoints
│   ├── instruments.ts    # Instruments CRUD
│   ├── cards.ts          # Preference cards CRUD
│   └── quiz.ts           # Quiz & study endpoints
├── types/
│   └── index.ts          # TypeScript types (matches backend Pydantic schemas)
├── providers/
│   └── QueryProvider.tsx # React Query provider with config
├── hooks/
│   ├── index.ts          # Hook exports
│   ├── useAuth.ts        # Auth React Query hooks
│   └── useInstruments.ts # Instruments React Query hooks
└── utils/
    └── constants.ts      # API URLs, limits, config
```

## Setup

### 1. Install Dependencies

```bash
cd mobile
npx expo install axios @tanstack/react-query expo-secure-store
```

### 2. Copy Files

Copy the `src/` folder contents into your `mobile/src/` directory.

### 3. Configure Environment

Create or update `.env.local`:

```bash
EXPO_PUBLIC_API_URL=http://localhost:8000
```

For production, use your Railway/Render URL.

### 4. Add QueryProvider to App

In your root layout (`app/_layout.tsx`):

```tsx
import { QueryProvider } from '../src/providers/QueryProvider';

export default function RootLayout() {
  return (
    <QueryProvider>
      {/* ... rest of your app */}
    </QueryProvider>
  );
}
```

## Usage Examples

### Making API Calls with Hooks

```tsx
import { useInstruments, useInstrument } from '../src/hooks';

function InstrumentList() {
  const { data, isLoading, error } = useInstruments({ category: 'cutting' });
  
  if (isLoading) return <Text>Loading...</Text>;
  if (error) return <Text>Error: {error.detail}</Text>;
  
  return (
    <FlatList
      data={data?.items}
      renderItem={({ item }) => <Text>{item.name}</Text>}
    />
  );
}
```

### Direct API Calls

```tsx
import { instrumentsApi } from '../src/api';

async function searchInstruments(query: string) {
  try {
    const results = await instrumentsApi.searchInstruments({ query, limit: 10 });
    return results;
  } catch (error) {
    console.error('Search failed:', error.detail);
  }
}
```

### Infinite Scroll

```tsx
import { useInfiniteInstruments } from '../src/hooks';

function InstrumentList() {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useInfiniteInstruments();

  const instruments = data?.pages.flatMap(page => page.items) ?? [];

  return (
    <FlatList
      data={instruments}
      onEndReached={() => hasNextPage && fetchNextPage()}
      // ...
    />
  );
}
```

## Key Features

### Token Management
- Tokens stored securely in expo-secure-store
- Automatic token refresh on 401 responses
- Request queue during refresh to prevent race conditions

### React Query Configuration
- 5-minute stale time (data stays fresh)
- 30-minute cache time (unused data removed)
- Automatic retry with exponential backoff
- Query key factory for consistent cache keys

### Type Safety
- All API responses are fully typed
- Types match backend Pydantic schemas
- Autocomplete works throughout

## Query Keys

Use the `queryKeys` factory for cache management:

```tsx
import { queryClient, queryKeys } from '../src/providers/QueryProvider';

// Invalidate all instrument queries
queryClient.invalidateQueries({ queryKey: queryKeys.instruments.all });

// Invalidate specific instrument
queryClient.invalidateQueries({ queryKey: queryKeys.instruments.detail('123') });

// Prefetch data
queryClient.prefetchQuery({
  queryKey: queryKeys.instruments.detail('123'),
  queryFn: () => instrumentsApi.getInstrument('123'),
});
```

## Next Steps

After Stage 2B, proceed to:
- **Stage 2C**: Auth store with Zustand
- **Stage 2D**: Auth screens (Login/Signup)
