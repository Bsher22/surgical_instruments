import { useCallback } from 'react';
import { useAuthStore } from '../stores/authStore';
import { SignupRequest } from '../types';

/**
 * useAuth Hook
 *
 * Provides a clean interface to authentication functionality.
 * Wraps the Zustand auth store with convenient methods.
 */
export function useAuth() {
  // Select state from store
  const user = useAuthStore((state) => state.user);
  const isLoading = useAuthStore((state) => state.isLoading);
  const isAuthenticated = useAuthStore((state) => state.isAuthenticated);
  const isInitialized = useAuthStore((state) => state.isInitialized);
  const accessToken = useAuthStore((state) => state.accessToken);

  // Select actions from store
  const loginAction = useAuthStore((state) => state.login);
  const signupAction = useAuthStore((state) => state.signup);
  const logoutAction = useAuthStore((state) => state.logout);
  const initializeAction = useAuthStore((state) => state.initialize);
  const setUserAction = useAuthStore((state) => state.setUser);
  const refreshSessionAction = useAuthStore((state) => state.refreshSession);

  /**
   * Login with email and password
   */
  const login = useCallback(
    async (email: string, password: string) => {
      await loginAction(email, password);
    },
    [loginAction]
  );

  /**
   * Create new account
   */
  const signup = useCallback(
    async (data: SignupRequest) => {
      await signupAction(data);
    },
    [signupAction]
  );

  /**
   * Logout current user
   */
  const logout = useCallback(async () => {
    await logoutAction();
  }, [logoutAction]);

  /**
   * Initialize auth state (call on app start)
   */
  const initialize = useCallback(async () => {
    await initializeAction();
  }, [initializeAction]);

  /**
   * Refresh the current session
   */
  const refreshSession = useCallback(async () => {
    return await refreshSessionAction();
  }, [refreshSessionAction]);

  /**
   * Check if user has premium subscription
   */
  const isPremium = user?.subscription_tier === 'premium';

  /**
   * Check if premium subscription is active (not expired)
   */
  const isPremiumActive =
    isPremium &&
    user?.subscription_expires_at &&
    new Date(user.subscription_expires_at) > new Date();

  return {
    // State
    user,
    isLoading,
    isAuthenticated,
    isInitialized,
    accessToken,
    isPremium,
    isPremiumActive,

    // Actions
    login,
    signup,
    logout,
    initialize,
    refreshSession,
    setUser: setUserAction,
  };
}
