# Stage 9: Content Population - Detailed Outline

## Overview

Stage 9 focuses on populating the SurgicalPrep database with production-ready content, including 200+ surgical instruments with comprehensive details and 10-15 template preference cards for common procedures.

**Goal**: Production-ready instrument database and template content

**Estimated Time**: 8-12 hours (can be parallelized)

---

## 9A: Content Gathering

### Objectives
- Compile a comprehensive list of 200-300 surgical instruments
- Organize instruments by specialty and category
- Document complete information for each instrument

### Instrument Data Structure
Each instrument requires:
```json
{
  "name": "Kelly Hemostatic Forceps",
  "aliases": ["Kelly Clamp", "Kelly Hemostat"],
  "category": "Clamps & Forceps",
  "description": "A locking hemostatic forceps used to clamp blood vessels...",
  "primary_uses": ["Clamping blood vessels", "Grasping tissue", "Holding sutures"],
  "common_procedures": ["General Surgery", "Vascular Surgery", "Gynecologic Surgery"],
  "handling_notes": "Available in curved and straight varieties. Check locking mechanism...",
  "is_premium": false
}
```

### Content Organization by Specialty

| Specialty | Target Count | Priority |
|-----------|--------------|----------|
| General Surgery | 50-60 | High |
| Orthopedic | 40-50 | High |
| OB/GYN | 25-30 | High |
| Cardiovascular | 25-30 | Medium |
| Neurosurgery | 20-25 | Medium |
| Plastic Surgery | 15-20 | Medium |
| Urology | 15-20 | Medium |
| ENT | 15-20 | Low |
| Ophthalmology | 10-15 | Low |
| Other/General | 20-30 | Low |

### Categories
1. **Cutting & Dissecting** - Scalpels, scissors, osteotomes
2. **Clamps & Forceps** - Hemostats, tissue forceps, towel clamps
3. **Grasping & Holding** - Allis clamps, Babcock forceps, sponge sticks
4. **Retractors** - Self-retaining, handheld, specialty
5. **Suturing** - Needle holders, suture scissors
6. **Probes & Dilators** - Sounds, probes, dilators
7. **Specialty** - Procedure-specific instruments
8. **Powered** - Drills, saws, dermatomes

### Data Sources (for reference only)
- Medical supply catalogs (Sklar, Integra, V. Mueller)
- Surgical technology textbooks
- Hospital instrument count sheets
- Professional associations (AST, AORN)

---

## 9B: Image Pipeline

### Image Requirements
- **Primary Image**: 800x600 pixels, white/neutral background
- **Thumbnail**: 400x300 pixels (auto-generated)
- **Format**: PNG or WebP preferred, JPEG acceptable
- **File Size**: < 100KB after optimization
- **Naming Convention**: `instrument_slug_primary.png`

### Image Processing Workflow

```
1. Source Image Acquisition
   ↓
2. Background Removal/Standardization
   ↓
3. Resize to 800x600 (maintain aspect ratio)
   ↓
4. Generate 400x300 thumbnail
   ↓
5. Optimize file size (TinyPNG, ImageOptim)
   ↓
6. Upload to Supabase Storage
   ↓
7. Record public URLs in database
```

### Supabase Storage Structure
```
instrument-images/
├── primary/
│   ├── kelly-hemostatic-forceps.png
│   ├── mayo-scissors.png
│   └── ...
└── thumbnails/
    ├── kelly-hemostatic-forceps.png
    ├── mayo-scissors.png
    └── ...
```

### Image Upload Script Features
- Batch upload with progress tracking
- Automatic thumbnail generation
- URL generation and recording
- Duplicate detection
- Error handling and retry logic

---

## 9C: Database Seeding

### Seed Script Architecture

```
backend/scripts/
├── seed_instruments.py      # Main instrument seeding
├── seed_templates.py        # Template preference cards
├── image_processor.py       # Image processing utilities
├── upload_images.py         # Supabase storage upload
└── data/
    ├── instruments.json     # Master instrument data
    ├── instruments.csv      # Alternative CSV format
    ├── templates.json       # Template card definitions
    └── images/              # Source images folder
```

### Seeding Process

1. **Validation Phase**
   - Parse JSON/CSV data
   - Validate required fields
   - Check for duplicates
   - Verify image file existence

2. **Image Processing Phase**
   - Process and optimize images
   - Upload to Supabase Storage
   - Generate and store URLs

3. **Database Insert Phase**
   - Batch insert instruments
   - Update with image URLs
   - Create search vectors for full-text search

4. **Verification Phase**
   - Count inserted records
   - Verify image URLs accessible
   - Test search functionality

### Running the Seeds

```bash
# Full seeding (instruments + images + templates)
python -m scripts.seed_instruments --full

# Instruments only (no images)
python -m scripts.seed_instruments --data-only

# Images only (assumes instruments exist)
python -m scripts.upload_images

# Template cards only
python -m scripts.seed_templates

# Verify seeding
python -m scripts.verify_seed
```

### Rollback Strategy
```bash
# Remove all seeded data
python -m scripts.seed_instruments --rollback

# Remove specific batch
python -m scripts.seed_instruments --rollback --batch="2024-01-15"
```

---

## 9D: Template Preference Cards

### Target Templates (10-15 cards)

| Procedure | Specialty | Priority |
|-----------|-----------|----------|
| Laparoscopic Cholecystectomy | General Surgery | High |
| Open Appendectomy | General Surgery | High |
| Total Knee Arthroplasty | Orthopedic | High |
| Total Hip Arthroplasty | Orthopedic | High |
| Cesarean Section | OB/GYN | High |
| Laparoscopic Hysterectomy | OB/GYN | High |
| Inguinal Hernia Repair | General Surgery | Medium |
| Carpal Tunnel Release | Orthopedic | Medium |
| Laparoscopic Appendectomy | General Surgery | Medium |
| Breast Lumpectomy | General Surgery | Medium |
| Rotator Cuff Repair | Orthopedic | Low |
| Tonsillectomy | ENT | Low |
| Cataract Extraction | Ophthalmology | Low |

### Template Card Structure

```json
{
  "title": "Laparoscopic Cholecystectomy",
  "surgeon_name": "Template",
  "procedure_name": "Laparoscopic Cholecystectomy",
  "specialty": "General Surgery",
  "is_template": true,
  "is_public": true,
  "general_notes": "Standard lap chole setup...",
  "setup_notes": "Mayo stand: clip appliers, graspers...",
  "items": [
    {
      "instrument_id": "uuid-of-instrument",
      "custom_name": null,
      "quantity": 2,
      "size": "5mm",
      "notes": "One for camera, one for working",
      "category": "instruments",
      "position": 1
    }
  ]
}
```

### Template Features
- Marked as `is_template = true` and `is_public = true`
- No `user_id` association (system-owned)
- Includes typical item counts and sizes
- General and setup notes with standard practices
- Can be duplicated by users to customize

---

## Implementation Files

### File Structure
```
stage9_content_population/
├── STAGE_9_OUTLINE.md           # This document
├── README.md                    # Setup and usage instructions
├── backend/
│   └── scripts/
│       ├── __init__.py
│       ├── seed_instruments.py  # Main seeding script
│       ├── seed_templates.py    # Template card seeding
│       ├── image_processor.py   # Image utilities
│       ├── upload_images.py     # Supabase upload
│       ├── verify_seed.py       # Verification script
│       └── data/
│           ├── instruments.json # Instrument data (200+)
│           ├── templates.json   # Template cards
│           └── categories.json  # Category definitions
└── docs/
    ├── content_guidelines.md    # Writing standards
    └── image_guidelines.md      # Image specifications
```

---

## Quality Checklist

### Instrument Data Quality
- [ ] All required fields populated
- [ ] Descriptions 2-4 sentences, clinically accurate
- [ ] At least 3 primary uses per instrument
- [ ] Common procedures list relevant specialties
- [ ] Aliases include common nicknames/abbreviations
- [ ] Handling notes include safety considerations
- [ ] No duplicate entries
- [ ] Consistent capitalization and formatting

### Image Quality
- [ ] Clear, high-resolution source images
- [ ] Consistent white/neutral backgrounds
- [ ] Proper orientation (horizontal preferred)
- [ ] File size optimized (< 100KB)
- [ ] Correct dimensions (800x600 / 400x300)
- [ ] No watermarks or copyrighted content

### Template Cards Quality
- [ ] Accurate instrument lists for procedures
- [ ] Realistic quantities and sizes
- [ ] Helpful setup notes
- [ ] Items properly categorized
- [ ] Covers high-demand procedures

---

## Testing & Verification

### Data Integrity Tests
```python
# Run verification script
python -m scripts.verify_seed

# Checks performed:
# - Total instrument count >= 200
# - All instruments have required fields
# - No duplicate names
# - All image URLs accessible
# - Full-text search returns results
# - Template cards link to valid instruments
```

### Manual Verification
1. Browse instruments in app - verify images load
2. Search for common terms - verify results
3. Filter by category - verify accuracy
4. Open template cards - verify items display
5. Duplicate a template - verify full data copied

---

## Rollout Strategy

### Phase 1: Core Instruments (100)
- General Surgery instruments
- Common across specialties
- Highest-priority items

### Phase 2: Specialty Expansion (100+)
- Orthopedic specialty instruments
- OB/GYN specialty instruments
- Cardiovascular specialty instruments

### Phase 3: Templates & Polish
- All template preference cards
- Image optimization pass
- Data accuracy review

---

## Maintenance Plan

### Adding New Instruments
```bash
# Add single instrument
python -m scripts.seed_instruments --add --file=new_instrument.json

# Add batch
python -m scripts.seed_instruments --add --file=new_instruments.json
```

### Updating Existing Data
```bash
# Update instrument by ID
python -m scripts.seed_instruments --update --id=uuid --file=updates.json

# Bulk update from CSV
python -m scripts.seed_instruments --update --file=updates.csv
```

### Content Expansion Roadmap
- Month 2: Add 100 more specialty instruments
- Month 3: Add video demonstrations (premium)
- Month 4: User-submitted instruments (moderated)
- Month 6: International instrument naming/localization
