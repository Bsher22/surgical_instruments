// User types
export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'tech' | 'nurse' | 'educator' | 'other';
  institution?: string;
  is_premium: boolean;
  premium_expires_at?: string;
  created_at: string;
  updated_at: string;
}

// Instrument types
export type InstrumentCategory =
  | 'cutting'
  | 'clamping'
  | 'grasping'
  | 'retracting'
  | 'suturing'
  | 'suctioning'
  | 'dilating'
  | 'probing'
  | 'measuring'
  | 'specialty';

export interface Instrument {
  id: string;
  name: string;
  aliases: string[];
  category: InstrumentCategory;
  description: string;
  primary_uses: string[];
  common_procedures: string[];
  handling_notes?: string;
  image_url?: string;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

export interface InstrumentListParams {
  page?: number;
  limit?: number;
  category?: InstrumentCategory;
  search?: string;
  is_premium?: boolean;
}

export interface InstrumentListResponse {
  items: Instrument[];
  total: number;
  page: number;
  limit: number;
  has_more: boolean;
}

// Preference Card types
export type CardItemCategory = 'instruments' | 'supplies' | 'sutures' | 'implants' | 'other';

export interface CardItem {
  id: string;
  card_id: string;
  instrument_id?: string;
  name: string;
  quantity?: number;
  size?: string;
  notes?: string;
  category: CardItemCategory;
  order_index: number;
  instrument?: Instrument;
}

export interface PreferenceCard {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: string;
  notes?: string;
  setup_notes?: string;
  setup_photos: string[];
  is_template: boolean;
  is_public: boolean;
  items: CardItem[];
  created_at: string;
  updated_at: string;
}

export interface PreferenceCardListParams {
  page?: number;
  limit?: number;
  search?: string;
  specialty?: string;
  is_template?: boolean;
}

// Quiz types
export type QuizQuestionType = 'image_to_name' | 'name_to_use' | 'image_to_category';

export interface QuizQuestion {
  id: string;
  type: QuizQuestionType;
  instrument: Instrument;
  options: string[];
  correct_answer: string;
}

export interface QuizSession {
  id: string;
  user_id: string;
  questions: QuizQuestion[];
  current_index: number;
  score: number;
  total_questions: number;
  started_at: string;
  completed_at?: string;
}

export interface QuizResult {
  session_id: string;
  score: number;
  total: number;
  percentage: number;
  time_taken_seconds: number;
  mistakes: Array<{
    question: QuizQuestion;
    user_answer: string;
  }>;
}

// Study Progress types
export interface InstrumentProgress {
  id: string;
  user_id: string;
  instrument_id: string;
  times_studied: number;
  times_correct: number;
  times_incorrect: number;
  last_studied_at?: string;
  next_review_at?: string;
  ease_factor: number;
  interval_days: number;
  is_bookmarked: boolean;
  instrument?: Instrument;
}

export interface StudyStats {
  instruments_studied: number;
  total_quiz_sessions: number;
  average_score: number;
  current_streak: number;
  due_for_review: number;
}

// API Response types
export interface ApiError {
  detail: string;
  code?: string;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  has_more: boolean;
}

// Category metadata for filters
export interface CategoryMeta {
  id: InstrumentCategory;
  label: string;
  count?: number;
}

export const INSTRUMENT_CATEGORIES: CategoryMeta[] = [
  { id: 'cutting', label: 'Cutting' },
  { id: 'clamping', label: 'Clamping' },
  { id: 'grasping', label: 'Grasping' },
  { id: 'retracting', label: 'Retracting' },
  { id: 'suturing', label: 'Suturing' },
  { id: 'suctioning', label: 'Suctioning' },
  { id: 'dilating', label: 'Dilating' },
  { id: 'probing', label: 'Probing' },
  { id: 'measuring', label: 'Measuring' },
  { id: 'specialty', label: 'Specialty' },
];
