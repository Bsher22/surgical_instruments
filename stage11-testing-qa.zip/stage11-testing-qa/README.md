# Stage 11: Testing & QA Package

This package contains everything needed to implement comprehensive testing for the SurgicalPrep application.

## Package Contents

```
stage11-testing-qa/
├── STAGE_11_OUTLINE.md          # Detailed implementation outline
├── .env.test                     # Test environment configuration
│
├── backend/
│   ├── tests/
│   │   ├── __init__.py
│   │   ├── conftest.py          # Pytest fixtures and configuration
│   │   ├── test_auth.py         # Authentication endpoint tests
│   │   ├── test_users.py        # User management tests
│   │   ├── test_instruments.py  # Instrument CRUD tests
│   │   ├── test_preference_cards.py  # Preference card tests
│   │   ├── test_quiz.py         # Quiz session tests
│   │   ├── test_study_progress.py    # Spaced repetition tests
│   │   └── test_premium.py      # Premium gating tests
│   ├── pytest.ini               # Pytest configuration
│   └── requirements-test.txt    # Test dependencies
│
├── mobile/
│   ├── __tests__/
│   │   ├── setup.ts             # Jest setup with mocks
│   │   ├── utils/
│   │   │   └── test-utils.tsx   # Custom render and factories
│   │   ├── mocks/
│   │   │   ├── handlers.ts      # MSW API handlers
│   │   │   └── server.ts        # MSW server setup
│   │   ├── components/
│   │   │   ├── InstrumentCard.test.tsx
│   │   │   ├── FlashCard.test.tsx
│   │   │   └── QuizQuestion.test.tsx
│   │   ├── stores/
│   │   │   └── authStore.test.ts
│   │   └── screens/
│   │       └── auth/
│   │           └── LoginScreen.test.tsx
│   ├── jest.config.js           # Jest configuration
│   └── package.test.json        # Test dependencies
│
└── docs/
    ├── MANUAL_TESTING_CHECKLIST.md  # QA testing checklist
    └── BETA_TESTING_GUIDE.md        # Beta testing procedures
```

## Installation

### Backend Tests

```bash
cd backend

# Install test dependencies
pip install -r requirements-test.txt

# Run all tests
pytest

# Run with coverage
pytest --cov=app --cov-report=html

# Run specific test file
pytest tests/test_auth.py -v

# Run tests in parallel
pytest -n auto
```

### Frontend Tests

```bash
cd mobile

# Install test dependencies (merge with existing package.json)
npm install --save-dev @testing-library/react-native @testing-library/jest-native jest-expo msw

# Run all tests
npm test

# Run with coverage
npm test -- --coverage

# Run in watch mode
npm test -- --watch

# Run specific test file
npm test -- LoginScreen.test.tsx
```

## Test Categories

### Backend Tests

| File | Description | Test Count |
|------|-------------|------------|
| `test_auth.py` | Registration, login, tokens, password | ~25 tests |
| `test_users.py` | Profile, preferences, stats | ~15 tests |
| `test_instruments.py` | List, search, filter, bookmark | ~20 tests |
| `test_preference_cards.py` | CRUD, items, photos, duplicate | ~25 tests |
| `test_quiz.py` | Sessions, answers, results | ~20 tests |
| `test_study_progress.py` | Spaced repetition, bookmarks | ~15 tests |
| `test_premium.py` | Limits, gating, subscription | ~15 tests |

### Frontend Tests

| Directory | Description |
|-----------|-------------|
| `components/` | UI component unit tests |
| `hooks/` | Custom hook tests |
| `stores/` | Zustand store tests |
| `screens/` | Screen integration tests |
| `api/` | API client tests |

## Key Testing Patterns

### Backend: Async Testing with Pytest

```python
@pytest.mark.asyncio
async def test_example(async_client: AsyncClient, auth_headers: dict):
    response = await async_client.get(
        "/api/v1/endpoint",
        headers=auth_headers,
    )
    assert response.status_code == 200
```

### Frontend: Custom Render with Providers

```typescript
import { render, fireEvent, factories } from '../utils/test-utils';

it('renders correctly', () => {
  const instrument = factories.instrument({ name: 'Test' });
  const { getByText } = render(<Component instrument={instrument} />);
  expect(getByText('Test')).toBeTruthy();
});
```

### MSW for API Mocking

```typescript
import { server } from '../mocks/server';
import { http, HttpResponse } from 'msw';

beforeAll(() => server.listen());
afterEach(() => server.resetHandlers());
afterAll(() => server.close());

it('handles error', async () => {
  server.use(
    http.get('/api/endpoint', () => HttpResponse.error())
  );
  // Test error handling
});
```

## Coverage Goals

| Area | Target |
|------|--------|
| Backend API endpoints | 90%+ |
| Backend business logic | 95%+ |
| Frontend components | 80%+ |
| Frontend hooks | 85%+ |
| Critical user flows | 100% |

## Running Manual Tests

See `docs/MANUAL_TESTING_CHECKLIST.md` for comprehensive manual testing procedures covering:
- Authentication flows
- Instrument browsing
- Preference card management
- Quiz functionality
- Profile settings
- Edge cases and error handling
- Platform-specific tests

## Beta Testing

See `docs/BETA_TESTING_GUIDE.md` for:
- TestFlight/Play Store setup
- Tester recruitment strategies
- Feedback collection methods
- Success metrics
- Communication templates

## Continuous Integration

Add to your CI/CD pipeline:

```yaml
# GitHub Actions example
test:
  runs-on: ubuntu-latest
  steps:
    - uses: actions/checkout@v4
    
    # Backend tests
    - name: Run Backend Tests
      run: |
        cd backend
        pip install -r requirements-test.txt
        pytest --cov=app --cov-report=xml
    
    # Frontend tests
    - name: Run Frontend Tests
      run: |
        cd mobile
        npm ci
        npm test -- --coverage --ci
    
    # Upload coverage
    - uses: codecov/codecov-action@v3
```

## Next Steps After Testing

1. Fix all failing tests
2. Address bugs found in manual testing
3. Incorporate beta tester feedback
4. Ensure coverage targets are met
5. Proceed to Stage 12: Launch Preparation

## Support

If you encounter issues with the test setup:
1. Check dependency versions match
2. Ensure database migrations are current
3. Verify environment variables are set
4. Review test output for specific errors
