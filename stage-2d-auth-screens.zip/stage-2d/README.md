# Stage 2D: Auth Screens

This stage implements the authentication screens for SurgicalPrep, including login, signup, form validation, and error handling.

## 📁 File Structure

```
stage-2d/
├── app/
│   └── (auth)/
│       ├── _layout.tsx        # Auth stack navigator layout
│       ├── login.tsx          # Login screen with form
│       └── signup.tsx         # Signup screen with form
├── src/
│   ├── api/
│   │   ├── client.ts          # Axios client with interceptors
│   │   └── auth.ts            # Auth API endpoints
│   ├── components/
│   │   └── ui/
│   │       ├── FormError.tsx  # Error message component
│   │       └── LogoHeader.tsx # Branded header component
│   ├── hooks/
│   │   └── useAuth.ts         # Auth hook wrapper
│   ├── stores/
│   │   └── authStore.ts       # Zustand auth state management
│   ├── types/
│   │   └── index.ts           # TypeScript type definitions
│   └── utils/
│       ├── constants.ts       # App configuration constants
│       └── validation.ts      # Form validation functions
└── README.md                  # This file
```

## 🎯 Features Implemented

### Login Screen (`login.tsx`)
- Email and password input fields
- Password visibility toggle
- Form validation (email format, password requirements)
- Error handling with user-friendly messages
- Loading state during submission
- "Forgot password" link (placeholder)
- Link to signup screen
- Keyboard avoiding behavior
- Auto-focus and return key navigation

### Signup Screen (`signup.tsx`)
- Full name input
- Email input
- Role dropdown (modal picker)
  - Surgical Tech Student
  - Certified Surgical Technologist
  - OR Nurse / Perioperative Nurse
  - Surgical Tech Educator
  - Other Healthcare Professional
- Institution field (optional)
- Password with visibility toggle
- Confirm password
- Form validation for all fields
- Terms of Service agreement notice
- Link to login screen

### Auth Store (`authStore.ts`)
- Zustand-based state management
- Secure token storage with expo-secure-store
- Session persistence across app restarts
- Token refresh logic
- Login, signup, logout actions
- Loading and error states

### API Client (`client.ts`)
- Axios instance with base configuration
- Request interceptor for auth token attachment
- Response interceptor for 401 handling
- Automatic token refresh on expiry
- Error message extraction
- Configurable timeout

### Validation (`validation.ts`)
- Email format validation
- Password strength validation (8+ chars, letter + number)
- Name validation
- Required field validation
- Composite validator support

## 🎨 Design Decisions

### Color Scheme
- **Primary**: Teal (`#0D9488`) - Medical/trustworthy feel
- **Background**: Light gray (`#F8FAFB`)
- **Error**: Red (`#EF4444`)
- **Text**: Dark gray (`#1F2937`)

### Typography
- Clean, readable font sizes
- Clear visual hierarchy
- Appropriate spacing for mobile

### UX Patterns
- Inline field validation errors
- General error banner for API errors
- Loading spinner in submit button
- Disabled state while submitting
- Keyboard-aware scrolling

## 📲 Installation

1. Copy the files to your Expo project's corresponding directories
2. Install dependencies if not already installed:
   ```bash
   npx expo install expo-secure-store zustand axios
   ```
3. Ensure your `app.json` has the correct configuration

## 🔧 Configuration

### API URL
Update the API URL in `src/api/client.ts` or configure via `app.json`:

```json
{
  "expo": {
    "extra": {
      "apiUrl": "https://your-api.railway.app/api/v1"
    }
  }
}
```

### Bundle Identifiers
Update in `app.json`:
```json
{
  "expo": {
    "ios": { "bundleIdentifier": "com.yourname.surgicalprep" },
    "android": { "package": "com.yourname.surgicalprep" }
  }
}
```

## 🧪 Testing

### Manual Testing Checklist

- [ ] Login with valid credentials
- [ ] Login with invalid email format (shows error)
- [ ] Login with wrong password (shows error)
- [ ] Login with network offline (shows error)
- [ ] Signup with all valid fields
- [ ] Signup with existing email (shows error)
- [ ] Signup with weak password (shows error)
- [ ] Signup with mismatched passwords (shows error)
- [ ] Navigate between login and signup
- [ ] Token persistence after app restart
- [ ] Logout clears stored data

## 📋 Dependencies

- `expo-router` - File-based navigation
- `expo-secure-store` - Secure token storage
- `zustand` - State management
- `axios` - HTTP client
- `react-native-safe-area-context` - Safe area handling

## 🔗 Integration Points

### Root Layout
The root `_layout.tsx` should check auth state and redirect:

```tsx
import { useAuth } from '../src/hooks/useAuth';
import { Redirect, Stack } from 'expo-router';

export default function RootLayout() {
  const { isAuthenticated, isInitialized, initialize } = useAuth();

  useEffect(() => {
    initialize();
  }, []);

  if (!isInitialized) {
    return <SplashScreen />;
  }

  if (!isAuthenticated) {
    return <Redirect href="/(auth)/login" />;
  }

  return <Stack />;
}
```

### Backend Endpoints Expected
- `POST /auth/login` - Login
- `POST /auth/signup` - Create account
- `POST /auth/logout` - Logout
- `POST /auth/refresh` - Refresh token
- `GET /auth/me` - Get current user

## ➡️ Next Steps

After completing Stage 2D, proceed to:
- **Stage 3A**: Instruments API Layer
- **Stage 3B**: Instrument List Screen
