/**
 * Quiz & Study API Client
 * SurgicalPrep - Stage 6A
 * 
 * Handles all quiz, flashcard, and study progress API interactions.
 */

import { apiClient } from './client';
import type {
  // Config types
  QuizConfig,
  FlashcardConfig,
  
  // Session types
  QuizSession,
  FlashcardSession,
  
  // Answer types
  AnswerSubmission,
  AnswerResult,
  FlashcardResultSubmission,
  FlashcardResultResponse,
  
  // Result types
  QuizSessionResult,
  FlashcardSessionResult,
  
  // Progress types
  StudyProgress,
  InstrumentProgress,
  DueForReviewParams,
  DueForReviewResponse,
  
  // History types
  QuizHistoryParams,
  QuizHistoryResponse,
  
  // Request/Response types
  StartQuizRequest,
  StartQuizResponse,
  StartFlashcardRequest,
  StartFlashcardResponse,
  EndSessionRequest,
  EndQuizResponse,
  EndFlashcardResponse,
  
  // Premium types
  QuizLimits,
} from '../types/quiz';

// =============================================================================
// Quiz Session Endpoints
// =============================================================================

/**
 * Start a new quiz session with the given configuration.
 * Returns the session with all questions pre-loaded.
 */
export async function startQuizSession(config: QuizConfig): Promise<StartQuizResponse> {
  const response = await apiClient.post<StartQuizResponse>('/quiz/sessions', {
    config,
  } as StartQuizRequest);
  return response.data;
}

/**
 * Get an existing quiz session by ID.
 * Useful for resuming an in-progress session.
 */
export async function getQuizSession(sessionId: string): Promise<QuizSession> {
  const response = await apiClient.get<QuizSession>(`/quiz/sessions/${sessionId}`);
  return response.data;
}

/**
 * Submit an answer for a question in an active quiz session.
 * Returns immediate feedback on whether the answer was correct.
 */
export async function submitQuizAnswer(submission: AnswerSubmission): Promise<AnswerResult> {
  const { session_id, question_id, ...answerData } = submission;
  const response = await apiClient.post<AnswerResult>(
    `/quiz/sessions/${session_id}/questions/${question_id}/answer`,
    answerData
  );
  return response.data;
}

/**
 * End a quiz session and get final results.
 * Can optionally mark as abandoned if user didn't complete all questions.
 */
export async function endQuizSession(
  sessionId: string,
  abandoned: boolean = false
): Promise<QuizSessionResult> {
  const response = await apiClient.post<EndQuizResponse>(
    `/quiz/sessions/${sessionId}/end`,
    { abandoned } as EndSessionRequest
  );
  return response.data.result;
}

/**
 * Abandon a quiz session without completing it.
 * Progress is saved but session is marked as abandoned.
 */
export async function abandonQuizSession(sessionId: string): Promise<void> {
  await apiClient.post(`/quiz/sessions/${sessionId}/abandon`);
}

// =============================================================================
// Flashcard Session Endpoints
// =============================================================================

/**
 * Start a new flashcard study session.
 * Returns a deck of flashcards based on configuration.
 */
export async function startFlashcardSession(
  config: FlashcardConfig
): Promise<StartFlashcardResponse> {
  const response = await apiClient.post<StartFlashcardResponse>('/quiz/flashcards/sessions', {
    config,
  } as StartFlashcardRequest);
  return response.data;
}

/**
 * Get an existing flashcard session by ID.
 */
export async function getFlashcardSession(sessionId: string): Promise<FlashcardSession> {
  const response = await apiClient.get<FlashcardSession>(
    `/quiz/flashcards/sessions/${sessionId}`
  );
  return response.data;
}

/**
 * Record the result of a flashcard (got it or study more).
 * Updates spaced repetition scheduling for the instrument.
 */
export async function recordFlashcardResult(
  submission: FlashcardResultSubmission
): Promise<FlashcardResultResponse> {
  const { session_id, ...resultData } = submission;
  const response = await apiClient.post<FlashcardResultResponse>(
    `/quiz/flashcards/sessions/${session_id}/result`,
    resultData
  );
  return response.data;
}

/**
 * End a flashcard session and get summary results.
 */
export async function endFlashcardSession(
  sessionId: string,
  abandoned: boolean = false
): Promise<FlashcardSessionResult> {
  const response = await apiClient.post<EndFlashcardResponse>(
    `/quiz/flashcards/sessions/${sessionId}/end`,
    { abandoned }
  );
  return response.data.result;
}

/**
 * Get a standalone flashcard deck without creating a session.
 * Useful for quick review mode.
 */
export async function getFlashcardDeck(config: FlashcardConfig): Promise<FlashcardSession> {
  const response = await apiClient.post<StartFlashcardResponse>(
    '/quiz/flashcards/deck',
    { config }
  );
  return response.data.session;
}

// =============================================================================
// Study Progress Endpoints
// =============================================================================

/**
 * Get the user's overall study progress and statistics.
 */
export async function getStudyProgress(): Promise<StudyProgress> {
  const response = await apiClient.get<StudyProgress>('/quiz/progress');
  return response.data;
}

/**
 * Get detailed progress for a specific instrument.
 */
export async function getInstrumentProgress(instrumentId: string): Promise<InstrumentProgress> {
  const response = await apiClient.get<InstrumentProgress>(
    `/quiz/progress/instruments/${instrumentId}`
  );
  return response.data;
}

/**
 * Get instruments that are due for spaced repetition review.
 */
export async function getDueForReview(
  params: DueForReviewParams = {}
): Promise<DueForReviewResponse> {
  const response = await apiClient.get<DueForReviewResponse>('/quiz/progress/due-for-review', {
    params: {
      limit: params.limit ?? 20,
      offset: params.offset ?? 0,
      categories: params.categories?.join(','),
      include_overdue: params.include_overdue ?? true,
      sort_by: params.sort_by ?? 'due_date',
    },
  });
  return response.data;
}

/**
 * Toggle bookmark status for an instrument.
 * Bookmarked instruments can be filtered in study sessions.
 */
export async function toggleInstrumentBookmark(
  instrumentId: string,
  bookmarked: boolean
): Promise<InstrumentProgress> {
  const response = await apiClient.patch<InstrumentProgress>(
    `/quiz/progress/instruments/${instrumentId}/bookmark`,
    { bookmarked }
  );
  return response.data;
}

/**
 * Reset study progress for a specific instrument.
 * Clears spaced repetition data and stats.
 */
export async function resetInstrumentProgress(instrumentId: string): Promise<void> {
  await apiClient.delete(`/quiz/progress/instruments/${instrumentId}`);
}

/**
 * Reset all study progress for the user.
 * USE WITH CAUTION - this is irreversible.
 */
export async function resetAllProgress(): Promise<void> {
  await apiClient.delete('/quiz/progress/reset-all');
}

// =============================================================================
// Quiz History Endpoints
// =============================================================================

/**
 * Get paginated history of past quiz sessions.
 */
export async function getQuizHistory(
  params: QuizHistoryParams = {}
): Promise<QuizHistoryResponse> {
  const response = await apiClient.get<QuizHistoryResponse>('/quiz/history', {
    params: {
      limit: params.limit ?? 20,
      offset: params.offset ?? 0,
      quiz_type: params.quiz_type,
      date_from: params.date_from,
      date_to: params.date_to,
    },
  });
  return response.data;
}

/**
 * Get detailed results for a specific past quiz session.
 */
export async function getQuizSessionDetails(sessionId: string): Promise<QuizSessionResult> {
  const response = await apiClient.get<QuizSessionResult>(`/quiz/history/${sessionId}`);
  return response.data;
}

// =============================================================================
// Quiz Limits (Premium Gating)
// =============================================================================

/**
 * Get the user's current quiz limits and premium status.
 */
export async function getQuizLimits(): Promise<QuizLimits> {
  const response = await apiClient.get<QuizLimits>('/quiz/limits');
  return response.data;
}

// =============================================================================
// Quick Quiz Endpoints
// =============================================================================

/**
 * Start a "Quick 10" quiz - 10 random questions across all categories.
 */
export async function startQuickQuiz(): Promise<StartQuizResponse> {
  return startQuizSession({
    quiz_type: 'multiple_choice',
    question_count: 10,
    difficulty: 'mixed',
  });
}

/**
 * Start a review session for instruments due for spaced repetition.
 */
export async function startReviewSession(
  maxQuestions: number = 20
): Promise<StartQuizResponse> {
  return startQuizSession({
    quiz_type: 'mixed',
    question_count: maxQuestions,
    include_due_for_review: true,
    difficulty: 'mixed',
  });
}

/**
 * Start a category-focused quiz.
 */
export async function startCategoryQuiz(
  categories: string[],
  questionCount: number = 15
): Promise<StartQuizResponse> {
  return startQuizSession({
    quiz_type: 'multiple_choice',
    question_count: questionCount,
    categories,
    difficulty: 'mixed',
  });
}

// =============================================================================
// Export all functions
// =============================================================================

export const quizApi = {
  // Quiz sessions
  startQuizSession,
  getQuizSession,
  submitQuizAnswer,
  endQuizSession,
  abandonQuizSession,
  
  // Flashcard sessions
  startFlashcardSession,
  getFlashcardSession,
  recordFlashcardResult,
  endFlashcardSession,
  getFlashcardDeck,
  
  // Study progress
  getStudyProgress,
  getInstrumentProgress,
  getDueForReview,
  toggleInstrumentBookmark,
  resetInstrumentProgress,
  resetAllProgress,
  
  // History
  getQuizHistory,
  getQuizSessionDetails,
  
  // Limits
  getQuizLimits,
  
  // Quick actions
  startQuickQuiz,
  startReviewSession,
  startCategoryQuiz,
};

export default quizApi;
