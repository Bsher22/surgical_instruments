// src/api/supabase.ts
// Supabase client configuration
// NOTE: This should already exist from Stage 1. This file is included
// as a reference for the storage API integration.

import { createClient } from '@supabase/supabase-js';

const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY!;

if (!supabaseUrl || !supabaseAnonKey) {
  console.warn(
    'Supabase credentials not found. Make sure EXPO_PUBLIC_SUPABASE_URL and EXPO_PUBLIC_SUPABASE_ANON_KEY are set in your .env file.'
  );
}

/**
 * Supabase client instance
 * Used for database operations and storage
 */
export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: false, // We handle session persistence with expo-secure-store
    autoRefreshToken: false, // We handle token refresh manually
  },
});

export default supabase;
