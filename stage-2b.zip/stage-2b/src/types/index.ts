// ============================================
// SurgicalPrep - TypeScript Types
// Matches backend Pydantic schemas
// ============================================

// -------------------- User --------------------

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  institution?: string;
  is_premium: boolean;
  premium_expires_at?: string;
  created_at: string;
  updated_at: string;
}

export type UserRole = 'student' | 'surgical_tech' | 'nurse' | 'educator' | 'other';

export interface UserCreate {
  email: string;
  password: string;
  name: string;
  role: UserRole;
  institution?: string;
}

export interface UserUpdate {
  name?: string;
  role?: UserRole;
  institution?: string;
}

// -------------------- Auth --------------------

export interface LoginRequest {
  email: string;
  password: string;
}

export interface LoginResponse {
  access_token: string;
  refresh_token: string;
  token_type: 'bearer';
  user: User;
}

export interface RefreshTokenRequest {
  refresh_token: string;
}

export interface RefreshTokenResponse {
  access_token: string;
  token_type: 'bearer';
}

// -------------------- Instruments --------------------

export interface Instrument {
  id: string;
  name: string;
  aliases: string[];
  category: InstrumentCategory;
  description: string;
  primary_uses: string[];
  common_procedures: string[];
  handling_notes?: string;
  image_url?: string;
  thumbnail_url?: string;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

export type InstrumentCategory =
  | 'cutting'
  | 'grasping'
  | 'clamping'
  | 'retracting'
  | 'suturing'
  | 'probing'
  | 'dilating'
  | 'suctioning'
  | 'specialty'
  | 'other';

export interface InstrumentListParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: InstrumentCategory;
  sort_by?: 'name' | 'created_at' | 'category';
  sort_order?: 'asc' | 'desc';
}

export interface InstrumentSearchParams {
  query: string;
  limit?: number;
}

// -------------------- Preference Cards --------------------

export interface PreferenceCard {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: Specialty;
  general_notes?: string;
  setup_notes?: string;
  items: PreferenceCardItem[];
  photos: string[];
  is_template: boolean;
  is_public: boolean;
  created_at: string;
  updated_at: string;
}

export type Specialty =
  | 'general'
  | 'orthopedic'
  | 'cardiovascular'
  | 'neurosurgery'
  | 'obstetrics'
  | 'gynecology'
  | 'urology'
  | 'ent'
  | 'plastic'
  | 'ophthalmic'
  | 'other';

export interface PreferenceCardItem {
  id: string;
  card_id: string;
  instrument_id?: string;
  instrument?: Instrument;
  custom_name?: string;
  quantity: number;
  size?: string;
  notes?: string;
  category: ItemCategory;
  sort_order: number;
}

export type ItemCategory = 'instruments' | 'supplies' | 'sutures' | 'implants' | 'special';

export interface PreferenceCardCreate {
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: Specialty;
  general_notes?: string;
  setup_notes?: string;
  items?: PreferenceCardItemCreate[];
}

export interface PreferenceCardUpdate {
  title?: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: Specialty;
  general_notes?: string;
  setup_notes?: string;
}

export interface PreferenceCardItemCreate {
  instrument_id?: string;
  custom_name?: string;
  quantity?: number;
  size?: string;
  notes?: string;
  category?: ItemCategory;
  sort_order?: number;
}

export interface PreferenceCardItemUpdate {
  quantity?: number;
  size?: string;
  notes?: string;
  category?: ItemCategory;
  sort_order?: number;
}

export interface CardListParams {
  page?: number;
  limit?: number;
  search?: string;
  specialty?: Specialty;
  templates_only?: boolean;
}

// -------------------- Quiz & Study --------------------

export interface QuizSession {
  id: string;
  user_id: string;
  quiz_type: QuizType;
  category_filter?: InstrumentCategory;
  total_questions: number;
  correct_answers: number;
  score_percentage: number;
  started_at: string;
  completed_at?: string;
  questions: QuizQuestion[];
}

export type QuizType = 'flashcard' | 'multiple_choice' | 'image_to_name' | 'name_to_use';

export interface QuizQuestion {
  id: string;
  session_id: string;
  instrument_id: string;
  instrument: Instrument;
  question_type: QuestionType;
  question_text: string;
  options?: string[];
  correct_answer: string;
  user_answer?: string;
  is_correct?: boolean;
  answered_at?: string;
}

export type QuestionType = 'image_to_name' | 'name_to_use' | 'image_to_category';

export interface QuizSessionCreate {
  quiz_type: QuizType;
  category_filter?: InstrumentCategory;
  question_count?: number;
}

export interface QuizAnswerSubmit {
  question_id: string;
  answer: string;
}

export interface UserInstrumentProgress {
  id: string;
  user_id: string;
  instrument_id: string;
  instrument: Instrument;
  times_studied: number;
  times_correct: number;
  times_incorrect: number;
  accuracy_rate: number;
  last_studied_at: string;
  next_review_at: string;
  ease_factor: number;
  interval_days: number;
  is_bookmarked: boolean;
}

export interface StudyStats {
  total_instruments_studied: number;
  total_quizzes_completed: number;
  average_score: number;
  current_streak: number;
  due_for_review_count: number;
  bookmarked_count: number;
}

// -------------------- Pagination --------------------

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
}

// -------------------- API Error --------------------

export interface ApiError {
  detail: string;
  status_code?: number;
  errors?: Record<string, string[]>;
}

// -------------------- Subscription --------------------

export interface SubscriptionStatus {
  is_premium: boolean;
  tier: 'free' | 'premium';
  expires_at?: string;
  cards_used: number;
  cards_limit: number;
  daily_quizzes_used: number;
  daily_quizzes_limit: number;
}
