import { get } from './client';
import type {
  Instrument,
  InstrumentDetail,
  InstrumentsResponse,
  GetInstrumentsParams,
  InstrumentSearchParams,
  InstrumentSearchResponse,
  InstrumentCategory,
} from '../types/instruments';

/**
 * Instruments API
 * 
 * Provides typed functions for interacting with the instruments endpoints.
 */

const INSTRUMENTS_BASE = '/instruments';

/**
 * Get paginated list of instruments with optional filtering
 * 
 * @param params - Query parameters for filtering, sorting, and pagination
 * @returns Paginated response with instruments array and metadata
 * 
 * @example
 * // Get first page of cutting instruments
 * const response = await getInstruments({ 
 *   page: 1, 
 *   limit: 20, 
 *   category: 'cutting' 
 * });
 */
export async function getInstruments(
  params: GetInstrumentsParams = {}
): Promise<InstrumentsResponse> {
  const {
    page = 1,
    limit = 20,
    search,
    category,
    sort_by = 'name',
    sort_order = 'asc',
  } = params;

  const queryParams: Record<string, unknown> = {
    page,
    limit,
    sort_by,
    sort_order,
  };

  // Only add optional params if they have values
  if (search?.trim()) {
    queryParams.search = search.trim();
  }
  if (category) {
    queryParams.category = category;
  }

  return get<InstrumentsResponse>(INSTRUMENTS_BASE, queryParams);
}

/**
 * Get a single instrument by ID
 * 
 * @param id - Instrument UUID
 * @returns Full instrument detail including premium fields (if user has access)
 * 
 * @example
 * const instrument = await getInstrument('123e4567-e89b-12d3-a456-426614174000');
 */
export async function getInstrument(id: string): Promise<InstrumentDetail> {
  return get<InstrumentDetail>(`${INSTRUMENTS_BASE}/${id}`);
}

/**
 * Full-text search for instruments
 * 
 * Uses PostgreSQL full-text search for intelligent matching across
 * name, aliases, description, and uses.
 * 
 * @param params - Search query and optional filters
 * @returns Search results with relevance scores
 * 
 * @example
 * // Search for forceps in grasping category
 * const results = await searchInstruments({ 
 *   query: 'forceps', 
 *   category: 'grasping',
 *   limit: 10 
 * });
 */
export async function searchInstruments(
  params: InstrumentSearchParams
): Promise<InstrumentSearchResponse> {
  const { query, limit = 20, category } = params;

  const queryParams: Record<string, unknown> = {
    q: query.trim(),
    limit,
  };

  if (category) {
    queryParams.category = category;
  }

  return get<InstrumentSearchResponse>(`${INSTRUMENTS_BASE}/search`, queryParams);
}

/**
 * Get all available instrument categories with counts
 * 
 * @returns Array of categories with instrument counts
 */
export interface CategoryCount {
  category: InstrumentCategory;
  count: number;
}

export async function getCategories(): Promise<CategoryCount[]> {
  return get<CategoryCount[]>(`${INSTRUMENTS_BASE}/categories`);
}

/**
 * Get instruments by multiple IDs (batch fetch)
 * Useful for loading instruments in a preference card
 * 
 * @param ids - Array of instrument UUIDs
 * @returns Array of instruments (in same order as requested IDs)
 */
export async function getInstrumentsByIds(ids: string[]): Promise<Instrument[]> {
  if (ids.length === 0) return [];
  
  return get<Instrument[]>(`${INSTRUMENTS_BASE}/batch`, { ids: ids.join(',') });
}

/**
 * Get suggested/popular instruments
 * Useful for empty states or discovery
 * 
 * @param limit - Number of instruments to return
 * @returns Array of popular instruments
 */
export async function getPopularInstruments(limit: number = 10): Promise<Instrument[]> {
  return get<Instrument[]>(`${INSTRUMENTS_BASE}/popular`, { limit });
}

/**
 * Get related instruments for a given instrument
 * 
 * @param id - Instrument UUID to find related items for
 * @param limit - Number of related instruments to return
 * @returns Array of related instruments
 */
export async function getRelatedInstruments(
  id: string,
  limit: number = 5
): Promise<Instrument[]> {
  return get<Instrument[]>(`${INSTRUMENTS_BASE}/${id}/related`, { limit });
}
