/**
 * CardItemRow Component
 * Displays a single item with name, quantity, size, notes
 * Tappable to navigate to instrument detail if linked
 */
import React from 'react';
import { View, Text, StyleSheet, Pressable } from 'react-native';
import { Ionicons } from '@expo/vector-icons';
import * as Haptics from 'expo-haptics';
import { colors, spacing, typography } from '../../utils/theme';
import type { PreferenceCardItem } from '../../types';

interface CardItemRowProps {
  item: PreferenceCardItem;
  onPress?: (itemId: string, instrumentId?: string) => void;
  showDivider?: boolean;
}

export function CardItemRow({ item, onPress, showDivider = true }: CardItemRowProps) {
  const hasLink = Boolean(item.instrument_id);
  
  const handlePress = () => {
    if (hasLink && onPress) {
      Haptics.selectionAsync();
      onPress(item.id, item.instrument_id || undefined);
    }
  };

  const Container = hasLink ? Pressable : View;
  const containerProps = hasLink
    ? {
        onPress: handlePress,
        style: ({ pressed }: { pressed: boolean }) => [
          styles.container,
          pressed && styles.pressed,
          showDivider && styles.divider,
        ],
        accessibilityRole: 'button' as const,
        accessibilityLabel: `${item.item_name}, tap to view instrument details`,
        accessibilityHint: 'Opens the instrument detail screen',
      }
    : {
        style: [styles.container, showDivider && styles.divider],
      };

  return (
    <Container {...containerProps}>
      <View style={styles.mainContent}>
        <View style={styles.nameRow}>
          <Text style={styles.itemName} numberOfLines={2}>
            {item.item_name}
          </Text>
          {hasLink && (
            <Ionicons
              name="chevron-forward"
              size={18}
              color={colors.textTertiary}
              style={styles.chevron}
            />
          )}
        </View>

        <View style={styles.metaRow}>
          {item.quantity && item.quantity > 1 && (
            <View style={styles.metaItem}>
              <Ionicons name="layers-outline" size={14} color={colors.textSecondary} />
              <Text style={styles.metaText}>×{item.quantity}</Text>
            </View>
          )}
          
          {item.size && (
            <View style={styles.metaItem}>
              <Ionicons name="resize-outline" size={14} color={colors.textSecondary} />
              <Text style={styles.metaText}>{item.size}</Text>
            </View>
          )}

          {!item.instrument_id && (
            <View style={styles.customBadge}>
              <Text style={styles.customBadgeText}>Custom</Text>
            </View>
          )}
        </View>

        {item.notes && (
          <View style={styles.notesContainer}>
            <Ionicons name="document-text-outline" size={14} color={colors.textTertiary} />
            <Text style={styles.notesText} numberOfLines={2}>
              {item.notes}
            </Text>
          </View>
        )}
      </View>
    </Container>
  );
}

const styles = StyleSheet.create({
  container: {
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.sm,
  },
  pressed: {
    backgroundColor: colors.surfaceSecondary,
  },
  divider: {
    borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: colors.border,
  },
  mainContent: {
    flex: 1,
  },
  nameRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    justifyContent: 'space-between',
  },
  itemName: {
    ...typography.body,
    color: colors.text,
    fontWeight: '500',
    flex: 1,
    marginRight: spacing.sm,
  },
  chevron: {
    marginTop: 2,
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: spacing.xs,
    gap: spacing.md,
    flexWrap: 'wrap',
  },
  metaItem: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
  },
  metaText: {
    ...typography.caption,
    color: colors.textSecondary,
  },
  customBadge: {
    backgroundColor: colors.warning + '20',
    paddingHorizontal: spacing.xs,
    paddingVertical: 2,
    borderRadius: 4,
  },
  customBadgeText: {
    ...typography.caption,
    color: colors.warning,
    fontWeight: '500',
    fontSize: 10,
  },
  notesContainer: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: spacing.xs,
    gap: spacing.xs,
    backgroundColor: colors.surfaceSecondary,
    padding: spacing.xs,
    borderRadius: 6,
  },
  notesText: {
    ...typography.caption,
    color: colors.textTertiary,
    flex: 1,
    fontStyle: 'italic',
  },
});
