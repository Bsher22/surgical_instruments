import { create } from 'zustand';
import * as SecureStore from 'expo-secure-store';
import { User, AuthTokens, LoginRequest, SignupRequest } from '../types';
import { authApi } from '../api/auth';

// Keys for secure storage
const TOKEN_KEY = 'surgicalprep_token';
const REFRESH_TOKEN_KEY = 'surgicalprep_refresh_token';
const USER_KEY = 'surgicalprep_user';

interface AuthState {
  // State
  user: User | null;
  accessToken: string | null;
  refreshToken: string | null;
  isLoading: boolean;
  isAuthenticated: boolean;
  isInitialized: boolean;

  // Actions
  login: (email: string, password: string) => Promise<void>;
  signup: (data: SignupRequest) => Promise<void>;
  logout: () => Promise<void>;
  refreshSession: () => Promise<boolean>;
  initialize: () => Promise<void>;
  setUser: (user: User) => void;
  clearAuth: () => void;
}

/**
 * Auth Store
 *
 * Manages authentication state using Zustand.
 * Persists tokens securely using expo-secure-store.
 */
export const useAuthStore = create<AuthState>((set, get) => ({
  // Initial state
  user: null,
  accessToken: null,
  refreshToken: null,
  isLoading: false,
  isAuthenticated: false,
  isInitialized: false,

  /**
   * Initialize auth state from secure storage
   * Called on app start to restore session
   */
  initialize: async () => {
    try {
      set({ isLoading: true });

      // Retrieve stored tokens
      const [accessToken, refreshToken, userJson] = await Promise.all([
        SecureStore.getItemAsync(TOKEN_KEY),
        SecureStore.getItemAsync(REFRESH_TOKEN_KEY),
        SecureStore.getItemAsync(USER_KEY),
      ]);

      if (accessToken && refreshToken && userJson) {
        const user = JSON.parse(userJson) as User;

        // Set state with stored values
        set({
          user,
          accessToken,
          refreshToken,
          isAuthenticated: true,
        });

        // Optionally verify token is still valid
        // If expired, attempt refresh
        try {
          const refreshed = await get().refreshSession();
          if (!refreshed) {
            // Token refresh failed, clear auth
            await get().logout();
          }
        } catch {
          // Refresh failed, but we can try to use existing token
          // The API will reject if it's expired
        }
      }
    } catch (error) {
      console.error('Failed to initialize auth:', error);
      // Clear any corrupt data
      await get().clearAuth();
    } finally {
      set({ isLoading: false, isInitialized: true });
    }
  },

  /**
   * Login with email and password
   */
  login: async (email: string, password: string) => {
    set({ isLoading: true });

    try {
      const response = await authApi.login({ email, password });

      // Store tokens securely
      await Promise.all([
        SecureStore.setItemAsync(TOKEN_KEY, response.tokens.access_token),
        SecureStore.setItemAsync(REFRESH_TOKEN_KEY, response.tokens.refresh_token),
        SecureStore.setItemAsync(USER_KEY, JSON.stringify(response.user)),
      ]);

      set({
        user: response.user,
        accessToken: response.tokens.access_token,
        refreshToken: response.tokens.refresh_token,
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  /**
   * Create new account
   */
  signup: async (data: SignupRequest) => {
    set({ isLoading: true });

    try {
      const response = await authApi.signup(data);

      // Store tokens securely
      await Promise.all([
        SecureStore.setItemAsync(TOKEN_KEY, response.tokens.access_token),
        SecureStore.setItemAsync(REFRESH_TOKEN_KEY, response.tokens.refresh_token),
        SecureStore.setItemAsync(USER_KEY, JSON.stringify(response.user)),
      ]);

      set({
        user: response.user,
        accessToken: response.tokens.access_token,
        refreshToken: response.tokens.refresh_token,
        isAuthenticated: true,
        isLoading: false,
      });
    } catch (error) {
      set({ isLoading: false });
      throw error;
    }
  },

  /**
   * Logout and clear all auth data
   */
  logout: async () => {
    set({ isLoading: true });

    try {
      // Call backend logout if needed
      const token = get().accessToken;
      if (token) {
        try {
          await authApi.logout();
        } catch {
          // Ignore logout API errors
        }
      }
    } finally {
      await get().clearAuth();
      set({ isLoading: false });
    }
  },

  /**
   * Refresh access token using refresh token
   */
  refreshSession: async (): Promise<boolean> => {
    const { refreshToken } = get();

    if (!refreshToken) {
      return false;
    }

    try {
      const response = await authApi.refreshToken(refreshToken);

      // Update stored tokens
      await Promise.all([
        SecureStore.setItemAsync(TOKEN_KEY, response.tokens.access_token),
        SecureStore.setItemAsync(REFRESH_TOKEN_KEY, response.tokens.refresh_token),
        SecureStore.setItemAsync(USER_KEY, JSON.stringify(response.user)),
      ]);

      set({
        user: response.user,
        accessToken: response.tokens.access_token,
        refreshToken: response.tokens.refresh_token,
        isAuthenticated: true,
      });

      return true;
    } catch (error) {
      console.error('Token refresh failed:', error);
      return false;
    }
  },

  /**
   * Update user data
   */
  setUser: (user: User) => {
    set({ user });
    SecureStore.setItemAsync(USER_KEY, JSON.stringify(user));
  },

  /**
   * Clear all auth data from state and storage
   */
  clearAuth: async () => {
    await Promise.all([
      SecureStore.deleteItemAsync(TOKEN_KEY),
      SecureStore.deleteItemAsync(REFRESH_TOKEN_KEY),
      SecureStore.deleteItemAsync(USER_KEY),
    ]);

    set({
      user: null,
      accessToken: null,
      refreshToken: null,
      isAuthenticated: false,
    });
  },
}));
