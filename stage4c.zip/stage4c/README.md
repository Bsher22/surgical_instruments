# Stage 4C: Card Detail/View Screen

This stage implements the preference card detail view screen, allowing users to see complete information about a preference card including grouped items, photos, and notes.

## Files Included

### Screen
- `app/(tabs)/cards/[id].tsx` - Main card detail screen with dynamic routing

### Components

#### Card Components (`src/components/cards/`)
- `CardHeader.tsx` - Displays card title, surgeon, procedure, specialty badge
- `CardItemsSection.tsx` - Groups and displays items by category (collapsible)
- `CardItemRow.tsx` - Individual item display with navigation to instruments
- `PhotoCarousel.tsx` - Horizontal scrollable photo gallery
- `NotesSection.tsx` - Expandable notes display
- `CardDetailSkeleton.tsx` - Loading placeholder
- `index.ts` - Component exports

#### UI Components (`src/components/ui/`)
- `HeaderButton.tsx` - Icon button for navigation headers
- `ErrorState.tsx` - Error display with retry option
- `ImageViewer.tsx` - Fullscreen image viewer with zoom
- `SpecialtyBadge.tsx` - Colored specialty indicator badge
- `index.ts` - Component exports

### API & Hooks
- `src/api/client.ts` - Axios client with auth interceptors
- `src/api/cards.ts` - Cards API functions
- `src/hooks/useCards.ts` - React Query hooks for cards

### Utilities
- `src/utils/theme.ts` - Design tokens (colors, spacing, typography)
- `src/utils/constants.ts` - App-wide constants
- `src/utils/formatters.ts` - Date, number, and text formatters

### Types
- `src/types/index.ts` - TypeScript types matching backend schemas

## Setup Instructions

### 1. Install Dependencies

Make sure you have these dependencies installed (should already exist from Stage 2):

```bash
npx expo install expo-haptics expo-image-picker
npm install react-native-gesture-handler react-native-reanimated
npm install @expo/vector-icons
```

### 2. Copy Files

Copy the files from this stage into your project structure:

```
mobile/
├── app/
│   └── (tabs)/
│       └── cards/
│           └── [id].tsx          # Card detail screen
├── src/
│   ├── api/
│   │   ├── client.ts             # If not exists from Stage 4A
│   │   └── cards.ts              # Update/replace from Stage 4A
│   ├── components/
│   │   ├── cards/
│   │   │   ├── CardHeader.tsx
│   │   │   ├── CardItemsSection.tsx
│   │   │   ├── CardItemRow.tsx
│   │   │   ├── PhotoCarousel.tsx
│   │   │   ├── NotesSection.tsx
│   │   │   ├── CardDetailSkeleton.tsx
│   │   │   └── index.ts
│   │   └── ui/
│   │       ├── HeaderButton.tsx
│   │       ├── ErrorState.tsx
│   │       ├── ImageViewer.tsx
│   │       ├── SpecialtyBadge.tsx
│   │       └── index.ts
│   ├── hooks/
│   │   └── useCards.ts           # Update/replace from Stage 4A
│   ├── types/
│   │   └── index.ts              # Update/merge with existing
│   └── utils/
│       ├── theme.ts              # If not exists
│       ├── constants.ts          # If not exists
│       └── formatters.ts         # If not exists
```

### 3. Configure Reanimated

Add Reanimated plugin to `babel.config.js`:

```javascript
module.exports = function(api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: [
      'react-native-reanimated/plugin',
    ],
  };
};
```

### 4. Configure Gesture Handler

In your root layout (`app/_layout.tsx`), wrap the app with GestureHandlerRootView:

```tsx
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      {/* Your app content */}
    </GestureHandlerRootView>
  );
}
```

### 5. Navigation Integration

Ensure your cards navigation is set up correctly. The card detail screen uses Expo Router's dynamic routes:

```tsx
// Navigate to card detail from cards list:
router.push(`/cards/${cardId}`);

// The [id].tsx file automatically receives the id parameter
```

## Features

### Card Header
- Title with template badge indicator
- Surgeon and procedure information
- Specialty badge with color coding
- Last updated timestamp (relative time)

### Photo Carousel
- Horizontal swipeable photo gallery
- Pagination dots indicator
- Tap to view fullscreen
- Pinch-to-zoom in fullscreen mode
- Swipe between photos

### Items Section
- Items grouped by category:
  - Instruments
  - Supplies
  - Sutures
  - Implants/Special
  - Other
- Collapsible category sections
- Each item shows:
  - Name
  - Quantity (if > 1)
  - Size (if specified)
  - Notes (if any)
  - "Custom" badge for non-linked items
- Tap instrument items to navigate to instrument detail
- Animated expand/collapse

### Notes Section
- General notes and setup notes
- Collapsible sections
- Preview mode when collapsed
- Selectable text

### Actions
- Edit button → Navigate to edit screen (Stage 5)
- Share button → Native share sheet
- Pull-to-refresh

### Loading & Error States
- Animated skeleton loading
- Error state with retry button

## Component API

### CardHeader
```tsx
interface CardHeaderProps {
  title: string;
  surgeonName?: string | null;
  procedureName?: string | null;
  specialty?: string | null;
  updatedAt?: string | null;
  isTemplate?: boolean;
}
```

### CardItemsSection
```tsx
interface CardItemsSectionProps {
  items: PreferenceCardItem[];
  onItemPress?: (itemId: string, instrumentId?: string) => void;
}
```

### PhotoCarousel
```tsx
interface PhotoCarouselProps {
  photos: string[];
  onPhotoPress?: (index: number) => void;
}
```

### NotesSection
```tsx
interface NotesSectionProps {
  title: string;
  content: string;
  defaultExpanded?: boolean;
  icon?: keyof typeof Ionicons.glyphMap;
}
```

### ImageViewer
```tsx
interface ImageViewerProps {
  images: string[];
  initialIndex: number;
  visible: boolean;
  onClose: () => void;
}
```

### SpecialtyBadge
```tsx
interface SpecialtyBadgeProps {
  specialty: string;
  size?: 'small' | 'medium' | 'large';
}
```

## Theme Customization

Colors, spacing, and typography can be customized in `src/utils/theme.ts`. The theme uses a medical/professional color palette with proper contrast ratios.

## Accessibility

- All interactive elements have accessibility labels
- Proper touch target sizes (minimum 44x44)
- Screen reader support
- Haptic feedback on interactions
- Proper heading hierarchy

## Testing

Test the following flows:
1. Navigate to card detail from cards list
2. View all card information
3. Scroll through photos
4. Tap photo to view fullscreen
5. Pinch to zoom in fullscreen
6. Expand/collapse item categories
7. Tap instrument item to navigate
8. Pull to refresh
9. Test loading state (slow network)
10. Test error state (disconnect network)

## Dependencies

- `@tanstack/react-query` - Data fetching and caching
- `expo-haptics` - Haptic feedback
- `react-native-gesture-handler` - Gesture handling
- `react-native-reanimated` - Animations
- `@expo/vector-icons` - Icons
- `expo-secure-store` - Secure token storage
- `axios` - HTTP client

## Next Steps

After implementing Stage 4C, proceed to:
- **Stage 5**: Preference Cards - Create & Edit
  - Card form with validation
  - Item management (add, edit, delete, reorder)
  - Photo upload functionality
  - Draft auto-save
