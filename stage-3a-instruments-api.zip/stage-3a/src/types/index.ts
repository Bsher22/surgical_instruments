// Re-export all types for convenient imports
// Usage: import { Instrument, InstrumentCategory } from '@/types';

export * from './instruments';

// Common shared types

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'student' | 'surgical_tech' | 'nurse' | 'educator' | 'other';
  institution: string | null;
  is_premium: boolean;
  premium_expires_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface ApiErrorResponse {
  detail: string;
  code?: string;
}
