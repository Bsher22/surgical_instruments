// src/hooks/index.ts
// Barrel exports for custom hooks

// Photo hooks
export { usePhotoUpload, urlsToPhotos, photosToUrls } from './usePhotoUpload';
export { useImagePicker } from './useImagePicker';
export { usePhotoDelete } from './usePhotoDelete';

// Re-export existing hooks from other stages
// export { useAuth } from './useAuth';
// export { useInstruments, useInstrument, useInstrumentSearch } from './useInstruments';
// export { useCards, useCard } from './useCards';
