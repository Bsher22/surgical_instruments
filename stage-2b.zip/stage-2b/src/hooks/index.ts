// ============================================
// SurgicalPrep - Hooks Index
// Export all custom hooks
// ============================================

// Auth hooks
export {
  useCurrentUser,
  useRegister,
  useLogin,
  useLogout,
  useUpdateProfile,
  useChangePassword,
  useRequestPasswordReset,
  useDeleteAccount,
} from './useAuth';

// Instrument hooks
export {
  useInstruments,
  useInfiniteInstruments,
  useInstrument,
  useInstrumentSearch,
  useInstrumentsByCategory,
  useInstrumentCategories,
  useBookmarkedInstruments,
  useToggleBookmark,
  usePrefetchInstrument,
} from './useInstruments';
