// src/components/InstrumentCard.tsx
import React, { memo } from 'react';
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
} from 'react-native';
import { Image } from 'expo-image';
import { Ionicons } from '@expo/vector-icons';
import type { Instrument, InstrumentCategory } from '../types/instruments';

const { width: SCREEN_WIDTH } = Dimensions.get('window');
const CARD_MARGIN = 8;
const NUM_COLUMNS = 2;
const CARD_WIDTH = (SCREEN_WIDTH - CARD_MARGIN * (NUM_COLUMNS + 1)) / NUM_COLUMNS;

interface InstrumentCardProps {
  instrument: Instrument;
  onPress: (instrument: Instrument) => void;
}

// Category color mapping
const CATEGORY_COLORS: Record<InstrumentCategory, string> = {
  cutting: '#EF4444',
  clamping: '#F59E0B',
  grasping: '#10B981',
  retracting: '#3B82F6',
  suturing: '#8B5CF6',
  probing: '#EC4899',
  dilating: '#06B6D4',
  suctioning: '#6366F1',
  specialty: '#F97316',
  other: '#6B7280',
};

// Format category label for display
const formatCategory = (category: string): string => {
  return category.charAt(0).toUpperCase() + category.slice(1);
};

const InstrumentCardComponent: React.FC<InstrumentCardProps> = ({
  instrument,
  onPress,
}) => {
  const categoryColor = CATEGORY_COLORS[instrument.category] || '#6B7280';

  return (
    <TouchableOpacity
      style={styles.card}
      onPress={() => onPress(instrument)}
      activeOpacity={0.7}
    >
      <View style={styles.imageContainer}>
        {instrument.thumbnail_url ? (
          <Image
            source={{ uri: instrument.thumbnail_url }}
            style={styles.image}
            contentFit="cover"
            transition={200}
          />
        ) : (
          <View style={styles.placeholderImage}>
            <Ionicons name="medical" size={40} color="#D1D5DB" />
          </View>
        )}
        {instrument.is_premium && (
          <View style={styles.premiumBadge}>
            <Ionicons name="star" size={12} color="#FCD34D" />
          </View>
        )}
      </View>
      
      <View style={styles.content}>
        <Text style={styles.name} numberOfLines={2}>
          {instrument.name}
        </Text>
        <View style={[styles.categoryBadge, { backgroundColor: `${categoryColor}15` }]}>
          <Text style={[styles.categoryText, { color: categoryColor }]}>
            {formatCategory(instrument.category)}
          </Text>
        </View>
      </View>
    </TouchableOpacity>
  );
};

// Memoize to prevent unnecessary re-renders in FlatList
export const InstrumentCard = memo(InstrumentCardComponent);

const styles = StyleSheet.create({
  card: {
    width: CARD_WIDTH,
    backgroundColor: '#FFFFFF',
    borderRadius: 12,
    marginBottom: CARD_MARGIN,
    marginHorizontal: CARD_MARGIN / 2,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.1,
    shadowRadius: 2,
    elevation: 2,
    overflow: 'hidden',
  },
  imageContainer: {
    width: '100%',
    aspectRatio: 4 / 3,
    backgroundColor: '#F9FAFB',
    position: 'relative',
  },
  image: {
    width: '100%',
    height: '100%',
  },
  placeholderImage: {
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
  },
  premiumBadge: {
    position: 'absolute',
    top: 8,
    right: 8,
    backgroundColor: '#1F2937',
    borderRadius: 12,
    padding: 4,
  },
  content: {
    padding: 12,
  },
  name: {
    fontSize: 14,
    fontWeight: '600',
    color: '#1F2937',
    marginBottom: 8,
    lineHeight: 18,
  },
  categoryBadge: {
    alignSelf: 'flex-start',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  categoryText: {
    fontSize: 11,
    fontWeight: '600',
    textTransform: 'capitalize',
  },
});

// Export constants for use in list screen
export { CARD_WIDTH, CARD_MARGIN, NUM_COLUMNS };

export default InstrumentCard;
