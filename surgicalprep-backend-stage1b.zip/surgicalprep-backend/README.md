# SurgicalPrep API

FastAPI backend for the SurgicalPrep mobile application - a study tool for surgical technicians.

## Tech Stack

- **Framework**: FastAPI 0.109
- **Database**: PostgreSQL (via Supabase)
- **ORM**: SQLAlchemy 2.0 (async)
- **Auth**: JWT with python-jose
- **Payments**: Stripe

## Project Structure

```
surgicalprep-backend/
├── app/
│   ├── main.py              # FastAPI application entry
│   ├── api/
│   │   └── endpoints/       # API route handlers
│   │       ├── auth.py      # Login, signup, token refresh
│   │       ├── users.py     # Profile, settings
│   │       ├── instruments.py # Instrument CRUD
│   │       ├── cards.py     # Preference cards CRUD
│   │       └── quiz.py      # Quiz sessions, progress
│   ├── core/
│   │   ├── config.py        # Settings from environment
│   │   └── security.py      # JWT, password hashing
│   ├── db/
│   │   ├── database.py      # Async engine, session
│   │   └── models.py        # SQLAlchemy models
│   └── schemas/             # Pydantic schemas
│       ├── user.py
│       ├── instrument.py
│       ├── card.py
│       └── quiz.py
├── scripts/                  # Utility scripts
├── tests/                    # Pytest tests
├── requirements.txt
├── railway.json              # Railway deployment
├── render.yaml               # Render deployment
├── Dockerfile
├── Procfile
└── .env.example
```

## Quick Start

### 1. Clone and Setup

```bash
git clone <your-repo-url>
cd surgicalprep-backend

# Create virtual environment
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Configure Environment

```bash
cp .env.example .env
# Edit .env with your credentials
```

### 3. Run Locally

```bash
uvicorn app.main:app --reload --port 8000
```

Visit: http://localhost:8000/docs for interactive API documentation

## Deployment

### Option A: Railway (Recommended)

1. **Create Railway Account**: https://railway.app
2. **New Project** → **Deploy from GitHub repo**
3. **Add Variables** (from `.env.example`):
   - `DATABASE_URL`
   - `SECRET_KEY`
   - `SUPABASE_URL`, `SUPABASE_ANON_KEY`, `SUPABASE_SERVICE_KEY`
   - `CORS_ORIGINS` (include your mobile app URLs)
4. **Deploy** - Railway auto-detects Python and uses `railway.json`
5. **Get URL**: `https://your-app.railway.app`

### Option B: Render

1. **Create Render Account**: https://render.com
2. **New** → **Web Service** → **Connect repo**
3. **Configuration**:
   - Environment: `Python`
   - Build: `pip install -r requirements.txt`
   - Start: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
4. **Add Environment Variables**
5. **Deploy**

### Option C: Docker

```bash
# Build
docker build -t surgicalprep-api .

# Run
docker run -p 8000:8000 --env-file .env surgicalprep-api
```

## API Endpoints

### Authentication
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/auth/signup` | Register new user |
| POST | `/api/auth/login` | Login, get tokens |
| POST | `/api/auth/refresh` | Refresh access token |

### Users
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/users/me` | Get current user |
| PATCH | `/api/users/me` | Update profile |
| GET | `/api/users/me/subscription` | Get subscription status |
| DELETE | `/api/users/me` | Delete account |

### Instruments
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/instruments` | List (paginated, searchable) |
| GET | `/api/instruments/{id}` | Get single instrument |
| GET | `/api/instruments/categories` | List categories |
| GET | `/api/instruments/search` | Quick search |

### Preference Cards
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/cards` | List user's cards |
| POST | `/api/cards` | Create card |
| GET | `/api/cards/{id}` | Get card |
| PATCH | `/api/cards/{id}` | Update card |
| DELETE | `/api/cards/{id}` | Delete card |
| POST | `/api/cards/{id}/duplicate` | Duplicate card |
| GET | `/api/cards/templates` | List public templates |

### Quiz & Study
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/quiz/start` | Start quiz session |
| POST | `/api/quiz/{id}/answer` | Submit answer |
| POST | `/api/quiz/{id}/complete` | Finish quiz |
| GET | `/api/quiz/stats` | Get study statistics |
| GET | `/api/quiz/due-for-review` | Instruments needing review |
| POST | `/api/quiz/bookmark` | Bookmark instrument |

### Health
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/health` | Health check |
| GET | `/` | API info |

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | ✅ | PostgreSQL connection string |
| `SECRET_KEY` | ✅ | JWT signing key (32+ chars) |
| `SUPABASE_URL` | ✅ | Supabase project URL |
| `SUPABASE_ANON_KEY` | ✅ | Supabase anonymous key |
| `SUPABASE_SERVICE_KEY` | ⚪ | Supabase service key |
| `STRIPE_SECRET_KEY` | ⚪ | Stripe API key |
| `STRIPE_WEBHOOK_SECRET` | ⚪ | Stripe webhook signing |
| `CORS_ORIGINS` | ⚪ | Allowed origins (JSON array) |
| `DEBUG` | ⚪ | Enable debug mode |

## Verification

After deployment, verify your API is working:

```bash
# Health check
curl https://your-app.railway.app/health

# Expected response:
# {"status":"healthy","version":"1.0.0"}
```

## Next Steps

1. ✅ Deploy backend (Stage 1B complete)
2. ⏭️ Stage 1A: Set up Supabase and run schema
3. ⏭️ Stage 1C: Initialize Expo mobile app

## License

MIT
