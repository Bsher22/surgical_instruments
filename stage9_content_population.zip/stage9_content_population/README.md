# Stage 9: Content Population

## Overview

This package contains everything needed to populate the SurgicalPrep database with production-ready content:

- **200+ surgical instruments** with comprehensive details
- **10+ template preference cards** for common procedures
- **Image processing utilities** for standardized instrument images
- **Database seeding scripts** with validation and rollback support

## Prerequisites

1. **Backend deployed and accessible**
2. **Supabase project configured** with:
   - Database schema applied
   - Storage bucket `instrument-images` created
   - Service role key available

3. **Python environment** with dependencies:
   ```bash
   pip install asyncpg sqlalchemy[asyncio] aiohttp pillow python-dotenv supabase
   ```

## Environment Setup

Create a `.env` file in the `backend` directory:

```env
DATABASE_URL=postgresql+asyncpg://user:password@host:5432/database
SUPABASE_URL=https://your-project.supabase.co
SUPABASE_SERVICE_KEY=your-service-role-key
SUPABASE_BUCKET=instrument-images
```

## Quick Start

### 1. Seed Instruments (Data Only)

```bash
cd backend
python -m scripts.seed_instruments --data-only
```

This inserts all instrument records without images.

### 2. Upload Images (Optional)

If you have instrument images in `scripts/data/images/`:

```bash
python -m scripts.upload_images
```

### 3. Seed Template Cards

```bash
python -m scripts.seed_templates
```

### 4. Verify Everything

```bash
python -m scripts.verify_seed
```

## Full Seeding (With Images)

```bash
python -m scripts.seed_instruments --full
```

This runs the complete pipeline:
1. Validates all data
2. Processes and uploads images
3. Inserts instrument records
4. Seeds template cards
5. Verifies integrity

## Command Reference

### seed_instruments.py

```bash
# Full seed (data + images)
python -m scripts.seed_instruments --full

# Data only (no images)
python -m scripts.seed_instruments --data-only

# Add new instruments from file
python -m scripts.seed_instruments --add --file=new_instruments.json

# Update existing instruments
python -m scripts.seed_instruments --update --file=updates.json

# Rollback all seeded data
python -m scripts.seed_instruments --rollback

# Dry run (validate without inserting)
python -m scripts.seed_instruments --dry-run
```

### seed_templates.py

```bash
# Seed all template cards
python -m scripts.seed_templates

# Seed specific template
python -m scripts.seed_templates --template="lap_chole"

# Rollback templates
python -m scripts.seed_templates --rollback
```

### upload_images.py

```bash
# Upload all images
python -m scripts.upload_images

# Upload specific instrument images
python -m scripts.upload_images --instrument="kelly-forceps"

# Regenerate thumbnails
python -m scripts.upload_images --thumbnails-only
```

### verify_seed.py

```bash
# Run all verification checks
python -m scripts.verify_seed

# Verify specific aspect
python -m scripts.verify_seed --check=images
python -m scripts.verify_seed --check=instruments
python -m scripts.verify_seed --check=templates
python -m scripts.verify_seed --check=search
```

## Data Files

### instruments.json

Master instrument data file containing 200+ instruments:

```json
{
  "instruments": [
    {
      "name": "Kelly Hemostatic Forceps",
      "aliases": ["Kelly Clamp", "Kelly Hemostat"],
      "category": "Clamps & Forceps",
      "description": "...",
      "primary_uses": ["...", "..."],
      "common_procedures": ["...", "..."],
      "handling_notes": "...",
      "is_premium": false,
      "image_filename": "kelly-hemostatic-forceps.png"
    }
  ]
}
```

### templates.json

Template preference cards:

```json
{
  "templates": [
    {
      "title": "Laparoscopic Cholecystectomy",
      "procedure_name": "Laparoscopic Cholecystectomy",
      "specialty": "General Surgery",
      "general_notes": "...",
      "setup_notes": "...",
      "items": [...]
    }
  ]
}
```

### categories.json

Category definitions with display order:

```json
{
  "categories": [
    { "name": "Cutting & Dissecting", "order": 1 },
    { "name": "Clamps & Forceps", "order": 2 }
  ]
}
```

## Image Guidelines

### Specifications
- **Dimensions**: 800x600 pixels (primary), 400x300 (thumbnail)
- **Format**: PNG or WebP preferred
- **Background**: White or neutral gray
- **File size**: < 100KB optimized
- **Naming**: `instrument-slug.png` (lowercase, hyphens)

### Directory Structure

```
scripts/data/images/
├── source/           # Original high-res images
├── processed/        # Processed 800x600 images
└── thumbnails/       # Generated 400x300 thumbnails
```

### Processing Pipeline

1. Place source images in `scripts/data/images/source/`
2. Run: `python -m scripts.image_processor`
3. Processed images appear in `processed/` and `thumbnails/`
4. Upload with: `python -m scripts.upload_images`

## Adding New Content

### Adding Instruments

1. Add entries to `instruments.json` or create a new JSON file
2. Add corresponding images to `images/source/`
3. Run:
   ```bash
   python -m scripts.seed_instruments --add --file=new_instruments.json
   ```

### Adding Template Cards

1. Add entries to `templates.json`
2. Ensure all referenced instruments exist in database
3. Run:
   ```bash
   python -m scripts.seed_templates
   ```

## Troubleshooting

### "Instrument not found" errors
- Ensure instruments are seeded before templates
- Check instrument names match exactly (case-sensitive)

### Image upload failures
- Verify Supabase service key has write permissions
- Check storage bucket exists and is configured
- Ensure images meet size/format requirements

### Database connection errors
- Verify DATABASE_URL is correct
- Ensure database is accessible from your network
- Check SSL requirements for production databases

## Content Statistics

After full seeding, you should have:

| Content Type | Count |
|--------------|-------|
| Instruments | 200+ |
| Categories | 8 |
| Template Cards | 10-15 |
| Images (Primary) | 200+ |
| Images (Thumbnails) | 200+ |

## Verification Checklist

- [ ] All instruments inserted (verify count)
- [ ] All images uploaded and accessible
- [ ] Full-text search returns results
- [ ] Template cards load with items
- [ ] Categories display correctly
- [ ] No duplicate entries
- [ ] Premium flags set correctly
