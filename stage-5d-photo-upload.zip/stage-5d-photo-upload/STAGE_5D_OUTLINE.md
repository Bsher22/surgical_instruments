# Stage 5D: Photo Upload - Implementation Outline

## Overview

Stage 5D implements photo upload functionality for preference cards, allowing users to capture setup photos via camera or select from gallery, preview them in a grid, delete unwanted photos, and upload them to Supabase Storage with proper loading states.

---

## Components to Build

### 1. Core Components

| Component | Purpose |
|-----------|---------|
| `PhotoUploader` | Main container component with camera/gallery buttons and preview grid |
| `PhotoPreviewGrid` | Grid display of uploaded/pending photos with delete capability |
| `PhotoPreviewItem` | Individual photo thumbnail with loading state and delete button |
| `PhotoSourceModal` | Bottom sheet modal for choosing camera vs gallery |

### 2. Hooks

| Hook | Purpose |
|------|---------|
| `usePhotoUpload` | Manages photo selection, upload queue, and upload progress |
| `useImagePicker` | Wraps expo-image-picker for camera/gallery access |
| `usePhotoDelete` | Handles photo deletion from storage and local state |

### 3. API Layer

| File | Purpose |
|------|---------|
| `src/api/storage.ts` | Supabase Storage API client for upload/delete operations |

### 4. Types

| Type | Purpose |
|------|---------|
| `Photo` | Photo metadata (id, uri, url, uploadStatus) |
| `PhotoUploadState` | Upload queue state management |
| `PhotoPickerResult` | Result from image picker |

### 5. Utilities

| Utility | Purpose |
|---------|---------|
| `imageUtils.ts` | Image compression, resizing, and format conversion |
| `fileUtils.ts` | File naming, MIME type detection, blob conversion |

---

## File Structure

```
src/
├── api/
│   └── storage.ts                    # Supabase Storage operations
├── components/
│   └── photos/
│       ├── index.ts                  # Barrel export
│       ├── PhotoUploader.tsx         # Main photo upload component
│       ├── PhotoPreviewGrid.tsx      # Grid of photo thumbnails
│       ├── PhotoPreviewItem.tsx      # Single photo with delete
│       └── PhotoSourceModal.tsx      # Camera/gallery picker modal
├── hooks/
│   ├── usePhotoUpload.ts            # Upload orchestration hook
│   ├── useImagePicker.ts            # expo-image-picker wrapper
│   └── usePhotoDelete.ts            # Photo deletion hook
├── types/
│   └── photo.ts                      # Photo-related types
└── utils/
    ├── imageUtils.ts                 # Image processing utilities
    └── fileUtils.ts                  # File handling utilities
```

---

## Implementation Details

### 1. PhotoUploader Component

**Props:**
```typescript
interface PhotoUploaderProps {
  photos: Photo[];                    // Current photos
  onPhotosChange: (photos: Photo[]) => void;  // Callback when photos change
  maxPhotos?: number;                 // Max allowed photos (default: 10)
  cardId?: string;                    // Card ID for storage path
  disabled?: boolean;                 // Disable all interactions
}
```

**Features:**
- "Add Photos" button that opens PhotoSourceModal
- Displays PhotoPreviewGrid with current photos
- Shows upload progress for pending uploads
- Enforces max photo limit
- Handles upload errors with retry option

### 2. PhotoPreviewGrid Component

**Props:**
```typescript
interface PhotoPreviewGridProps {
  photos: Photo[];
  onDelete: (photoId: string) => void;
  onPhotoPress?: (photo: Photo) => void;  // Optional full-screen view
  columns?: number;                   // Grid columns (default: 3)
  disabled?: boolean;
}
```

**Features:**
- Responsive grid layout
- Shows upload progress overlay for uploading photos
- Error state indicator for failed uploads
- Tap-to-delete with haptic feedback
- Empty state when no photos

### 3. PhotoPreviewItem Component

**Props:**
```typescript
interface PhotoPreviewItemProps {
  photo: Photo;
  onDelete: () => void;
  onPress?: () => void;
  size: number;
  disabled?: boolean;
}
```

**Features:**
- Thumbnail image display
- Delete button (X) in corner
- Upload progress indicator (circular)
- Error badge for failed uploads
- Loading skeleton while image loads

### 4. PhotoSourceModal Component

**Props:**
```typescript
interface PhotoSourceModalProps {
  visible: boolean;
  onClose: () => void;
  onSelectCamera: () => void;
  onSelectGallery: () => void;
}
```

**Features:**
- Bottom sheet modal presentation
- Camera option with icon
- Gallery option with icon
- Cancel button
- Animated slide-up appearance

### 5. usePhotoUpload Hook

**Interface:**
```typescript
interface UsePhotoUploadReturn {
  photos: Photo[];
  isUploading: boolean;
  uploadProgress: number;
  addPhotos: (uris: string[]) => Promise<void>;
  removePhoto: (photoId: string) => Promise<void>;
  retryFailedUploads: () => Promise<void>;
  clearAll: () => void;
}
```

**Behavior:**
- Manages upload queue with concurrent uploads (max 2)
- Tracks individual and overall progress
- Handles upload failures with retry capability
- Optimistic UI updates (show photo immediately, upload in background)
- Generates unique filenames with timestamp and UUID
- Compresses images before upload

### 6. useImagePicker Hook

**Interface:**
```typescript
interface UseImagePickerReturn {
  pickFromCamera: () => Promise<PhotoPickerResult | null>;
  pickFromGallery: (allowMultiple?: boolean) => Promise<PhotoPickerResult[] | null>;
  requestPermissions: () => Promise<boolean>;
  cameraPermissionStatus: PermissionStatus;
  galleryPermissionStatus: PermissionStatus;
}
```

**Behavior:**
- Handles permission requests for camera and media library
- Configures image picker options (quality, aspect ratio, etc.)
- Returns selected image(s) with local URI
- Handles permission denied gracefully

### 7. Storage API Client

**Functions:**
```typescript
// Upload a photo to Supabase Storage
async function uploadPhoto(
  file: Blob,
  path: string,
  onProgress?: (progress: number) => void
): Promise<{ url: string; path: string }>;

// Delete a photo from Supabase Storage
async function deletePhoto(path: string): Promise<void>;

// Get public URL for a stored photo
function getPhotoUrl(path: string): string;

// Upload multiple photos
async function uploadPhotos(
  files: { blob: Blob; path: string }[],
  onProgress?: (completed: number, total: number) => void
): Promise<{ url: string; path: string }[]>;
```

---

## State Management

### Photo Object Structure

```typescript
interface Photo {
  id: string;                         // Unique identifier (UUID)
  localUri: string;                   // Local file URI (for display before upload)
  remoteUrl?: string;                 // Supabase public URL (after upload)
  storagePath?: string;               // Path in Supabase storage
  uploadStatus: 'pending' | 'uploading' | 'success' | 'error';
  uploadProgress?: number;            // 0-100 progress percentage
  errorMessage?: string;              // Error message if upload failed
  createdAt: string;                  // ISO timestamp
}
```

### Integration with Card Edit Form

The PhotoUploader integrates with the card editing form state:

```typescript
// In card edit form state
interface CardFormState {
  // ... other fields
  photos: Photo[];
  photosToDelete: string[];           // Storage paths to delete on save
}

// When saving the card
async function saveCard() {
  // 1. Delete removed photos from storage
  await Promise.all(
    photosToDelete.map(path => deletePhoto(path))
  );
  
  // 2. Wait for pending uploads to complete
  await waitForUploads();
  
  // 3. Save card with photo URLs
  const photoUrls = photos
    .filter(p => p.uploadStatus === 'success')
    .map(p => p.remoteUrl);
  
  await updateCard({ ...cardData, setup_photos: photoUrls });
}
```

---

## Upload Flow

```
┌─────────────────────────────────────────────────────────────────┐
│                         USER ACTION                              │
│                   Tap "Add Photos" button                        │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                      PhotoSourceModal                            │
│                   Camera | Gallery | Cancel                      │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                    useImagePicker Hook                           │
│          Request permissions → Open picker → Get URI(s)          │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                   usePhotoUpload Hook                            │
│   1. Create Photo object with localUri (status: 'pending')       │
│   2. Add to photos array (immediate UI update)                   │
│   3. Compress/resize image                                       │
│   4. Start upload (status: 'uploading')                          │
│   5. Track progress                                              │
│   6. On success: update remoteUrl (status: 'success')            │
│   7. On error: set errorMessage (status: 'error')                │
└─────────────────────────────────────────────────────────────────┘
                              │
                              ▼
┌─────────────────────────────────────────────────────────────────┐
│                     PhotoPreviewGrid                             │
│              Displays all photos with status indicators          │
└─────────────────────────────────────────────────────────────────┘
```

---

## Error Handling

| Scenario | Handling |
|----------|----------|
| Permission denied | Show alert with settings link |
| Upload fails | Mark photo as error, show retry button |
| Network error | Queue retry, show offline indicator |
| File too large | Compress more aggressively, retry |
| Max photos reached | Disable add button, show message |
| Invalid file type | Show error toast, reject file |

---

## Configuration Constants

```typescript
// Photo upload configuration
export const PHOTO_CONFIG = {
  MAX_PHOTOS_PER_CARD: 10,
  MAX_FILE_SIZE_MB: 5,
  COMPRESSION_QUALITY: 0.8,
  TARGET_WIDTH: 1200,
  TARGET_HEIGHT: 1200,
  ALLOWED_TYPES: ['image/jpeg', 'image/png', 'image/heic'],
  CONCURRENT_UPLOADS: 2,
  STORAGE_BUCKET: 'card-photos',
  THUMBNAIL_SIZE: 200,
};
```

---

## Dependencies Required

```bash
# Already installed (from Stage 1)
npx expo install expo-image-picker

# Additional dependencies
npx expo install expo-file-system
npx expo install expo-image-manipulator
```

---

## Testing Checklist

- [ ] Camera capture works on iOS and Android
- [ ] Gallery selection works (single and multiple)
- [ ] Permission denied shows appropriate message
- [ ] Photos display in grid immediately after selection
- [ ] Upload progress indicator shows during upload
- [ ] Successful upload updates photo URL
- [ ] Failed upload shows error state and retry option
- [ ] Delete photo removes from grid
- [ ] Delete photo removes from storage (after save)
- [ ] Max photos limit is enforced
- [ ] Large images are compressed before upload
- [ ] Works offline (shows photos, queues uploads)
- [ ] Photos persist after app restart (saved cards)

---

## Integration Points

### With Card Edit Screen (Stage 5B/5C)

```typescript
// In CardEditScreen.tsx
import { PhotoUploader } from '@/components/photos';

function CardEditScreen() {
  const [photos, setPhotos] = useState<Photo[]>(card.photos || []);
  
  return (
    <ScrollView>
      {/* ... other form sections ... */}
      
      <Section title="Setup Photos">
        <PhotoUploader
          photos={photos}
          onPhotosChange={setPhotos}
          cardId={card.id}
          maxPhotos={10}
        />
      </Section>
    </ScrollView>
  );
}
```

### With Card API (Stage 4A/5E)

```typescript
// Photo URLs are stored as array of strings in card
interface PreferenceCard {
  // ... other fields
  setup_photos: string[];  // Array of Supabase public URLs
}

// When loading a card, convert URLs to Photo objects
function urlsToPhotos(urls: string[]): Photo[] {
  return urls.map(url => ({
    id: generateId(),
    localUri: url,
    remoteUrl: url,
    storagePath: extractPathFromUrl(url),
    uploadStatus: 'success',
    createdAt: new Date().toISOString(),
  }));
}
```
