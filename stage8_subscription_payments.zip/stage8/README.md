# Stage 8: Subscription & Payments

Complete implementation package for Stripe-based subscription system with premium feature gating.

## Package Contents

```
stage8/
├── backend/
│   ├── app/
│   │   ├── api/endpoints/
│   │   │   └── subscriptions.py       # API routes
│   │   ├── core/
│   │   │   └── stripe_config.py       # Stripe configuration
│   │   ├── schemas/
│   │   │   └── subscription.py        # Pydantic schemas
│   │   ├── services/
│   │   │   └── subscription_service.py # Business logic
│   │   └── db/
│   │       └── models_subscription.py  # Model updates
│   └── migrations/
│       └── add_subscription_fields.sql # Database migration
│
├── frontend/
│   ├── app/(tabs)/profile/
│   │   └── subscription.tsx           # Subscription screen
│   └── src/
│       ├── api/
│       │   └── subscriptions.ts       # API client
│       ├── stores/
│       │   └── subscriptionStore.ts   # Zustand store
│       ├── hooks/
│       │   ├── useSubscription.ts     # Main subscription hook
│       │   └── usePremiumFeature.ts   # Feature gating hook
│       ├── types/
│       │   └── subscription.ts        # TypeScript types
│       ├── constants/
│       │   └── subscription.ts        # Constants & config
│       └── components/
│           ├── subscription/
│           │   ├── PaywallScreen.tsx  # Main paywall
│           │   ├── PricingCard.tsx    # Plan display
│           │   ├── BenefitItem.tsx    # Benefit row
│           │   ├── PremiumBadge.tsx   # Status badge
│           │   └── index.ts
│           └── premium/
│               ├── PremiumGate.tsx    # Feature gate wrapper
│               ├── LockedOverlay.tsx  # Lock UI
│               ├── UpgradePrompt.tsx  # Modal + nudges
│               └── index.ts
│
└── README.md                          # This file
```

## Prerequisites

### Stripe Account Setup

1. **Create Stripe Account**: https://dashboard.stripe.com/register

2. **Create Products** (in Stripe Dashboard → Products):
   - **SurgicalPrep Premium Monthly**
     - Price: $4.99/month recurring
     - Note the `price_id` (e.g., `price_1ABC...`)
   - **SurgicalPrep Premium Annual**
     - Price: $29.99/year recurring
     - Note the `price_id`

3. **Set Up Webhook** (Developers → Webhooks):
   - Endpoint URL: `https://your-api.com/api/subscriptions/webhook`
   - Events to send:
     - `checkout.session.completed`
     - `customer.subscription.updated`
     - `customer.subscription.deleted`
     - `invoice.payment_succeeded`
     - `invoice.payment_failed`
   - Note the `webhook signing secret` (whsec_...)

4. **Get API Keys** (Developers → API keys):
   - Publishable key (pk_test_...)
   - Secret key (sk_test_...)

## Installation

### Backend

1. **Install Dependencies**:
```bash
pip install stripe
```

2. **Add Environment Variables** to `.env`:
```bash
STRIPE_SECRET_KEY=sk_test_your_secret_key
STRIPE_PUBLISHABLE_KEY=pk_test_your_publishable_key
STRIPE_WEBHOOK_SECRET=whsec_your_webhook_secret
STRIPE_MONTHLY_PRICE_ID=price_your_monthly_price_id
STRIPE_ANNUAL_PRICE_ID=price_your_annual_price_id
FRONTEND_URL=surgicalprep://
```

3. **Run Database Migration**:
```bash
# In Supabase SQL Editor or via psql
psql $DATABASE_URL < migrations/add_subscription_fields.sql
```

4. **Update User Model** in `app/db/models.py`:
```python
# Add these columns to your User model
stripe_customer_id = Column(String(255), nullable=True, index=True)
stripe_subscription_id = Column(String(255), nullable=True, index=True)
subscription_tier = Column(String(50), default="free", nullable=False)
subscription_status = Column(String(50), default="inactive", nullable=False)
subscription_expires_at = Column(DateTime(timezone=True), nullable=True)

# Add relationship
subscription_events = relationship(
    "SubscriptionEvent",
    back_populates="user",
    cascade="all, delete-orphan"
)
```

5. **Register Router** in `app/main.py` or `app/api/router.py`:
```python
from app.api.endpoints import subscriptions

app.include_router(subscriptions.router, prefix="/api")
# or
api_router.include_router(subscriptions.router)
```

### Frontend

1. **Install Dependencies**:
```bash
npx expo install expo-web-browser expo-linking
npm install @react-native-async-storage/async-storage expo-blur
```

2. **Copy Files** to your project:
   - Copy `frontend/src/*` to `mobile/src/`
   - Copy `frontend/app/*` to `mobile/app/`

3. **Update app.json** with deep link scheme:
```json
{
  "expo": {
    "scheme": "surgicalprep",
    "ios": {
      "bundleIdentifier": "com.yourname.surgicalprep",
      "associatedDomains": ["applinks:your-domain.com"]
    },
    "android": {
      "package": "com.yourname.surgicalprep",
      "intentFilters": [
        {
          "action": "VIEW",
          "data": [{ "scheme": "surgicalprep" }],
          "category": ["BROWSABLE", "DEFAULT"]
        }
      ]
    }
  }
}
```

4. **Add UpgradePrompt to Root Layout** (`app/_layout.tsx`):
```tsx
import UpgradePrompt from '../src/components/premium/UpgradePrompt';

export default function RootLayout() {
  return (
    <>
      <Stack>
        {/* ... your screens */}
      </Stack>
      <UpgradePrompt />
    </>
  );
}
```

## Usage Examples

### Gating a Feature

```tsx
import { PremiumGate } from '../components/premium';

function InstrumentDetail({ instrument }) {
  return (
    <View>
      <Text>{instrument.name}</Text>
      
      {/* Basic info - always visible */}
      <Text>{instrument.description}</Text>
      
      {/* Premium content - gated */}
      <PremiumGate feature="full_instrument_details">
        <View>
          <Text>Handling Notes:</Text>
          <Text>{instrument.handlingNotes}</Text>
        </View>
      </PremiumGate>
    </View>
  );
}
```

### Checking Before Action

```tsx
import { usePremiumFeature } from '../hooks/usePremiumFeature';

function CreateCardButton() {
  const { withAccessCheck } = usePremiumFeature('create_card');
  
  const handlePress = async () => {
    await withAccessCheck(() => {
      router.push('/cards/new');
    });
  };
  
  return (
    <TouchableOpacity onPress={handlePress}>
      <Text>Create Card</Text>
    </TouchableOpacity>
  );
}
```

### Showing Usage Limits

```tsx
import { UsageLimitWarning } from '../components/premium';
import { useUsageStats } from '../hooks/usePremiumFeature';

function QuizHome() {
  const { quizzes } = useUsageStats();
  
  return (
    <View>
      {quizzes.limit && (
        <UsageLimitWarning
          current={quizzes.current}
          limit={quizzes.limit}
          type="quizzes"
        />
      )}
      {/* ... rest of screen */}
    </View>
  );
}
```

### Subscription Status in Profile

```tsx
import { useSubscription } from '../hooks/useSubscription';
import { TierBadge } from '../components/subscription';

function ProfileHeader() {
  const { status, isPremium, openPortal } = useSubscription();
  
  return (
    <View>
      <Text>{user.name}</Text>
      <TierBadge tier={isPremium ? 'premium' : 'free'} />
      
      {isPremium && (
        <TouchableOpacity onPress={openPortal}>
          <Text>Manage Subscription</Text>
        </TouchableOpacity>
      )}
    </View>
  );
}
```

### Backend Feature Gating

```python
from app.api.endpoints.subscriptions import require_feature

@router.post("/cards")
async def create_card(
    card: CardCreate,
    user: User = Depends(require_feature("create_card")),
    db: AsyncSession = Depends(get_db),
):
    # User has access - proceed with card creation
    ...
```

## Testing

### Stripe Test Cards

| Card Number | Result |
|-------------|--------|
| 4242 4242 4242 4242 | Success |
| 4000 0000 0000 0002 | Declined |
| 4000 0000 0000 3220 | 3D Secure required |

Use any future expiry date and any 3-digit CVC.

### Testing Webhooks Locally

```bash
# Install Stripe CLI
brew install stripe/stripe-cli/stripe

# Login
stripe login

# Forward webhooks to local server
stripe listen --forward-to localhost:8000/api/subscriptions/webhook

# Note the webhook signing secret it provides
```

### Manual Test Flow

1. Start app, log in as free user
2. Try to create 6th preference card → should show upgrade prompt
3. Navigate to subscription screen
4. Select plan and tap Subscribe
5. Complete checkout with test card 4242...
6. Verify redirect back to app
7. Check that premium features are now accessible
8. Open customer portal, cancel subscription
9. Verify access continues until period end

## Production Checklist

- [ ] Switch Stripe keys from test to production
- [ ] Update webhook endpoint to production URL
- [ ] Verify webhook events are being received
- [ ] Test complete subscription flow
- [ ] Set up Stripe tax collection (if applicable)
- [ ] Configure Stripe customer emails
- [ ] Set up failed payment retry schedule
- [ ] Add analytics tracking for conversions

## Troubleshooting

### Webhook Not Received
- Check Stripe dashboard for failed webhook attempts
- Verify endpoint URL is correct and publicly accessible
- Check webhook signing secret matches

### User Not Marked Premium After Payment
- Check backend logs for webhook processing errors
- Verify user_id is in checkout session metadata
- Check database for subscription_events records

### Deep Link Not Working
- Verify app scheme is configured correctly
- Test with `npx uri-scheme open surgicalprep://subscription/success`
- Check iOS Associated Domains / Android intent filters

## Support

For issues with this implementation, check:
1. Stripe Dashboard logs
2. Backend error logs
3. React Query DevTools for API errors
