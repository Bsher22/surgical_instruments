/**
 * Application Constants
 */

// API Configuration
// In development, this comes from .env.local
// In production, it's set during the build process
export const API_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

// Pagination defaults
export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 100;

// Free tier limits
export const FREE_TIER_CARD_LIMIT = 5;
export const FREE_TIER_QUIZ_DAILY_LIMIT = 3;

// Cache times (in milliseconds)
export const CACHE_TIMES = {
  SHORT: 1000 * 60,       // 1 minute
  MEDIUM: 1000 * 60 * 5,  // 5 minutes
  LONG: 1000 * 60 * 30,   // 30 minutes
  PERMANENT: Infinity,     // Never stale
} as const;

// Storage keys
export const STORAGE_KEYS = {
  ACCESS_TOKEN: 'surgicalprep_access_token',
  REFRESH_TOKEN: 'surgicalprep_refresh_token',
  USER: 'surgicalprep_user',
  DRAFT_CARD: 'surgicalprep_draft_card',
  RECENT_SEARCHES: 'surgicalprep_recent_searches',
} as const;
