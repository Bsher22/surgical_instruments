// ============================================
// SurgicalPrep - Constants
// ============================================

// API Configuration
export const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000';
export const API_VERSION = '/api/v1';
export const API_URL = `${API_BASE_URL}${API_VERSION}`;

// Auth
export const TOKEN_STORAGE_KEY = 'surgicalprep_access_token';
export const REFRESH_TOKEN_STORAGE_KEY = 'surgicalprep_refresh_token';
export const USER_STORAGE_KEY = 'surgicalprep_user';

// Pagination
export const DEFAULT_PAGE_SIZE = 20;
export const MAX_PAGE_SIZE = 100;

// Search
export const SEARCH_DEBOUNCE_MS = 300;

// Free Tier Limits
export const FREE_TIER_LIMITS = {
  maxCards: 5,
  dailyQuizzes: 3,
  maxBookmarks: 20,
} as const;

// Quiz Configuration
export const QUIZ_CONFIG = {
  defaultQuestionCount: 10,
  quickQuizCount: 10,
  fullQuizCount: 30,
  timerDurationSeconds: 30,
} as const;

// Image Configuration
export const IMAGE_CONFIG = {
  maxSize: 5 * 1024 * 1024, // 5MB
  allowedTypes: ['image/jpeg', 'image/png', 'image/webp'],
  thumbnailSize: { width: 400, height: 300 },
  fullSize: { width: 800, height: 600 },
} as const;

// Spaced Repetition (SM-2 Algorithm)
export const SM2_CONFIG = {
  minEaseFactor: 1.3,
  defaultEaseFactor: 2.5,
  minInterval: 1,
  maxInterval: 365,
} as const;

// App Info
export const APP_INFO = {
  name: 'SurgicalPrep',
  version: '1.0.0',
  supportEmail: 'support@surgicalprep.app',
  privacyPolicyUrl: 'https://surgicalprep.app/privacy',
  termsOfServiceUrl: 'https://surgicalprep.app/terms',
} as const;

// Instrument Categories with Labels
export const INSTRUMENT_CATEGORIES = [
  { value: 'cutting', label: 'Cutting & Dissecting' },
  { value: 'grasping', label: 'Grasping & Holding' },
  { value: 'clamping', label: 'Clamping & Occluding' },
  { value: 'retracting', label: 'Retracting & Exposing' },
  { value: 'suturing', label: 'Suturing & Stapling' },
  { value: 'probing', label: 'Probing & Dilating' },
  { value: 'dilating', label: 'Dilating' },
  { value: 'suctioning', label: 'Suctioning & Aspirating' },
  { value: 'specialty', label: 'Specialty' },
  { value: 'other', label: 'Other' },
] as const;

// Specialties with Labels
export const SPECIALTIES = [
  { value: 'general', label: 'General Surgery' },
  { value: 'orthopedic', label: 'Orthopedic' },
  { value: 'cardiovascular', label: 'Cardiovascular' },
  { value: 'neurosurgery', label: 'Neurosurgery' },
  { value: 'obstetrics', label: 'Obstetrics' },
  { value: 'gynecology', label: 'Gynecology' },
  { value: 'urology', label: 'Urology' },
  { value: 'ent', label: 'ENT' },
  { value: 'plastic', label: 'Plastic Surgery' },
  { value: 'ophthalmic', label: 'Ophthalmic' },
  { value: 'other', label: 'Other' },
] as const;

// User Roles with Labels
export const USER_ROLES = [
  { value: 'student', label: 'Surgical Tech Student' },
  { value: 'surgical_tech', label: 'Surgical Technologist' },
  { value: 'nurse', label: 'OR Nurse' },
  { value: 'educator', label: 'Educator' },
  { value: 'other', label: 'Other' },
] as const;
