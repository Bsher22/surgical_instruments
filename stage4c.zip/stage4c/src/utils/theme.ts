/**
 * Theme Constants
 * Centralized design tokens for colors, spacing, and typography
 */
import { TextStyle } from 'react-native';

export const colors = {
  // Primary palette
  primary: '#2563EB',       // Blue-600
  primaryLight: '#DBEAFE',  // Blue-100
  primaryDark: '#1D4ED8',   // Blue-700

  // Background colors
  background: '#F9FAFB',    // Gray-50
  surface: '#FFFFFF',
  surfaceSecondary: '#F3F4F6', // Gray-100

  // Text colors
  text: '#111827',          // Gray-900
  textSecondary: '#6B7280', // Gray-500
  textTertiary: '#9CA3AF',  // Gray-400

  // Border colors
  border: '#E5E7EB',        // Gray-200
  borderFocus: '#2563EB',   // Blue-600

  // Semantic colors
  success: '#10B981',       // Emerald-500
  successLight: '#D1FAE5',  // Emerald-100
  warning: '#F59E0B',       // Amber-500
  warningLight: '#FEF3C7',  // Amber-100
  error: '#EF4444',         // Red-500
  errorLight: '#FEE2E2',    // Red-100
  info: '#3B82F6',          // Blue-500
  infoLight: '#DBEAFE',     // Blue-100

  // Category colors
  categoryInstrument: '#3B82F6',  // Blue
  categorySupply: '#10B981',      // Green
  categorySuture: '#8B5CF6',      // Purple
  categoryImplant: '#F59E0B',     // Amber
  categoryOther: '#6B7280',       // Gray

  // Premium colors
  premium: '#7C3AED',       // Violet-600
  premiumLight: '#EDE9FE',  // Violet-100

  // Neutral
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',

  // Overlay
  overlay: 'rgba(0, 0, 0, 0.5)',
  overlayLight: 'rgba(0, 0, 0, 0.3)',
};

export const spacing = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

export const borderRadius = {
  xs: 4,
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  full: 9999,
};

export const typography: Record<string, TextStyle> = {
  // Headers
  h1: {
    fontSize: 24,
    fontWeight: '700',
    lineHeight: 32,
    letterSpacing: -0.5,
  },
  h2: {
    fontSize: 20,
    fontWeight: '600',
    lineHeight: 28,
    letterSpacing: -0.3,
  },
  h3: {
    fontSize: 18,
    fontWeight: '600',
    lineHeight: 24,
  },

  // Body text
  body: {
    fontSize: 16,
    fontWeight: '400',
    lineHeight: 24,
  },
  bodySmall: {
    fontSize: 14,
    fontWeight: '400',
    lineHeight: 20,
  },

  // UI elements
  subtitle: {
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
  },
  caption: {
    fontSize: 12,
    fontWeight: '400',
    lineHeight: 16,
  },
  button: {
    fontSize: 16,
    fontWeight: '600',
    lineHeight: 24,
  },
  buttonSmall: {
    fontSize: 14,
    fontWeight: '600',
    lineHeight: 20,
  },

  // Labels
  label: {
    fontSize: 14,
    fontWeight: '500',
    lineHeight: 20,
  },
  labelSmall: {
    fontSize: 12,
    fontWeight: '500',
    lineHeight: 16,
  },
};

export const shadows = {
  sm: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 1 },
    shadowOpacity: 0.05,
    shadowRadius: 2,
    elevation: 1,
  },
  md: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 2,
  },
  lg: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.15,
    shadowRadius: 8,
    elevation: 4,
  },
};

// Animation timings
export const animation = {
  fast: 150,
  normal: 250,
  slow: 400,
};

// Hit slop for touch targets
export const hitSlop = {
  small: { top: 5, bottom: 5, left: 5, right: 5 },
  medium: { top: 10, bottom: 10, left: 10, right: 10 },
  large: { top: 15, bottom: 15, left: 15, right: 15 },
};
