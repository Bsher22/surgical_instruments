# Stage 4A: Cards API Layer

This stage implements the API layer for preference cards, providing typed API functions and React Query hooks for data fetching and mutations.

## Files Overview

```
src/
├── api/
│   ├── client.ts        # Axios client with auth interceptors
│   └── cards.ts         # Cards API functions
├── hooks/
│   └── useCards.ts      # React Query hooks for cards
├── types/
│   └── cards.ts         # TypeScript types for cards
└── utils/
    └── constants.ts     # App constants (API URL, limits, etc.)
```

## Types (`src/types/cards.ts`)

### Core Types
- `PreferenceCard` - Main card entity
- `CardItem` - Items on a card (instruments, supplies, etc.)
- `CardPhoto` - Setup photos attached to cards
- `CardWithDetails` - Card with full items and photos

### Enums
- `CardItemCategory` - instrument, supply, suture, implant, equipment, other
- `Specialty` - general, orthopedic, cardiovascular, neurosurgery, etc.

### Helper Functions
- `groupItemsByCategory(items)` - Groups card items by category for display

## API Functions (`src/api/cards.ts`)

### Read Operations
```typescript
// Get paginated list of user's cards
getCards(params: GetCardsParams): Promise<PaginatedCardsResponse>

// Get single card with all details
getCard(cardId: string): Promise<CardWithDetails>

// Get public template cards
getTemplates(specialty?: string): Promise<PreferenceCard[]>

// Search cards
searchCards(query: string): Promise<PreferenceCard[]>
```

### Write Operations
```typescript
// CRUD
createCard(data: PreferenceCardCreate): Promise<CardWithDetails>
updateCard(cardId: string, data: PreferenceCardUpdate): Promise<CardWithDetails>
deleteCard(cardId: string): Promise<void>
duplicateCard(cardId: string): Promise<CardWithDetails>

// Item management
addCardItem(cardId, item): Promise<CardWithDetails>
updateCardItem(cardId, itemId, data): Promise<CardWithDetails>
removeCardItem(cardId, itemId): Promise<void>
reorderCardItems(cardId, itemIds[]): Promise<CardWithDetails>

// Photo management
addCardPhoto(cardId, photo): Promise<CardPhoto>
updateCardPhoto(cardId, photoId, data): Promise<CardPhoto>
deleteCardPhoto(cardId, photoId): Promise<void>
```

### Utility Functions
```typescript
checkCardLimit(): Promise<{ canCreate: boolean; current: number; limit: number }>
getCardCount(): Promise<number>
```

## React Query Hooks (`src/hooks/useCards.ts`)

### Query Hooks
```typescript
// List with pagination
useCards(params?: GetCardsParams)

// Infinite scroll version
useInfiniteCards(params?)

// Single card detail
useCard(cardId: string)

// Templates
useTemplates(specialty?: Specialty)

// Search
useSearchCards(query: string)

// Limits
useCardLimit()
useCardCount()
```

### Mutation Hooks
```typescript
// Card CRUD
useCreateCard()
useUpdateCard()
useDeleteCard()
useDuplicateCard()

// Item mutations
useAddCardItem()
useUpdateCardItem()
useRemoveCardItem()
useReorderCardItems()

// Photo mutations
useAddCardPhoto()
useUpdateCardPhoto()
useDeleteCardPhoto()
```

### Prefetching
```typescript
usePrefetchCard() -> (cardId) => void
usePrefetchTemplates() -> (specialty?) => void
```

## Usage Examples

### Fetching Cards List
```tsx
function CardsList() {
  const { data, isLoading, error } = useCards({
    specialty: 'orthopedic',
    search: 'knee',
    limit: 20,
  });

  if (isLoading) return <LoadingSkeleton />;
  if (error) return <ErrorMessage error={error} />;

  return (
    <FlatList
      data={data?.items}
      renderItem={({ item }) => <CardItem card={item} />}
    />
  );
}
```

### Infinite Scroll
```tsx
function CardsInfiniteList() {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useInfiniteCards({ specialty: 'general' });

  const cards = data?.pages.flatMap(page => page.items) ?? [];

  return (
    <FlatList
      data={cards}
      onEndReached={() => hasNextPage && fetchNextPage()}
      ListFooterComponent={isFetchingNextPage ? <Spinner /> : null}
    />
  );
}
```

### Creating a Card
```tsx
function CreateCardForm() {
  const createCard = useCreateCard({
    onSuccess: (newCard) => {
      navigation.navigate('CardDetail', { id: newCard.id });
    },
    onError: (error) => {
      Toast.show({ type: 'error', text1: getErrorMessage(error) });
    },
  });

  const handleSubmit = (data: PreferenceCardCreate) => {
    createCard.mutate(data);
  };

  return (
    <Form onSubmit={handleSubmit}>
      {/* form fields */}
      <Button 
        onPress={handleSubmit} 
        loading={createCard.isPending}
      >
        Create Card
      </Button>
    </Form>
  );
}
```

### Card Detail with Items
```tsx
function CardDetail({ cardId }: { cardId: string }) {
  const { data: card, isLoading } = useCard(cardId);
  const deleteCard = useDeleteCard();

  if (isLoading) return <LoadingSkeleton />;
  if (!card) return <NotFound />;

  const groupedItems = groupItemsByCategory(card.items);

  return (
    <ScrollView>
      <CardHeader card={card} />
      
      {Object.entries(groupedItems).map(([category, items]) => (
        items.length > 0 && (
          <ItemSection 
            key={category}
            title={CATEGORY_LABELS[category]}
            items={items}
          />
        )
      ))}
      
      <PhotoCarousel photos={card.photos} />
    </ScrollView>
  );
}
```

### Checking Free Tier Limit
```tsx
function CreateCardButton() {
  const { data: limitInfo } = useCardLimit();

  if (!limitInfo?.canCreate) {
    return (
      <View>
        <Text>Card limit reached ({limitInfo?.current}/{limitInfo?.limit})</Text>
        <Button onPress={navigateToUpgrade}>Upgrade to Premium</Button>
      </View>
    );
  }

  return <Button onPress={navigateToCreate}>Create Card</Button>;
}
```

## Query Keys

The `cardKeys` factory provides consistent cache key management:

```typescript
cardKeys.all           // ['cards']
cardKeys.lists()       // ['cards', 'list']
cardKeys.list(params)  // ['cards', 'list', params]
cardKeys.detail(id)    // ['cards', 'detail', id]
cardKeys.templates()   // ['cards', 'templates']
cardKeys.limit()       // ['cards', 'limit']
```

## Cache Invalidation

Mutations automatically invalidate relevant queries:
- Create/Delete card → Invalidates lists, count, limit
- Update card → Invalidates that card's detail and lists
- Item/Photo changes → Invalidates parent card detail

## Next Steps (Stage 4B & 4C)

- [ ] **4B**: Cards List Screen UI
- [ ] **4C**: Card Detail/View Screen UI
