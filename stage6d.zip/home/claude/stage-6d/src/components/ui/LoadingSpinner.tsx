// LoadingSpinner Component
import React from 'react';
import { View, StyleSheet, ActivityIndicator, Text } from 'react-native';
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withRepeat,
  withTiming,
  Easing,
} from 'react-native-reanimated';

interface LoadingSpinnerProps {
  size?: 'small' | 'medium' | 'large';
  color?: string;
  label?: string;
}

export function LoadingSpinner({
  size = 'medium',
  color = '#3B82F6',
  label,
}: LoadingSpinnerProps) {
  const sizeMap = {
    small: 20,
    medium: 36,
    large: 48,
  };

  const activitySize = size === 'small' ? 'small' : 'large';

  return (
    <View style={styles.container}>
      <ActivityIndicator size={activitySize} color={color} />
      {label && <Text style={styles.label}>{label}</Text>}
    </View>
  );
}

// Custom animated spinner
interface CustomSpinnerProps {
  size?: number;
  color?: string;
  strokeWidth?: number;
}

export function CustomSpinner({
  size = 40,
  color = '#3B82F6',
  strokeWidth = 3,
}: CustomSpinnerProps) {
  const rotation = useSharedValue(0);

  React.useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, {
        duration: 1000,
        easing: Easing.linear,
      }),
      -1,
      false
    );
  }, [rotation]);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }],
  }));

  return (
    <Animated.View
      style={[
        {
          width: size,
          height: size,
          borderRadius: size / 2,
          borderWidth: strokeWidth,
          borderColor: '#E5E7EB',
          borderTopColor: color,
        },
        animatedStyle,
      ]}
    />
  );
}

// Full screen loading overlay
interface LoadingOverlayProps {
  visible: boolean;
  message?: string;
}

export function LoadingOverlay({ visible, message }: LoadingOverlayProps) {
  if (!visible) return null;

  return (
    <View style={styles.overlay}>
      <View style={styles.overlayContent}>
        <LoadingSpinner size="large" />
        {message && <Text style={styles.overlayMessage}>{message}</Text>}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
  },
  label: {
    fontSize: 14,
    color: '#6B7280',
    marginTop: 4,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: 'rgba(255, 255, 255, 0.9)',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 1000,
  },
  overlayContent: {
    alignItems: 'center',
    gap: 16,
    padding: 32,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 8,
  },
  overlayMessage: {
    fontSize: 16,
    color: '#1F2937',
    fontWeight: '500',
  },
});
