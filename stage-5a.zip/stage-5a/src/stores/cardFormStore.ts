/**
 * Card Form Zustand Store
 * 
 * Manages all state for preference card creation and editing,
 * including form data, validation, dirty tracking, and draft persistence.
 */

import { create } from 'zustand';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {
  CardFormStore,
  CardFormData,
  CardFormItem,
  CardFormPhoto,
  FormValidationErrors,
  CardDraft,
  CardDraftMetadata,
  PreferenceCardWithItems,
  ItemCategory,
} from '../types/cardForm';
import {
  createEmptyFormData,
  createDefaultItem,
  generateItemId,
  generatePhotoId,
  cardToFormData,
  validateFormData,
  hasValidationErrors,
  deepCompareFormData,
  getDraftKey,
  reorderArray,
  updateItemOrders,
} from '../utils/cardFormUtils';

/**
 * Current draft version - increment when draft structure changes
 */
const DRAFT_VERSION = 1;

/**
 * Initial state values
 */
const initialState = {
  formData: createEmptyFormData(),
  originalData: null,
  isDirty: false,
  isLoading: false,
  isSaving: false,
  lastSavedAt: null,
  validationErrors: {},
  draftKey: null,
  isEditing: false,
};

/**
 * Create the card form store
 */
export const useCardFormStore = create<CardFormStore>((set, get) => ({
  // Initial state
  ...initialState,

  /**
   * Reset to blank form for new card
   */
  initializeNewCard: () => {
    const emptyData = createEmptyFormData();
    set({
      formData: emptyData,
      originalData: null,
      isDirty: false,
      isLoading: false,
      isSaving: false,
      lastSavedAt: null,
      validationErrors: {},
      draftKey: getDraftKey(),
      isEditing: false,
    });
  },

  /**
   * Load existing card for editing
   */
  initializeFromCard: (card: PreferenceCardWithItems) => {
    const formData = cardToFormData(card);
    set({
      formData,
      originalData: formData,
      isDirty: false,
      isLoading: false,
      isSaving: false,
      lastSavedAt: null,
      validationErrors: {},
      draftKey: getDraftKey(card.id),
      isEditing: true,
    });
  },

  /**
   * Restore from saved draft
   */
  initializeFromDraft: async (draft: CardDraft) => {
    set({
      formData: draft.formData,
      originalData: draft.formData.id ? draft.formData : null,
      isDirty: true, // Draft is always considered dirty
      isLoading: false,
      isSaving: false,
      lastSavedAt: new Date(draft.metadata.savedAt),
      validationErrors: {},
      draftKey: getDraftKey(draft.formData.id),
      isEditing: !!draft.formData.id,
    });
  },

  /**
   * Update a single form field
   */
  updateField: <K extends keyof CardFormData>(
    field: K,
    value: CardFormData[K]
  ) => {
    set((state) => {
      const newFormData = { ...state.formData, [field]: value };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);
      return {
        formData: newFormData,
        isDirty,
        // Clear field-specific validation error when user edits
        validationErrors: {
          ...state.validationErrors,
          [field]: undefined,
        },
      };
    });
  },

  /**
   * Add item to card
   */
  addItem: (itemData: Partial<CardFormItem>) => {
    set((state) => {
      const newItem = createDefaultItem({
        ...itemData,
        order: state.formData.items.filter((i) => !i.isDeleted).length,
        isNew: true,
      });

      const newItems = [...state.formData.items, newItem];
      const newFormData = { ...state.formData, items: newItems };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);

      return {
        formData: newFormData,
        isDirty,
        validationErrors: {
          ...state.validationErrors,
          items: undefined,
        },
      };
    });
  },

  /**
   * Update existing item
   */
  updateItem: (itemId: string, updates: Partial<CardFormItem>) => {
    set((state) => {
      const newItems = state.formData.items.map((item) =>
        item.id === itemId ? { ...item, ...updates } : item
      );
      const newFormData = { ...state.formData, items: newItems };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);

      return {
        formData: newFormData,
        isDirty,
      };
    });
  },

  /**
   * Remove item from card (marks for deletion if existing)
   */
  removeItem: (itemId: string) => {
    set((state) => {
      const item = state.formData.items.find((i) => i.id === itemId);
      if (!item) return state;

      let newItems: CardFormItem[];
      if (item.isNew) {
        // For new items, just remove from array
        newItems = state.formData.items.filter((i) => i.id !== itemId);
      } else {
        // For existing items, mark as deleted
        newItems = state.formData.items.map((i) =>
          i.id === itemId ? { ...i, isDeleted: true } : i
        );
      }

      // Update order for remaining visible items
      newItems = updateItemOrders(
        newItems.filter((i) => !i.isDeleted)
      ).concat(newItems.filter((i) => i.isDeleted));

      const newFormData = { ...state.formData, items: newItems };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);

      return {
        formData: newFormData,
        isDirty,
      };
    });
  },

  /**
   * Reorder items via drag-and-drop
   */
  reorderItems: (fromIndex: number, toIndex: number) => {
    set((state) => {
      // Get only visible items for reordering
      const visibleItems = state.formData.items.filter((i) => !i.isDeleted);
      const deletedItems = state.formData.items.filter((i) => i.isDeleted);

      // Reorder visible items
      const reordered = reorderArray(visibleItems, fromIndex, toIndex);
      
      // Update order values
      const withNewOrders = updateItemOrders(reordered);

      const newItems = [...withNewOrders, ...deletedItems];
      const newFormData = { ...state.formData, items: newItems };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);

      return {
        formData: newFormData,
        isDirty,
      };
    });
  },

  /**
   * Add photo to card
   */
  addPhoto: (uri: string) => {
    set((state) => {
      const newPhoto: CardFormPhoto = {
        id: generatePhotoId(),
        uri,
        isNew: true,
        isDeleted: false,
      };

      const newPhotos = [...state.formData.photos, newPhoto];
      const newFormData = { ...state.formData, photos: newPhotos };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);

      return {
        formData: newFormData,
        isDirty,
      };
    });
  },

  /**
   * Remove photo from card (marks for deletion if existing)
   */
  removePhoto: (photoId: string) => {
    set((state) => {
      const photo = state.formData.photos.find((p) => p.id === photoId);
      if (!photo) return state;

      let newPhotos: CardFormPhoto[];
      if (photo.isNew) {
        // For new photos, just remove from array
        newPhotos = state.formData.photos.filter((p) => p.id !== photoId);
      } else {
        // For existing photos, mark as deleted
        newPhotos = state.formData.photos.map((p) =>
          p.id === photoId ? { ...p, isDeleted: true } : p
        );
      }

      const newFormData = { ...state.formData, photos: newPhotos };
      const isDirty = !deepCompareFormData(newFormData, state.originalData);

      return {
        formData: newFormData,
        isDirty,
      };
    });
  },

  /**
   * Update photo (e.g., after upload)
   */
  updatePhoto: (photoId: string, updates: Partial<CardFormPhoto>) => {
    set((state) => {
      const newPhotos = state.formData.photos.map((photo) =>
        photo.id === photoId ? { ...photo, ...updates } : photo
      );
      const newFormData = { ...state.formData, photos: newPhotos };

      return {
        formData: newFormData,
      };
    });
  },

  /**
   * Run validation, return success
   */
  validate: () => {
    const { formData } = get();
    const errors = validateFormData(formData);
    set({ validationErrors: errors });
    return !hasValidationErrors(errors);
  },

  /**
   * Clear validation errors
   */
  clearValidationErrors: () => {
    set({ validationErrors: {} });
  },

  /**
   * Save current state to AsyncStorage
   */
  saveDraft: async () => {
    const { formData, draftKey } = get();
    if (!draftKey) return;

    try {
      const metadata: CardDraftMetadata = {
        savedAt: new Date().toISOString(),
        cardId: formData.id,
        cardTitle: formData.title || 'Untitled Card',
        version: DRAFT_VERSION,
      };

      const draft: CardDraft = {
        metadata,
        formData,
      };

      await AsyncStorage.setItem(draftKey, JSON.stringify(draft));
      set({ lastSavedAt: new Date() });
    } catch (error) {
      console.error('Failed to save draft:', error);
      throw error;
    }
  },

  /**
   * Remove draft from AsyncStorage
   */
  clearDraft: async () => {
    const { draftKey } = get();
    if (!draftKey) return;

    try {
      await AsyncStorage.removeItem(draftKey);
      set({ lastSavedAt: null });
    } catch (error) {
      console.error('Failed to clear draft:', error);
      throw error;
    }
  },

  /**
   * Clear all form state
   */
  reset: () => {
    set(initialState);
  },

  /**
   * Update originalData, clear dirty flag (after successful save)
   */
  markAsSaved: () => {
    set((state) => ({
      originalData: state.formData,
      isDirty: false,
    }));
  },

  /**
   * Set loading state
   */
  setIsLoading: (loading: boolean) => {
    set({ isLoading: loading });
  },

  /**
   * Set saving state
   */
  setIsSaving: (saving: boolean) => {
    set({ isSaving: saving });
  },
}));

/**
 * Selector hooks for commonly used state slices
 */

/**
 * Get just the form data
 */
export const useCardFormData = () => useCardFormStore((state) => state.formData);

/**
 * Get dirty state
 */
export const useCardFormIsDirty = () => useCardFormStore((state) => state.isDirty);

/**
 * Get validation errors
 */
export const useCardFormErrors = () => 
  useCardFormStore((state) => state.validationErrors);

/**
 * Get loading/saving states
 */
export const useCardFormStatus = () => 
  useCardFormStore((state) => ({
    isLoading: state.isLoading,
    isSaving: state.isSaving,
    lastSavedAt: state.lastSavedAt,
  }));

/**
 * Get visible items (non-deleted)
 */
export const useCardFormVisibleItems = () =>
  useCardFormStore((state) =>
    state.formData.items
      .filter((item) => !item.isDeleted)
      .sort((a, b) => a.order - b.order)
  );

/**
 * Get visible photos (non-deleted)
 */
export const useCardFormVisiblePhotos = () =>
  useCardFormStore((state) =>
    state.formData.photos.filter((photo) => !photo.isDeleted)
  );

/**
 * Get form actions (stable references)
 */
export const useCardFormActions = () =>
  useCardFormStore((state) => ({
    initializeNewCard: state.initializeNewCard,
    initializeFromCard: state.initializeFromCard,
    initializeFromDraft: state.initializeFromDraft,
    updateField: state.updateField,
    addItem: state.addItem,
    updateItem: state.updateItem,
    removeItem: state.removeItem,
    reorderItems: state.reorderItems,
    addPhoto: state.addPhoto,
    removePhoto: state.removePhoto,
    updatePhoto: state.updatePhoto,
    validate: state.validate,
    clearValidationErrors: state.clearValidationErrors,
    saveDraft: state.saveDraft,
    clearDraft: state.clearDraft,
    reset: state.reset,
    markAsSaved: state.markAsSaved,
    setIsLoading: state.setIsLoading,
    setIsSaving: state.setIsSaving,
  }));
