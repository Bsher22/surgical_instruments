# Stage 11: Testing & QA - Implementation Outline

## Overview

Stage 11 establishes a comprehensive testing strategy for SurgicalPrep, covering backend unit/integration tests, frontend component/integration tests, manual testing procedures, and beta testing infrastructure. This ensures the application is stable, performant, and ready for production launch.

---

## 11A: Backend Tests (Pytest)

### Purpose
Create a robust pytest test suite covering all API endpoints, business logic, authentication flows, and premium feature gating.

### Test Structure
```
backend/
├── tests/
│   ├── __init__.py
│   ├── conftest.py              # Shared fixtures, test database setup
│   ├── test_auth.py             # Authentication endpoint tests
│   ├── test_users.py            # User management tests
│   ├── test_instruments.py      # Instrument CRUD tests
│   ├── test_preference_cards.py # Preference card CRUD tests
│   ├── test_quiz.py             # Quiz session and logic tests
│   ├── test_study_progress.py   # Spaced repetition and progress tests
│   └── test_premium.py          # Premium gating and subscription tests
```

### Key Testing Patterns

1. **Test Database Isolation**
   - Use async test fixtures with transaction rollback
   - Each test gets a clean database state
   - Factory functions for creating test data

2. **Authentication Testing**
   - Token generation and validation
   - Password hashing verification
   - Token refresh flow
   - Invalid credentials handling

3. **CRUD Operations**
   - Create, Read, Update, Delete for all entities
   - Pagination and filtering
   - Search functionality
   - Relationship handling (cards with items)

4. **Business Logic**
   - Quiz question generation
   - Spaced repetition algorithm (SM-2)
   - Score calculation
   - Progress tracking

5. **Premium Gating**
   - Free tier limits (5 cards, 3 quizzes/day)
   - Premium feature access
   - Subscription status validation

### Test Fixtures Provided
- `async_client`: AsyncClient for API testing
- `test_db`: Test database session
- `test_user`: Pre-created test user
- `auth_headers`: JWT token headers
- `premium_user`: User with premium subscription
- `sample_instruments`: Pre-populated instruments
- `sample_card`: Pre-created preference card

---

## 11B: Frontend Tests (Jest + React Native Testing Library)

### Purpose
Test React Native components, hooks, form validation, navigation flows, and API integration.

### Test Structure
```
mobile/
├── __tests__/
│   ├── setup.ts                    # Jest setup and mocks
│   ├── utils/
│   │   └── test-utils.tsx          # Custom render with providers
│   ├── components/
│   │   ├── ui/
│   │   │   ├── Button.test.tsx
│   │   │   ├── Input.test.tsx
│   │   │   └── Card.test.tsx
│   │   ├── InstrumentCard.test.tsx
│   │   ├── PreferenceCardItem.test.tsx
│   │   ├── FlashCard.test.tsx
│   │   └── QuizQuestion.test.tsx
│   ├── hooks/
│   │   ├── useAuth.test.ts
│   │   ├── useInstruments.test.ts
│   │   └── useQuiz.test.ts
│   ├── screens/
│   │   ├── auth/
│   │   │   ├── LoginScreen.test.tsx
│   │   │   └── SignupScreen.test.tsx
│   │   ├── instruments/
│   │   │   ├── InstrumentListScreen.test.tsx
│   │   │   └── InstrumentDetailScreen.test.tsx
│   │   ├── cards/
│   │   │   ├── CardListScreen.test.tsx
│   │   │   └── CardEditScreen.test.tsx
│   │   └── quiz/
│   │       ├── QuizHomeScreen.test.tsx
│   │       └── FlashcardSession.test.tsx
│   ├── api/
│   │   └── client.test.ts
│   └── stores/
│       ├── authStore.test.ts
│       └── quizStore.test.ts
```

### Testing Patterns

1. **Component Testing**
   - Render testing with React Native Testing Library
   - User interaction simulation
   - Accessibility verification
   - Snapshot testing for UI consistency

2. **Hook Testing**
   - Custom hook behavior with `@testing-library/react-hooks`
   - State management verification
   - Side effect testing

3. **Form Validation**
   - Required field validation
   - Email format validation
   - Password requirements
   - Error message display

4. **Navigation Testing**
   - Screen navigation flows
   - Parameter passing
   - Deep linking

5. **API Mocking**
   - MSW (Mock Service Worker) for API mocks
   - Loading state verification
   - Error handling
   - Retry logic

### Mock Utilities Provided
- Navigation mock for Expo Router
- Secure storage mock
- Haptic feedback mock
- Image picker mock
- Gesture handler mock
- Reanimated mock

---

## 11C: Manual Testing Checklist

### Purpose
Comprehensive checklist for manual QA testing across all features and platforms.

### Checklist Categories

1. **Authentication Flow**
   - [ ] Sign up with valid email
   - [ ] Sign up with existing email (error handling)
   - [ ] Login with correct credentials
   - [ ] Login with wrong password
   - [ ] Token refresh after expiry
   - [ ] Logout clears all data
   - [ ] Password reset flow

2. **Instruments**
   - [ ] List loads and paginates correctly
   - [ ] Pull-to-refresh works
   - [ ] Search returns accurate results
   - [ ] Category filter functions
   - [ ] Detail screen loads all data
   - [ ] Images load and zoom works
   - [ ] Bookmark toggle persists
   - [ ] Premium lock shows for gated content

3. **Preference Cards**
   - [ ] Card list displays correctly
   - [ ] Search/filter works
   - [ ] Create new card flow
   - [ ] Add items from instrument search
   - [ ] Add custom items
   - [ ] Edit existing card
   - [ ] Delete card with confirmation
   - [ ] Duplicate card creates copy
   - [ ] Photo upload from camera
   - [ ] Photo upload from gallery
   - [ ] Auto-save draft works
   - [ ] Free tier limit enforced (5 cards)

4. **Quiz & Study**
   - [ ] Flashcard session starts
   - [ ] Card flip animation works
   - [ ] Swipe gestures register correctly
   - [ ] Progress saves after session
   - [ ] Multiple choice quiz functions
   - [ ] Timer works (if enabled)
   - [ ] Results display accurately
   - [ ] Review mistakes navigation
   - [ ] Daily limit enforced (free tier)
   - [ ] Spaced repetition scheduling

5. **Profile & Settings**
   - [ ] Profile info displays
   - [ ] Edit profile saves
   - [ ] Subscription status accurate
   - [ ] Settings persist
   - [ ] Dark mode toggle (if implemented)
   - [ ] Logout works completely

6. **Edge Cases**
   - [ ] Offline behavior
   - [ ] Network error handling
   - [ ] Empty states display
   - [ ] Very long text handling
   - [ ] Rapid tap protection
   - [ ] Background/foreground transitions

7. **Platform-Specific (iOS)**
   - [ ] Safe area handling
   - [ ] Keyboard avoiding
   - [ ] Haptic feedback
   - [ ] Share sheet integration

8. **Platform-Specific (Android)**
   - [ ] Back button behavior
   - [ ] Status bar styling
   - [ ] Hardware keyboard support
   - [ ] Permission dialogs

---

## 11D: Beta Testing Setup

### Purpose
Establish beta testing infrastructure for collecting user feedback before public launch.

### TestFlight Setup (iOS)
1. Configure App Store Connect
2. Create beta testing group
3. Upload build via EAS
4. Invite internal testers (up to 100)
5. Set up external testing (up to 10,000)

### Google Play Internal Testing (Android)
1. Create internal testing track
2. Upload AAB via EAS
3. Add tester email list
4. Configure opt-in URL

### Beta Tester Recruitment
Target communities:
- r/scrubtech subreddit
- Surgical Tech Facebook groups
- LinkedIn professional networks
- Local hospital contacts
- Surgical tech school programs

### Feedback Collection
- Google Forms/Typeform survey
- In-app feedback button
- Crash reporting (Sentry)
- Analytics events
- Direct email support

### Feedback Categories
1. Bug reports (severity levels)
2. Feature requests
3. UX/UI feedback
4. Performance issues
5. Content accuracy

---

## Files Included in This Package

### Backend Tests
```
backend/tests/
├── __init__.py
├── conftest.py
├── test_auth.py
├── test_users.py
├── test_instruments.py
├── test_preference_cards.py
├── test_quiz.py
├── test_study_progress.py
└── test_premium.py
```

### Frontend Tests
```
mobile/__tests__/
├── setup.ts
├── utils/
│   └── test-utils.tsx
├── mocks/
│   ├── navigation.ts
│   ├── expo-modules.ts
│   └── handlers.ts (MSW)
├── components/
│   └── [component tests]
├── hooks/
│   └── [hook tests]
├── screens/
│   └── [screen tests]
├── api/
│   └── client.test.ts
└── stores/
    └── [store tests]
```

### Configuration Files
```
├── jest.config.js
├── jest.setup.js
├── pytest.ini
└── .env.test
```

### Documentation
```
├── STAGE_11_OUTLINE.md
├── MANUAL_TESTING_CHECKLIST.md
├── BETA_TESTING_GUIDE.md
└── TEST_COVERAGE_REPORT.md
```

---

## Running Tests

### Backend
```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=app --cov-report=html

# Run specific test file
pytest tests/test_auth.py -v

# Run specific test
pytest tests/test_auth.py::test_login_success -v
```

### Frontend
```bash
# Run all tests
npm test

# Run with coverage
npm test -- --coverage

# Run in watch mode
npm test -- --watch

# Run specific test file
npm test -- InstrumentCard.test.tsx
```

---

## Test Coverage Goals

| Area | Target Coverage |
|------|-----------------|
| Backend API endpoints | 90%+ |
| Backend business logic | 95%+ |
| Frontend components | 80%+ |
| Frontend hooks | 85%+ |
| Critical user flows | 100% |

---

## Next Steps After Stage 11

1. Address any failing tests
2. Fix bugs discovered during manual testing
3. Incorporate beta tester feedback
4. Proceed to Stage 12: Launch Preparation
