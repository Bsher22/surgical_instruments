# Stage 6A: Quiz API Layer

## Overview

This stage implements the complete API layer for the Quiz & Study system in SurgicalPrep. It includes TypeScript types, API client functions, React Query hooks, and a Zustand store for managing quiz/flashcard session state.

## Contents

```
src/
├── types/
│   └── quiz.ts          # All TypeScript types for quiz system
├── api/
│   └── quiz.ts          # API client functions
├── hooks/
│   └── useQuiz.ts       # React Query hooks
├── stores/
│   └── quizStore.ts     # Zustand store for session state
└── index.ts             # Clean exports
```

## Installation

1. Copy the `src/` files to your project's `src/` directory:
   - `src/types/quiz.ts`
   - `src/api/quiz.ts`
   - `src/hooks/useQuiz.ts`
   - `src/stores/quizStore.ts`

2. Update your main `src/types/index.ts` to export quiz types:
   ```typescript
   export * from './quiz';
   ```

3. Ensure dependencies are installed:
   ```bash
   npm install @tanstack/react-query zustand @react-native-async-storage/async-storage
   ```

## Prerequisites

This stage requires:
- **Stage 2B API Client** (`src/api/client.ts`) - The base axios client with auth interceptors
- **React Query Provider** already configured in your app
- **Zustand** for state management

## API Client Functions

### Quiz Sessions

```typescript
import { startQuizSession, submitQuizAnswer, endQuizSession } from '@/api/quiz';

// Start a new quiz
const { session } = await startQuizSession({
  quiz_type: 'multiple_choice',
  question_count: 10,
  categories: ['General Surgery', 'Orthopedic'],
  difficulty: 'mixed',
});

// Submit an answer
const result = await submitQuizAnswer({
  session_id: session.id,
  question_id: 'q123',
  selected_option_id: 'opt_a',
  time_taken_seconds: 15,
});

// End session and get results
const finalResult = await endQuizSession(session.id);
```

### Flashcard Sessions

```typescript
import { startFlashcardSession, recordFlashcardResult } from '@/api/quiz';

// Start flashcard session
const { session } = await startFlashcardSession({
  card_count: 20,
  include_due_for_review: true,
});

// Record swipe result
await recordFlashcardResult({
  session_id: session.id,
  flashcard_id: 'fc123',
  instrument_id: 'inst456',
  result: 'got_it', // or 'study_more'
});
```

### Study Progress

```typescript
import { getStudyProgress, getDueForReview } from '@/api/quiz';

// Get overall progress
const progress = await getStudyProgress();
console.log(`Studied ${progress.total_instruments_studied} instruments`);
console.log(`Current streak: ${progress.current_streak} days`);

// Get items due for review
const { instruments, total_due } = await getDueForReview({
  limit: 20,
  include_overdue: true,
});
```

## React Query Hooks

### Study Progress

```typescript
import { useStudyProgress, useDueForReview } from '@/hooks/useQuiz';

function StudyDashboard() {
  const { data: progress, isLoading } = useStudyProgress();
  const { data: dueItems } = useDueForReview({ limit: 10 });

  if (isLoading) return <LoadingSpinner />;

  return (
    <View>
      <Text>Instruments Studied: {progress?.total_instruments_studied}</Text>
      <Text>Due for Review: {dueItems?.total_due}</Text>
    </View>
  );
}
```

### Starting a Quiz

```typescript
import { useStartQuizSession, useSubmitQuizAnswer } from '@/hooks/useQuiz';
import { useQuizStore } from '@/stores/quizStore';

function QuizScreen() {
  const startQuiz = useStartQuizSession();
  const submitAnswer = useSubmitQuizAnswer();
  const { currentQuestion, selectedAnswer, setSelectedAnswer } = useQuizStore();

  const handleStartQuiz = async () => {
    const result = await startQuiz.mutateAsync({
      quiz_type: 'multiple_choice',
      question_count: 10,
    });
    // Session is automatically cached
  };

  const handleSubmit = async () => {
    if (!selectedAnswer) return;
    
    const result = await submitAnswer.mutateAsync({
      session_id: sessionId,
      question_id: currentQuestion.id,
      selected_option_id: selectedAnswer,
    });
    
    // Show feedback, then move to next question
  };
}
```

### Infinite Scroll for History

```typescript
import { useQuizHistoryInfinite } from '@/hooks/useQuiz';

function QuizHistoryScreen() {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useQuizHistoryInfinite({ quiz_type: 'multiple_choice' });

  const sessions = data?.pages.flatMap(page => page.sessions) ?? [];

  return (
    <FlatList
      data={sessions}
      onEndReached={() => hasNextPage && fetchNextPage()}
      // ...
    />
  );
}
```

## Zustand Store

The quiz store manages active session state locally:

```typescript
import { useQuizStore, selectSessionProgress } from '@/stores/quizStore';

function QuizInProgress() {
  // Actions
  const {
    initQuizSession,
    setSelectedAnswer,
    processAnswerResult,
    nextQuestion,
    flipCard,
    tickTimer,
  } = useQuizStore();

  // State
  const currentQuestion = useQuizStore(state => state.currentQuestion);
  const selectedAnswer = useQuizStore(state => state.selectedAnswer);
  const timerSeconds = useQuizStore(state => state.timerSeconds);
  const showingFeedback = useQuizStore(state => state.showingFeedback);

  // Selectors
  const progress = useQuizStore(selectSessionProgress);

  // Timer effect
  useEffect(() => {
    const interval = setInterval(tickTimer, 1000);
    return () => clearInterval(interval);
  }, []);
}
```

## Query Keys

Use query keys for manual cache operations:

```typescript
import { quizKeys } from '@/hooks/useQuiz';
import { useQueryClient } from '@tanstack/react-query';

const queryClient = useQueryClient();

// Invalidate all quiz data
queryClient.invalidateQueries({ queryKey: quizKeys.all });

// Invalidate just progress
queryClient.invalidateQueries({ queryKey: quizKeys.progress() });

// Get cached session
const session = queryClient.getQueryData(quizKeys.session('session123'));
```

## Type Reference

### Key Types

| Type | Description |
|------|-------------|
| `QuizConfig` | Configuration for starting a quiz |
| `FlashcardConfig` | Configuration for flashcard sessions |
| `QuizSession` | Active quiz session with questions |
| `FlashcardSession` | Active flashcard session with cards |
| `QuizQuestion` | Multiple choice question |
| `FlashcardItem` | Single flashcard (front/back) |
| `AnswerResult` | Result of submitting an answer |
| `QuizSessionResult` | Final results after completing quiz |
| `StudyProgress` | User's overall study statistics |
| `InstrumentProgress` | Progress for single instrument |
| `QuizLimits` | Premium gating limits |

### Question Types

```typescript
type QuestionType = 
  | 'image_to_name'      // Show image, pick correct name
  | 'name_to_use'        // Show name, pick primary use
  | 'image_to_category'  // Show image, pick category
  | 'name_to_image'      // Show name, pick correct image
  | 'flashcard';         // Flashcard mode
```

## Backend API Endpoints

This layer expects the following backend endpoints:

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/quiz/sessions` | Start quiz session |
| GET | `/quiz/sessions/:id` | Get session |
| POST | `/quiz/sessions/:id/questions/:qid/answer` | Submit answer |
| POST | `/quiz/sessions/:id/end` | End session |
| POST | `/quiz/flashcards/sessions` | Start flashcard session |
| POST | `/quiz/flashcards/sessions/:id/result` | Record flashcard result |
| GET | `/quiz/progress` | Get study progress |
| GET | `/quiz/progress/due-for-review` | Get due items |
| GET | `/quiz/history` | Get quiz history |
| GET | `/quiz/limits` | Get usage limits |

## Spaced Repetition (SM-2)

The system uses the SM-2 algorithm for spaced repetition:

- **Easiness Factor (EF)**: 1.3 to 2.5+ - how easy the item is
- **Interval**: Days until next review
- **Repetitions**: Successful consecutive reviews

When a user marks "got it" or "study more":
- "Got it" increases interval and maintains/increases EF
- "Study more" resets interval and decreases EF

## Next Steps

After implementing Stage 6A, proceed to:

1. **Stage 6B**: Quiz Home Screen (stats dashboard, quick actions)
2. **Stage 6C**: Flashcard Mode (swipeable cards, animations)
3. **Stage 6D**: Multiple Choice Quiz (question display, timer)
4. **Stage 6E**: Study Progress Tracking (bookmarks, due for review)

## Troubleshooting

### Common Issues

1. **"Cannot find module './client'"**
   - Ensure Stage 2B's API client is in place at `src/api/client.ts`

2. **React Query not updating**
   - Check that QueryClientProvider wraps your app
   - Verify query key structure matches

3. **Zustand state not persisting**
   - Ensure AsyncStorage is properly configured
   - Check that persist middleware is active

4. **Type errors with quiz types**
   - Run `npm run typecheck` to identify issues
   - Ensure all imports are from correct paths
