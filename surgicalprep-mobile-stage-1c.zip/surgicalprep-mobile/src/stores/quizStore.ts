import { create } from 'zustand';
import { QuizSession, QuizQuestion, QuizType, InstrumentCategory } from '@/types';
import { quizApi } from '@/api';

interface QuizState {
  // Current session
  currentSession: QuizSession | null;
  questions: QuizQuestion[];
  currentQuestionIndex: number;
  answers: Record<string, { answer: string; isCorrect: boolean }>;

  // UI State
  isLoading: boolean;
  error: string | null;

  // Actions
  startSession: (config: {
    quizType: QuizType;
    category?: InstrumentCategory;
    questionCount?: number;
  }) => Promise<void>;
  submitAnswer: (questionId: string, answer: string) => Promise<boolean>;
  nextQuestion: () => void;
  previousQuestion: () => void;
  endSession: () => Promise<QuizSession | null>;
  resetQuiz: () => void;

  // Computed
  isComplete: boolean;
  score: number;
  progress: number;
}

export const useQuizStore = create<QuizState>((set, get) => ({
  currentSession: null,
  questions: [],
  currentQuestionIndex: 0,
  answers: {},
  isLoading: false,
  error: null,
  isComplete: false,
  score: 0,
  progress: 0,

  startSession: async (config) => {
    set({ isLoading: true, error: null });
    try {
      const result = await quizApi.startSession({
        quiz_type: config.quizType,
        category: config.category,
        question_count: config.questionCount || 10,
      });

      set({
        currentSession: result.session,
        questions: result.questions,
        currentQuestionIndex: 0,
        answers: {},
        isLoading: false,
        isComplete: false,
      });
    } catch (error: any) {
      const message = error.response?.data?.detail || 'Failed to start quiz';
      set({ error: message, isLoading: false });
      throw error;
    }
  },

  submitAnswer: async (questionId: string, answer: string) => {
    const { currentSession } = get();
    if (!currentSession) return false;

    try {
      const result = await quizApi.submitAnswer(currentSession.id, {
        question_id: questionId,
        user_answer: answer,
        is_correct: false, // Server determines this
      });

      set((state) => ({
        answers: {
          ...state.answers,
          [questionId]: { answer, isCorrect: result.is_correct },
        },
      }));

      return result.is_correct;
    } catch (error) {
      console.error('Failed to submit answer:', error);
      return false;
    }
  },

  nextQuestion: () => {
    const { currentQuestionIndex, questions } = get();
    if (currentQuestionIndex < questions.length - 1) {
      set({ currentQuestionIndex: currentQuestionIndex + 1 });
    }
  },

  previousQuestion: () => {
    const { currentQuestionIndex } = get();
    if (currentQuestionIndex > 0) {
      set({ currentQuestionIndex: currentQuestionIndex - 1 });
    }
  },

  endSession: async () => {
    const { currentSession } = get();
    if (!currentSession) return null;

    set({ isLoading: true });
    try {
      const result = await quizApi.endSession(currentSession.id);
      set({ currentSession: result, isComplete: true, isLoading: false });
      return result;
    } catch (error) {
      set({ isLoading: false });
      console.error('Failed to end session:', error);
      return null;
    }
  },

  resetQuiz: () => {
    set({
      currentSession: null,
      questions: [],
      currentQuestionIndex: 0,
      answers: {},
      isComplete: false,
      error: null,
    });
  },
}));

// Selectors
export const selectCurrentQuestion = (state: QuizState) => state.questions[state.currentQuestionIndex];

export const selectProgress = (state: QuizState) => {
  if (state.questions.length === 0) return 0;
  return (Object.keys(state.answers).length / state.questions.length) * 100;
};

export const selectScore = (state: QuizState) => {
  const correctAnswers = Object.values(state.answers).filter((a) => a.isCorrect).length;
  if (state.questions.length === 0) return 0;
  return Math.round((correctAnswers / state.questions.length) * 100);
};
