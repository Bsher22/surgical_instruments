// src/api/storage.ts
// Supabase Storage API client for photo upload/delete operations

import { supabase } from './supabase';
import { PHOTO_CONFIG } from '../utils/constants';
import { PhotoUploadResult } from '../types/photo';

/**
 * Upload a photo to Supabase Storage
 * @param file - Blob or File to upload
 * @param path - Storage path (e.g., 'cards/user123/card456/photo.jpg')
 * @param onProgress - Optional progress callback (0-100)
 * @returns Upload result with public URL and path
 */
export async function uploadPhoto(
  file: Blob,
  path: string,
  onProgress?: (progress: number) => void
): Promise<PhotoUploadResult> {
  const bucket = PHOTO_CONFIG.storageBucket;
  
  try {
    // Note: Supabase JS client doesn't support upload progress natively
    // For progress tracking, we'd need to use XMLHttpRequest or a custom solution
    // For now, we'll simulate progress
    onProgress?.(10);
    
    const { data, error } = await supabase.storage
      .from(bucket)
      .upload(path, file, {
        cacheControl: '3600',
        upsert: false,
        contentType: file.type || 'image/jpeg',
      });
    
    if (error) {
      throw new Error(`Upload failed: ${error.message}`);
    }
    
    onProgress?.(90);
    
    // Get public URL
    const { data: urlData } = supabase.storage
      .from(bucket)
      .getPublicUrl(data.path);
    
    onProgress?.(100);
    
    return {
      url: urlData.publicUrl,
      path: data.path,
      size: file.size,
    };
  } catch (error) {
    console.error('Storage upload error:', error);
    throw error;
  }
}

/**
 * Upload a photo using FormData (alternative method with XMLHttpRequest for progress)
 * @param uri - Local URI of the file
 * @param path - Storage path
 * @param mimeType - MIME type of the file
 * @param onProgress - Progress callback (0-100)
 * @returns Upload result
 */
export async function uploadPhotoWithProgress(
  uri: string,
  path: string,
  mimeType: string = 'image/jpeg',
  onProgress?: (progress: number) => void
): Promise<PhotoUploadResult> {
  const bucket = PHOTO_CONFIG.storageBucket;
  
  // Get the Supabase URL and key
  const supabaseUrl = process.env.EXPO_PUBLIC_SUPABASE_URL;
  const supabaseAnonKey = process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY;
  
  if (!supabaseUrl || !supabaseAnonKey) {
    throw new Error('Supabase configuration missing');
  }
  
  const uploadUrl = `${supabaseUrl}/storage/v1/object/${bucket}/${path}`;
  
  // Fetch the file as blob
  const response = await fetch(uri);
  const blob = await response.blob();
  
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    
    // Track upload progress
    xhr.upload.addEventListener('progress', (event) => {
      if (event.lengthComputable) {
        const progress = Math.round((event.loaded / event.total) * 100);
        onProgress?.(progress);
      }
    });
    
    xhr.addEventListener('load', () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        // Get public URL
        const { data: urlData } = supabase.storage
          .from(bucket)
          .getPublicUrl(path);
        
        resolve({
          url: urlData.publicUrl,
          path: path,
          size: blob.size,
        });
      } else {
        reject(new Error(`Upload failed with status ${xhr.status}`));
      }
    });
    
    xhr.addEventListener('error', () => {
      reject(new Error('Network error during upload'));
    });
    
    xhr.addEventListener('abort', () => {
      reject(new Error('Upload aborted'));
    });
    
    xhr.open('POST', uploadUrl);
    xhr.setRequestHeader('Authorization', `Bearer ${supabaseAnonKey}`);
    xhr.setRequestHeader('Content-Type', mimeType);
    xhr.setRequestHeader('x-upsert', 'false');
    xhr.send(blob);
  });
}

/**
 * Delete a photo from Supabase Storage
 * @param path - Storage path of the photo to delete
 */
export async function deletePhoto(path: string): Promise<void> {
  const bucket = PHOTO_CONFIG.storageBucket;
  
  try {
    const { error } = await supabase.storage
      .from(bucket)
      .remove([path]);
    
    if (error) {
      throw new Error(`Delete failed: ${error.message}`);
    }
  } catch (error) {
    console.error('Storage delete error:', error);
    throw error;
  }
}

/**
 * Delete multiple photos from Supabase Storage
 * @param paths - Array of storage paths to delete
 */
export async function deletePhotos(paths: string[]): Promise<void> {
  if (paths.length === 0) return;
  
  const bucket = PHOTO_CONFIG.storageBucket;
  
  try {
    const { error } = await supabase.storage
      .from(bucket)
      .remove(paths);
    
    if (error) {
      throw new Error(`Bulk delete failed: ${error.message}`);
    }
  } catch (error) {
    console.error('Storage bulk delete error:', error);
    throw error;
  }
}

/**
 * Get the public URL for a stored photo
 * @param path - Storage path
 * @returns Public URL string
 */
export function getPhotoUrl(path: string): string {
  const bucket = PHOTO_CONFIG.storageBucket;
  
  const { data } = supabase.storage
    .from(bucket)
    .getPublicUrl(path);
  
  return data.publicUrl;
}

/**
 * Upload multiple photos with overall progress tracking
 * @param files - Array of files with paths
 * @param onProgress - Progress callback (completed count, total count)
 * @returns Array of upload results
 */
export async function uploadPhotos(
  files: Array<{ blob: Blob; path: string }>,
  onProgress?: (completed: number, total: number) => void
): Promise<PhotoUploadResult[]> {
  const results: PhotoUploadResult[] = [];
  let completed = 0;
  
  // Upload in batches for concurrent upload control
  const batchSize = PHOTO_CONFIG.concurrentUploads;
  
  for (let i = 0; i < files.length; i += batchSize) {
    const batch = files.slice(i, i + batchSize);
    
    const batchPromises = batch.map(async ({ blob, path }) => {
      const result = await uploadPhoto(blob, path);
      completed++;
      onProgress?.(completed, files.length);
      return result;
    });
    
    const batchResults = await Promise.all(batchPromises);
    results.push(...batchResults);
  }
  
  return results;
}

/**
 * Check if a photo exists in storage
 * @param path - Storage path to check
 * @returns true if photo exists
 */
export async function photoExists(path: string): Promise<boolean> {
  const bucket = PHOTO_CONFIG.storageBucket;
  
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .list(path.split('/').slice(0, -1).join('/'), {
        search: path.split('/').pop(),
      });
    
    if (error) return false;
    return data && data.length > 0;
  } catch {
    return false;
  }
}

/**
 * List all photos in a card's folder
 * @param userId - User ID
 * @param cardId - Card ID
 * @returns Array of photo paths
 */
export async function listCardPhotos(
  userId: string,
  cardId: string
): Promise<string[]> {
  const bucket = PHOTO_CONFIG.storageBucket;
  const folderPath = `cards/${userId}/${cardId}`;
  
  try {
    const { data, error } = await supabase.storage
      .from(bucket)
      .list(folderPath);
    
    if (error) {
      throw new Error(`List failed: ${error.message}`);
    }
    
    return (data || []).map(file => `${folderPath}/${file.name}`);
  } catch (error) {
    console.error('Storage list error:', error);
    return [];
  }
}
