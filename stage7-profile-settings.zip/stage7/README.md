# Stage 7: User Profile & Settings

## Overview

This stage implements comprehensive user account management and application settings for SurgicalPrep. It includes profile viewing/editing, subscription status display, usage statistics, settings management, and account actions.

## Files Included

```
stage7/
├── STAGE_7_OUTLINE.md              # Detailed implementation outline
├── README.md                       # This file
├── app/
│   └── (tabs)/
│       └── profile/
│           ├── _layout.tsx         # Profile stack navigation layout
│           ├── index.tsx           # Main profile screen
│           ├── settings.tsx        # Settings screen
│           ├── change-password.tsx # Change password screen
│           └── delete-account.tsx  # Delete account screen
└── src/
    ├── api/
    │   └── user.ts                 # User API functions
    ├── components/
    │   └── profile/
    │       ├── index.ts            # Barrel exports
    │       ├── ProfileHeader.tsx   # User avatar and info
    │       ├── SubscriptionCard.tsx # Premium status card
    │       ├── UsageStatsCard.tsx  # Stats dashboard
    │       ├── SettingsSection.tsx # Settings section wrapper
    │       ├── SettingsRow.tsx     # Settings row component
    │       ├── EditProfileModal.tsx # Profile edit modal
    │       └── CategoryPickerModal.tsx # Category selection modal
    ├── contexts/
    │   ├── index.ts                # Barrel exports
    │   └── ThemeContext.tsx        # Dark mode theme context
    ├── hooks/
    │   ├── useUser.ts              # React Query hooks for user data
    │   └── useSettingsSync.ts      # Settings sync hook
    ├── stores/
    │   └── settingsStore.ts        # Zustand settings store
    └── types/
        └── user.ts                 # User-related TypeScript types
```

## Installation

### 1. Install Required Dependencies

```bash
# Core dependencies (should already be installed)
npx expo install @react-native-async-storage/async-storage
npx expo install @react-native-picker/picker
npx expo install @react-native-community/slider
npx expo install expo-application
npx expo install expo-linear-gradient
npx expo install expo-haptics

# If not already installed from previous stages
npx expo install zustand
npx expo install @tanstack/react-query
```

### 2. Copy Files

Copy the files from this package to your mobile project:

```bash
# From your mobile project root
cp -r stage7/src/* src/
cp -r stage7/app/* app/
```

### 3. Update Tab Navigator

Add the Profile tab to your main tab layout (`app/(tabs)/_layout.tsx`):

```tsx
import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: '#6366F1',
        tabBarInactiveTintColor: '#9CA3AF',
        headerShown: false,
      }}
    >
      {/* ... other tabs ... */}
      
      <Tabs.Screen
        name="profile"
        options={{
          title: 'Profile',
          tabBarIcon: ({ color, size }) => (
            <Ionicons name="person-outline" size={size} color={color} />
          ),
        }}
      />
    </Tabs>
  );
}
```

### 4. Add Theme Provider (Optional but Recommended)

Wrap your app with the ThemeProvider in `app/_layout.tsx`:

```tsx
import { ThemeProvider } from '../src/contexts';

export default function RootLayout() {
  return (
    <ThemeProvider>
      {/* ... your existing providers and layout ... */}
    </ThemeProvider>
  );
}
```

### 5. Add Settings Sync (Optional)

Add the settings sync hook to your main app component:

```tsx
import { useSettingsSync } from '../src/hooks/useSettingsSync';

function AppContent() {
  // This will sync settings to backend automatically
  useSettingsSync();
  
  return (
    // ... your app content
  );
}
```

## Backend API Endpoints Required

This stage requires the following backend endpoints:

### Profile Endpoints
- `GET /api/users/me` - Get current user profile
- `PUT /api/users/me` - Update user profile
- `POST /api/users/me/avatar` - Upload avatar image
- `DELETE /api/users/me/avatar` - Delete avatar

### Statistics Endpoint
- `GET /api/users/me/stats` - Get user statistics

### Settings Endpoints
- `GET /api/users/me/settings` - Get user settings
- `PUT /api/users/me/settings` - Update user settings
- `POST /api/users/me/settings/reset` - Reset settings to defaults

### Account Endpoints
- `POST /api/auth/change-password` - Change password
- `DELETE /api/users/me` - Delete account

### Subscription Endpoint
- `GET /api/users/me/subscription` - Get subscription info

## Backend Schema Additions

Add these to your FastAPI backend:

### Pydantic Schemas

```python
# schemas/user.py

class UserSettings(BaseModel):
    quiz_question_count: int = 20
    quiz_timer_enabled: bool = False
    quiz_timer_seconds: int = 30
    preferred_categories: List[str] = []
    dark_mode: str = "system"  # light, dark, system
    text_size: str = "medium"  # small, medium, large
    haptic_feedback_enabled: bool = True
    study_reminders_enabled: bool = False
    reminder_time: Optional[str] = None

class UserStats(BaseModel):
    cards_created: int
    cards_limit: Optional[int]
    instruments_studied: int
    instruments_total: int
    quizzes_completed: int
    flashcard_sessions_completed: int
    average_quiz_score: Optional[float]
    current_streak: int
    longest_streak: int
    total_study_time_minutes: int
    last_study_date: Optional[datetime]
    instruments_due_for_review: int

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str

class DeleteAccountRequest(BaseModel):
    password: str
    confirmation: str  # Must be "DELETE"
```

### Database Model Addition

```python
# Add to users table or create user_settings table

class UserSettings(Base):
    __tablename__ = "user_settings"
    
    id = Column(UUID, primary_key=True, default=uuid4)
    user_id = Column(UUID, ForeignKey("users.id"), unique=True)
    quiz_question_count = Column(Integer, default=20)
    quiz_timer_enabled = Column(Boolean, default=False)
    quiz_timer_seconds = Column(Integer, default=30)
    preferred_categories = Column(ARRAY(String), default=[])
    dark_mode = Column(String, default="system")
    text_size = Column(String, default="medium")
    haptic_feedback_enabled = Column(Boolean, default=True)
    study_reminders_enabled = Column(Boolean, default=False)
    reminder_time = Column(String, nullable=True)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
```

## Features

### Profile Screen
- User avatar with initials fallback
- Name, email, role badge, institution display
- Edit profile modal
- Subscription status card with upgrade CTA
- Usage statistics with animated counters
- Quick action buttons

### Settings Screen
- Quiz preferences (question count, timer, categories)
- Display settings (dark mode, text size, haptics)
- About section (version, privacy, terms, support)
- Account actions (change password, logout, delete)

### Change Password Screen
- Current password verification
- Password strength indicator
- Real-time validation
- Match confirmation

### Delete Account Screen
- Warning banner with consequences list
- Password confirmation
- Type "DELETE" confirmation
- Alternative support option

## Customization

### Theme Colors

Edit `src/contexts/ThemeContext.tsx` to customize the color palette:

```tsx
const lightColors: ThemeColors = {
  primary: '#6366F1', // Change this to your brand color
  // ... other colors
};
```

### Quiz Categories

Edit `src/components/profile/CategoryPickerModal.tsx` to customize categories:

```tsx
export const QUIZ_CATEGORIES = [
  {
    id: 'your-category',
    label: 'Your Category',
    icon: 'icon-name',
    color: '#HexColor',
    description: 'Description here',
  },
  // ... more categories
];
```

## Testing Checklist

- [ ] Profile displays correctly with user data
- [ ] Edit profile modal saves changes
- [ ] Stats load and display correctly
- [ ] All settings toggles persist
- [ ] Slider adjusts and saves
- [ ] Category selection works
- [ ] Dark mode applies to app
- [ ] Change password validates correctly
- [ ] Change password succeeds/fails appropriately
- [ ] Logout clears data and redirects
- [ ] Delete account requires all confirmations
- [ ] Delete account removes user data

## Next Stage

Stage 8: Subscription & Payments
- Stripe integration
- Paywall screen
- Premium feature gating
- Subscription management

## Notes

- The subscription upgrade/manage buttons currently show placeholder alerts
- These will be connected to Stripe in Stage 8
- The theme context is ready for full dark mode support
- Settings sync happens automatically with debouncing
- All forms have haptic feedback when enabled
