// Types for Preference Cards - matches backend Pydantic schemas

// ============================================================================
// Enums
// ============================================================================

export type CardItemCategory = 
  | 'instrument'
  | 'supply'
  | 'suture'
  | 'implant'
  | 'equipment'
  | 'other';

export type Specialty =
  | 'general'
  | 'orthopedic'
  | 'cardiovascular'
  | 'neurosurgery'
  | 'obgyn'
  | 'urology'
  | 'ent'
  | 'plastic'
  | 'ophthalmic'
  | 'pediatric'
  | 'trauma'
  | 'other';

// ============================================================================
// Card Item Types
// ============================================================================

export interface CardItemBase {
  name: string;
  quantity: number;
  size?: string | null;
  notes?: string | null;
  category: CardItemCategory;
  instrument_id?: string | null; // Links to instruments table if from database
  sort_order: number;
}

export interface CardItem extends CardItemBase {
  id: string;
  card_id: string;
  created_at: string;
  updated_at: string;
}

export interface CardItemCreate extends Omit<CardItemBase, 'sort_order'> {
  sort_order?: number;
}

export interface CardItemUpdate extends Partial<CardItemBase> {
  id?: string; // Include for existing items during card update
}

// ============================================================================
// Preference Card Types
// ============================================================================

export interface PreferenceCardBase {
  title: string;
  surgeon_name?: string | null;
  procedure_name?: string | null;
  specialty?: Specialty | null;
  general_notes?: string | null;
  setup_notes?: string | null;
  is_template?: boolean;
  is_public?: boolean;
}

export interface PreferenceCard extends PreferenceCardBase {
  id: string;
  user_id: string;
  created_at: string;
  updated_at: string;
  items?: CardItem[];
  photos?: CardPhoto[];
  item_count?: number; // Computed field for list view
}

export interface PreferenceCardCreate extends PreferenceCardBase {
  items?: CardItemCreate[];
}

export interface PreferenceCardUpdate extends Partial<PreferenceCardBase> {
  items?: CardItemUpdate[];
}

// ============================================================================
// Card Photo Types
// ============================================================================

export interface CardPhoto {
  id: string;
  card_id: string;
  image_url: string;
  caption?: string | null;
  sort_order: number;
  created_at: string;
}

export interface CardPhotoCreate {
  image_url: string;
  caption?: string | null;
  sort_order?: number;
}

// ============================================================================
// API Request/Response Types
// ============================================================================

export interface GetCardsParams {
  search?: string;
  specialty?: Specialty;
  surgeon_name?: string;
  is_template?: boolean;
  page?: number;
  limit?: number;
  sort_by?: 'updated_at' | 'created_at' | 'title';
  sort_order?: 'asc' | 'desc';
}

export interface PaginatedCardsResponse {
  items: PreferenceCard[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
  has_next: boolean;
  has_prev: boolean;
}

export interface CardWithDetails extends PreferenceCard {
  items: CardItem[];
  photos: CardPhoto[];
}

// ============================================================================
// Card Item Grouped by Category (for display)
// ============================================================================

export interface GroupedCardItems {
  instruments: CardItem[];
  supplies: CardItem[];
  sutures: CardItem[];
  implants: CardItem[];
  equipment: CardItem[];
  other: CardItem[];
}

// Helper function to group items by category
export function groupItemsByCategory(items: CardItem[]): GroupedCardItems {
  return {
    instruments: items.filter(i => i.category === 'instrument'),
    supplies: items.filter(i => i.category === 'supply'),
    sutures: items.filter(i => i.category === 'suture'),
    implants: items.filter(i => i.category === 'implant'),
    equipment: items.filter(i => i.category === 'equipment'),
    other: items.filter(i => i.category === 'other'),
  };
}

// ============================================================================
// Specialty Display Names
// ============================================================================

export const SPECIALTY_LABELS: Record<Specialty, string> = {
  general: 'General Surgery',
  orthopedic: 'Orthopedic',
  cardiovascular: 'Cardiovascular',
  neurosurgery: 'Neurosurgery',
  obgyn: 'OB/GYN',
  urology: 'Urology',
  ent: 'ENT',
  plastic: 'Plastic Surgery',
  ophthalmic: 'Ophthalmic',
  pediatric: 'Pediatric',
  trauma: 'Trauma',
  other: 'Other',
};

export const CATEGORY_LABELS: Record<CardItemCategory, string> = {
  instrument: 'Instruments',
  supply: 'Supplies',
  suture: 'Sutures',
  implant: 'Implants',
  equipment: 'Equipment',
  other: 'Other',
};
