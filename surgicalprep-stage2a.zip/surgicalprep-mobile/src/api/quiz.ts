import { apiClient } from './client';
import { QuizSession, QuizQuestion, StudyProgress } from '../types';

interface StartQuizParams {
  question_count?: number;
  categories?: string[];
  question_types?: string[];
}

interface AnswerResult {
  is_correct: boolean;
  correct_answer: string;
  explanation?: string;
}

export const quizApi = {
  startSession: async (params: StartQuizParams = {}): Promise<QuizSession> => {
    return apiClient.post('/quiz/start', params);
  },

  getQuestion: async (sessionId: string, questionIndex: number): Promise<QuizQuestion> => {
    return apiClient.get(`/quiz/${sessionId}/question/${questionIndex}`);
  },

  submitAnswer: async (
    sessionId: string,
    questionId: string,
    answer: string
  ): Promise<AnswerResult> => {
    return apiClient.post(`/quiz/${sessionId}/answer`, {
      question_id: questionId,
      answer,
    });
  },

  endSession: async (sessionId: string): Promise<QuizSession> => {
    return apiClient.post(`/quiz/${sessionId}/end`);
  },

  getProgress: async (): Promise<StudyProgress> => {
    return apiClient.get('/study/progress');
  },

  getDueForReview: async (): Promise<string[]> => {
    return apiClient.get('/study/due');
  },

  recordFlashcardResult: async (
    instrumentId: string,
    result: 'correct' | 'incorrect'
  ): Promise<void> => {
    return apiClient.post('/study/flashcard', {
      instrument_id: instrumentId,
      result,
    });
  },
};
