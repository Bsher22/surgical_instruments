/**
 * Quiz & Study System Types
 * SurgicalPrep - Stage 6A
 */

// =============================================================================
// Enums & Constants
// =============================================================================

export type QuizType = 'flashcard' | 'multiple_choice' | 'mixed';

export type QuestionType = 
  | 'image_to_name'      // Show image, pick correct name
  | 'name_to_use'        // Show name, pick primary use
  | 'image_to_category'  // Show image, pick category
  | 'name_to_image'      // Show name, pick correct image
  | 'flashcard';         // Flashcard mode (no options)

export type Difficulty = 'easy' | 'medium' | 'hard' | 'mixed';

export type FlashcardResult = 'got_it' | 'study_more';

export type SessionStatus = 'in_progress' | 'completed' | 'abandoned';

// =============================================================================
// Quiz Configuration
// =============================================================================

export interface QuizConfig {
  quiz_type: QuizType;
  question_count: number;
  categories?: string[];           // Filter by instrument categories
  difficulty?: Difficulty;
  time_limit_seconds?: number;     // Per question timer (optional)
  include_due_for_review?: boolean; // Prioritize spaced repetition items
  instrument_ids?: string[];       // Specific instruments to quiz on
}

export interface FlashcardConfig {
  card_count: number;
  categories?: string[];
  include_due_for_review?: boolean;
  instrument_ids?: string[];
}

// =============================================================================
// Questions & Answers
// =============================================================================

export interface QuizQuestion {
  id: string;
  question_type: QuestionType;
  instrument_id: string;
  prompt: QuestionPrompt;
  options: QuizOption[];           // 4 options for multiple choice
  correct_option_id: string;
  time_limit_seconds?: number;
  explanation?: string;            // Shown after answering
}

export interface QuestionPrompt {
  type: 'image' | 'text';
  content: string;                 // Image URL or text content
  alt_text?: string;               // For accessibility
}

export interface QuizOption {
  id: string;
  content: string;                 // Option text or image URL
  type: 'text' | 'image';
}

export interface FlashcardItem {
  id: string;
  instrument_id: string;
  front: FlashcardFront;
  back: FlashcardBack;
  due_for_review: boolean;
  last_reviewed_at?: string;
  difficulty_rating?: number;      // SM-2 easiness factor
}

export interface FlashcardFront {
  image_url: string;
  alt_text?: string;
}

export interface FlashcardBack {
  name: string;
  aliases?: string[];
  category: string;
  primary_uses: string[];
  description?: string;
}

// =============================================================================
// Answer Submission
// =============================================================================

export interface AnswerSubmission {
  session_id: string;
  question_id: string;
  selected_option_id: string;
  time_taken_seconds?: number;
}

export interface AnswerResult {
  question_id: string;
  is_correct: boolean;
  correct_option_id: string;
  selected_option_id: string;
  explanation?: string;
  instrument: AnswerInstrumentInfo;
  points_earned: number;
  streak_bonus?: number;
}

export interface AnswerInstrumentInfo {
  id: string;
  name: string;
  category: string;
  image_url?: string;
}

export interface FlashcardResultSubmission {
  session_id: string;
  flashcard_id: string;
  instrument_id: string;
  result: FlashcardResult;
  time_spent_seconds?: number;
}

export interface FlashcardResultResponse {
  flashcard_id: string;
  instrument_id: string;
  result: FlashcardResult;
  next_review_date: string;        // ISO date string
  updated_difficulty: number;      // SM-2 easiness factor
}

// =============================================================================
// Quiz Sessions
// =============================================================================

export interface QuizSession {
  id: string;
  user_id: string;
  quiz_type: QuizType;
  status: SessionStatus;
  config: QuizConfig;
  questions: QuizQuestion[];
  current_question_index: number;
  answers: SessionAnswer[];
  score: number;
  total_questions: number;
  started_at: string;
  completed_at?: string;
  time_elapsed_seconds: number;
}

export interface SessionAnswer {
  question_id: string;
  selected_option_id: string;
  is_correct: boolean;
  time_taken_seconds?: number;
  answered_at: string;
}

export interface FlashcardSession {
  id: string;
  user_id: string;
  status: SessionStatus;
  config: FlashcardConfig;
  cards: FlashcardItem[];
  current_card_index: number;
  results: FlashcardSessionResult[];
  cards_completed: number;
  cards_got_it: number;
  cards_study_more: number;
  started_at: string;
  completed_at?: string;
}

export interface FlashcardSessionResult {
  flashcard_id: string;
  instrument_id: string;
  result: FlashcardResult;
  time_spent_seconds?: number;
  recorded_at: string;
}

// =============================================================================
// Session Results
// =============================================================================

export interface QuizSessionResult {
  session_id: string;
  quiz_type: QuizType;
  score: number;
  total_questions: number;
  percentage: number;
  time_elapsed_seconds: number;
  correct_answers: number;
  incorrect_answers: number;
  average_time_per_question: number;
  longest_streak: number;
  questions_breakdown: QuestionBreakdown[];
  category_performance: CategoryPerformance[];
  instruments_to_review: string[];  // Instrument IDs that were missed
  xp_earned: number;
  achievements_unlocked?: Achievement[];
}

export interface QuestionBreakdown {
  question_id: string;
  instrument_id: string;
  instrument_name: string;
  question_type: QuestionType;
  is_correct: boolean;
  time_taken_seconds?: number;
  selected_answer: string;
  correct_answer: string;
}

export interface CategoryPerformance {
  category: string;
  correct: number;
  total: number;
  percentage: number;
}

export interface FlashcardSessionResult {
  session_id: string;
  cards_reviewed: number;
  cards_got_it: number;
  cards_study_more: number;
  got_it_percentage: number;
  time_elapsed_seconds: number;
  average_time_per_card: number;
  cards_breakdown: FlashcardBreakdown[];
  next_review_summary: ReviewSummary;
  xp_earned: number;
}

export interface FlashcardBreakdown {
  instrument_id: string;
  instrument_name: string;
  result: FlashcardResult;
  time_spent_seconds?: number;
  next_review_date: string;
}

export interface ReviewSummary {
  due_today: number;
  due_tomorrow: number;
  due_this_week: number;
}

// =============================================================================
// Study Progress & Statistics
// =============================================================================

export interface StudyProgress {
  user_id: string;
  total_instruments_studied: number;
  total_instruments_available: number;
  instruments_mastered: number;      // High confidence level
  instruments_learning: number;      // Medium confidence
  instruments_new: number;           // Never studied
  
  // Quiz stats
  total_quizzes_completed: number;
  total_questions_answered: number;
  overall_accuracy: number;          // Percentage
  average_quiz_score: number;
  best_quiz_score: number;
  
  // Flashcard stats
  total_flashcard_sessions: number;
  total_cards_reviewed: number;
  flashcard_got_it_rate: number;     // Percentage
  
  // Streak & engagement
  current_streak: number;            // Days
  longest_streak: number;
  last_study_date?: string;
  total_study_time_minutes: number;
  
  // Spaced repetition
  due_for_review_count: number;
  overdue_count: number;
  
  // XP & achievements
  total_xp: number;
  level: number;
  xp_to_next_level: number;
  achievements_count: number;
  
  // Category breakdown
  category_progress: CategoryProgress[];
}

export interface CategoryProgress {
  category: string;
  instruments_total: number;
  instruments_studied: number;
  instruments_mastered: number;
  accuracy: number;
  last_studied_at?: string;
}

export interface InstrumentProgress {
  instrument_id: string;
  instrument_name: string;
  category: string;
  image_url?: string;
  
  // Study metrics
  times_studied: number;
  times_correct: number;
  times_incorrect: number;
  accuracy: number;
  
  // Spaced repetition (SM-2)
  easiness_factor: number;           // 1.3 to 2.5+
  interval_days: number;             // Days until next review
  repetitions: number;               // Successful consecutive reviews
  next_review_date?: string;
  last_reviewed_at?: string;
  
  // Confidence level
  confidence_level: 'new' | 'learning' | 'reviewing' | 'mastered';
  
  // Flags
  is_bookmarked: boolean;
  is_due_for_review: boolean;
  is_overdue: boolean;
}

// =============================================================================
// Due for Review
// =============================================================================

export interface DueForReviewParams {
  limit?: number;
  offset?: number;
  categories?: string[];
  include_overdue?: boolean;
  sort_by?: 'due_date' | 'difficulty' | 'last_reviewed';
}

export interface DueForReviewResponse {
  instruments: InstrumentProgress[];
  total_due: number;
  total_overdue: number;
  has_more: boolean;
  next_offset?: number;
}

// =============================================================================
// Quiz History
// =============================================================================

export interface QuizHistoryParams {
  limit?: number;
  offset?: number;
  quiz_type?: QuizType;
  date_from?: string;
  date_to?: string;
}

export interface QuizHistoryItem {
  session_id: string;
  quiz_type: QuizType;
  score: number;
  total_questions: number;
  percentage: number;
  time_elapsed_seconds: number;
  completed_at: string;
  categories: string[];
}

export interface QuizHistoryResponse {
  sessions: QuizHistoryItem[];
  total_count: number;
  has_more: boolean;
  next_offset?: number;
}

// =============================================================================
// Achievements & Gamification
// =============================================================================

export interface Achievement {
  id: string;
  name: string;
  description: string;
  icon_url: string;
  category: 'study' | 'quiz' | 'streak' | 'mastery' | 'special';
  xp_reward: number;
  unlocked_at?: string;
  progress?: number;                 // 0-100 for progressive achievements
  requirement?: number;              // Target value for progressive
}

// =============================================================================
// API Request/Response Types
// =============================================================================

export interface StartQuizRequest {
  config: QuizConfig;
}

export interface StartQuizResponse {
  session: QuizSession;
}

export interface StartFlashcardRequest {
  config: FlashcardConfig;
}

export interface StartFlashcardResponse {
  session: FlashcardSession;
}

export interface EndSessionRequest {
  session_id: string;
  abandoned?: boolean;
}

export interface EndQuizResponse {
  result: QuizSessionResult;
}

export interface EndFlashcardResponse {
  result: FlashcardSessionResult;
}

// =============================================================================
// Premium Gating
// =============================================================================

export interface QuizLimits {
  daily_quizzes_remaining: number;
  daily_quiz_limit: number;
  is_premium: boolean;
  reset_at: string;                  // When daily limit resets (ISO)
}

// =============================================================================
// Error Types
// =============================================================================

export interface QuizError {
  code: string;
  message: string;
  details?: Record<string, unknown>;
}

export type QuizErrorCode = 
  | 'SESSION_NOT_FOUND'
  | 'SESSION_ALREADY_COMPLETED'
  | 'QUESTION_NOT_FOUND'
  | 'INVALID_ANSWER'
  | 'DAILY_LIMIT_REACHED'
  | 'PREMIUM_REQUIRED'
  | 'INSUFFICIENT_INSTRUMENTS';
