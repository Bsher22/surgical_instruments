// ============================================================================
// Stage 6C: Haptic Feedback Utility
// ============================================================================

import * as Haptics from 'expo-haptics';
import { Platform } from 'react-native';

export type HapticFeedbackType =
  | 'light'
  | 'medium'
  | 'heavy'
  | 'success'
  | 'warning'
  | 'error'
  | 'selection';

/**
 * Trigger haptic feedback based on type
 * Gracefully handles platforms without haptic support
 */
export const triggerHaptic = async (type: HapticFeedbackType = 'light'): Promise<void> => {
  // Skip haptics on web
  if (Platform.OS === 'web') {
    return;
  }
  
  try {
    switch (type) {
      case 'light':
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
        break;
        
      case 'medium':
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
        break;
        
      case 'heavy':
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Heavy);
        break;
        
      case 'success':
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
        break;
        
      case 'warning':
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Warning);
        break;
        
      case 'error':
        await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
        break;
        
      case 'selection':
        await Haptics.selectionAsync();
        break;
        
      default:
        await Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
  } catch (error) {
    // Silently fail if haptics aren't available
    console.debug('Haptic feedback not available:', error);
  }
};

/**
 * Create a haptic-enhanced press handler
 * Wraps an onPress function with haptic feedback
 */
export const withHaptic = <T extends (...args: any[]) => any>(
  onPress: T,
  type: HapticFeedbackType = 'light'
): ((...args: Parameters<T>) => Promise<ReturnType<T>>) => {
  return async (...args: Parameters<T>) => {
    await triggerHaptic(type);
    return onPress(...args);
  };
};

/**
 * Haptic patterns for specific actions
 */
export const hapticPatterns = {
  // Swipe right - got it! (positive feedback)
  gotIt: () => triggerHaptic('success'),
  
  // Swipe left - study more (gentle reminder)
  studyMore: () => triggerHaptic('warning'),
  
  // Card flip (subtle interaction)
  flip: () => triggerHaptic('light'),
  
  // Session complete (celebration)
  sessionComplete: async () => {
    await triggerHaptic('success');
    // Small delay then another pulse for emphasis
    setTimeout(() => triggerHaptic('light'), 150);
  },
  
  // Button press (standard interaction)
  buttonPress: () => triggerHaptic('light'),
  
  // Error/invalid action
  error: () => triggerHaptic('error'),
  
  // Selection change
  selection: () => triggerHaptic('selection'),
};

export default {
  triggerHaptic,
  withHaptic,
  hapticPatterns,
};
