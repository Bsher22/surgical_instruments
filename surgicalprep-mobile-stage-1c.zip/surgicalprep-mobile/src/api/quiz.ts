import apiClient from './client';
import { ENDPOINTS } from '@/utils/constants';
import {
  QuizSession,
  QuizQuestion,
  QuizAnswer,
  StartQuizRequest,
  QuizSessionResult,
  StudyStats,
  UserInstrumentProgress,
} from '@/types';

export const quizApi = {
  async startSession(config: StartQuizRequest): Promise<QuizSessionResult> {
    const response = await apiClient.post<QuizSessionResult>(ENDPOINTS.quizSessions, config);
    return response.data;
  },

  async submitAnswer(
    sessionId: string,
    answer: QuizAnswer
  ): Promise<{ is_correct: boolean; explanation?: string }> {
    const response = await apiClient.post<{ is_correct: boolean; explanation?: string }>(
      `${ENDPOINTS.quizSessions}/${sessionId}/answer`,
      answer
    );
    return response.data;
  },

  async endSession(sessionId: string): Promise<QuizSession> {
    const response = await apiClient.post<QuizSession>(
      `${ENDPOINTS.quizSessions}/${sessionId}/end`
    );
    return response.data;
  },

  async getSessionHistory(limit?: number): Promise<QuizSession[]> {
    const response = await apiClient.get<QuizSession[]>(ENDPOINTS.quizSessions, {
      params: { limit: limit || 10 },
    });
    return response.data;
  },

  async getStudyStats(): Promise<StudyStats> {
    const response = await apiClient.get<StudyStats>(ENDPOINTS.studyProgress);
    return response.data;
  },

  async getDueForReview(): Promise<UserInstrumentProgress[]> {
    const response = await apiClient.get<UserInstrumentProgress[]>(
      `${ENDPOINTS.studyProgress}/due`
    );
    return response.data;
  },

  async toggleBookmark(instrumentId: string): Promise<UserInstrumentProgress> {
    const response = await apiClient.post<UserInstrumentProgress>(
      `${ENDPOINTS.studyProgress}/${instrumentId}/bookmark`
    );
    return response.data;
  },

  async getBookmarks(): Promise<UserInstrumentProgress[]> {
    const response = await apiClient.get<UserInstrumentProgress[]>(
      `${ENDPOINTS.studyProgress}/bookmarks`
    );
    return response.data;
  },
};
