import { apiClient } from './client';
import { User, AuthTokens, SignupData } from '../types';

interface LoginResponse {
  access_token: string;
  token_type: string;
  user: User;
}

interface SignupResponse {
  id: string;
  email: string;
  name: string;
}

export const authApi = {
  login: async (email: string, password: string): Promise<LoginResponse> => {
    // FastAPI OAuth2 expects form data
    const formData = new URLSearchParams();
    formData.append('username', email);
    formData.append('password', password);

    const response = await fetch(`${process.env.EXPO_PUBLIC_API_URL}/auth/login`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData.toString(),
    });

    if (!response.ok) {
      const error = await response.json().catch(() => ({}));
      throw new Error(error.detail || 'Login failed');
    }

    return response.json();
  },

  signup: async (data: SignupData): Promise<SignupResponse> => {
    return apiClient.post('/auth/register', data, { skipAuth: true });
  },

  getMe: async (): Promise<User> => {
    return apiClient.get('/auth/me');
  },

  refreshToken: async (refreshToken: string): Promise<AuthTokens> => {
    return apiClient.post('/auth/refresh', { refresh_token: refreshToken }, { skipAuth: true });
  },

  changePassword: async (currentPassword: string, newPassword: string): Promise<void> => {
    return apiClient.post('/auth/change-password', {
      current_password: currentPassword,
      new_password: newPassword,
    });
  },

  deleteAccount: async (): Promise<void> => {
    return apiClient.delete('/auth/me');
  },
};
