import { create } from 'zustand';
import { QuizSession, QuizQuestion } from '../types';
import { quizApi } from '../api/quiz';

interface QuizState {
  currentSession: QuizSession | null;
  currentQuestion: QuizQuestion | null;
  questionIndex: number;
  answers: Record<string, string>;
  isLoading: boolean;
  error: string | null;

  // Actions
  startSession: (params?: { categories?: string[]; questionCount?: number }) => Promise<void>;
  submitAnswer: (answer: string) => Promise<boolean>;
  nextQuestion: () => Promise<void>;
  endSession: () => Promise<QuizSession | null>;
  resetQuiz: () => void;
}

export const useQuizStore = create<QuizState>((set, get) => ({
  currentSession: null,
  currentQuestion: null,
  questionIndex: 0,
  answers: {},
  isLoading: false,
  error: null,

  startSession: async (params = {}) => {
    set({ isLoading: true, error: null });
    try {
      const session = await quizApi.startSession({
        question_count: params.questionCount,
        categories: params.categories,
      });
      
      set({
        currentSession: session,
        questionIndex: 0,
        answers: {},
        isLoading: false,
      });
      
      // Load first question
      await get().nextQuestion();
    } catch (error: any) {
      set({
        error: error.message || 'Failed to start quiz',
        isLoading: false,
      });
    }
  },

  submitAnswer: async (answer: string) => {
    const { currentSession, currentQuestion } = get();
    if (!currentSession || !currentQuestion) return false;

    set({ isLoading: true });
    try {
      const result = await quizApi.submitAnswer(
        currentSession.id,
        currentQuestion.id,
        answer
      );

      set((state) => ({
        answers: {
          ...state.answers,
          [currentQuestion.id]: answer,
        },
        isLoading: false,
      }));

      return result.is_correct;
    } catch (error: any) {
      set({
        error: error.message || 'Failed to submit answer',
        isLoading: false,
      });
      return false;
    }
  },

  nextQuestion: async () => {
    const { currentSession, questionIndex } = get();
    if (!currentSession) return;

    set({ isLoading: true });
    try {
      const question = await quizApi.getQuestion(currentSession.id, questionIndex);
      
      set({
        currentQuestion: question,
        questionIndex: questionIndex + 1,
        isLoading: false,
      });
    } catch (error: any) {
      set({
        error: error.message || 'Failed to load question',
        isLoading: false,
      });
    }
  },

  endSession: async () => {
    const { currentSession } = get();
    if (!currentSession) return null;

    set({ isLoading: true });
    try {
      const result = await quizApi.endSession(currentSession.id);
      set({ isLoading: false });
      return result;
    } catch (error: any) {
      set({
        error: error.message || 'Failed to end session',
        isLoading: false,
      });
      return null;
    }
  },

  resetQuiz: () => {
    set({
      currentSession: null,
      currentQuestion: null,
      questionIndex: 0,
      answers: {},
      error: null,
    });
  },
}));
