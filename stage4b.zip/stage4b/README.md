# Stage 4B: Cards List Screen

This stage implements the Preference Cards list view for browsing, searching, and managing preference cards.

## What's Included

### Screen
- `app/(tabs)/cards/index.tsx` - Main cards list screen with FlatList, search, filtering, and pull-to-refresh

### Components (`src/components/cards/`)
- `PreferenceCardItem.tsx` - Card preview with swipe actions (edit/delete)
- `PreferenceCardItemSkeleton` - Loading placeholder
- `CardsEmptyState.tsx` - Empty state with "Create First Card" CTA
- `CardsHeader.tsx` - Search bar with debounced input and filter button
- `SpecialtyFilter.tsx` - Modal for filtering by surgical specialty
- `CardLimitIndicator.tsx` - Shows free tier usage (e.g., "2/5 cards")

### Types (`src/types/`)
- `cards.ts` - TypeScript types for PreferenceCard, CardItem, Specialty, etc.

### API (`src/api/`)
- `cards.ts` - API client functions for cards CRUD operations
- `client.ts` - Base axios client with auth interceptors (reference from Stage 2B)

## Features Implemented

✅ Searchable card list (by surgeon name or procedure)  
✅ Filter by surgical specialty  
✅ Pull-to-refresh  
✅ Loading skeletons  
✅ Empty state with helpful tips  
✅ Swipe actions (edit, delete)  
✅ Free tier limit indicator with upgrade CTA  
✅ Performance optimizations (FlatList tuning)  
✅ Navigation to card detail  

## Dependencies Required

```bash
npx expo install @tanstack/react-query
npx expo install react-native-gesture-handler
npx expo install react-native-reanimated
npx expo install expo-secure-store
```

Make sure `GestureHandlerRootView` wraps your app in `_layout.tsx`.

## Usage

1. Copy files into your existing project structure
2. Ensure Stage 4A (Cards API Layer) is complete
3. Set up React Query provider in your app
4. Navigation should auto-work with Expo Router file-based routing

## File Placement

```
mobile/
├── app/
│   └── (tabs)/
│       └── cards/
│           └── index.tsx        ← Cards list screen
└── src/
    ├── api/
    │   ├── client.ts            ← Base API client
    │   └── cards.ts             ← Cards API functions
    ├── components/
    │   └── cards/
    │       ├── index.ts         ← Barrel export
    │       ├── PreferenceCardItem.tsx
    │       ├── CardsEmptyState.tsx
    │       ├── CardsHeader.tsx
    │       ├── SpecialtyFilter.tsx
    │       └── CardLimitIndicator.tsx
    └── types/
        └── cards.ts             ← TypeScript types
```

## Next Steps

After Stage 4B, proceed to:
- **Stage 4C**: Card Detail/View Screen
- **Stage 5**: Card Create/Edit functionality
