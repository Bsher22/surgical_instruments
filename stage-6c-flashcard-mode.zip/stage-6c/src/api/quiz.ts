// ============================================================================
// Stage 6C: Quiz API Client - Flashcard Endpoints
// ============================================================================

import { apiClient } from './client';
import { Instrument } from '../types';
import { SessionResults, SpacedRepetitionData } from '../types/flashcard';

// ============================================================================
// Types
// ============================================================================

interface GetInstrumentsForStudyParams {
  categoryIds?: string[];
  limit?: number;
  excludeRecent?: boolean;
}

interface FlashcardSessionResponse {
  success: boolean;
  sessionId?: string;
  message?: string;
}

interface StudyProgressResponse {
  totalInstruments: number;
  instrumentsStudied: number;
  averageAccuracy: number;
  currentStreak: number;
  longestStreak: number;
  totalSessions: number;
  totalCardsReviewed: number;
  dueForReviewCount: number;
  lastStudyDate?: string;
}

// ============================================================================
// API Functions
// ============================================================================

/**
 * Get instruments for flashcard study
 * Optionally filter by categories and exclude recently studied
 */
export const getInstrumentsForStudy = async (
  params: GetInstrumentsForStudyParams = {}
): Promise<Instrument[]> => {
  const { categoryIds, limit = 20, excludeRecent = true } = params;
  
  const queryParams = new URLSearchParams();
  if (categoryIds && categoryIds.length > 0) {
    queryParams.append('category_ids', categoryIds.join(','));
  }
  queryParams.append('limit', limit.toString());
  queryParams.append('exclude_recent', excludeRecent.toString());
  queryParams.append('shuffle', 'true');
  
  const response = await apiClient.get<Instrument[]>(
    `/study/instruments?${queryParams.toString()}`
  );
  
  return response.data;
};

/**
 * Get instruments due for spaced repetition review
 */
export const getDueForReview = async (limit: number = 20): Promise<Instrument[]> => {
  const response = await apiClient.get<Instrument[]>(
    `/study/due-review?limit=${limit}`
  );
  
  return response.data;
};

/**
 * Get user's bookmarked instruments
 */
export const getBookmarkedInstruments = async (
  limit: number = 20
): Promise<Instrument[]> => {
  const response = await apiClient.get<Instrument[]>(
    `/study/bookmarked?limit=${limit}`
  );
  
  return response.data;
};

/**
 * Record a completed flashcard session
 */
export const recordFlashcardSession = async (
  results: SessionResults
): Promise<FlashcardSessionResponse> => {
  const payload = {
    session_id: results.sessionId,
    total_cards: results.totalCards,
    got_it_count: results.gotItCount,
    study_more_count: results.studyMoreCount,
    average_response_time: results.averageResponseTime,
    accuracy: results.accuracy,
    duration_seconds: results.duration,
    card_results: results.cardResults.map((r) => ({
      instrument_id: r.instrumentId,
      got_it: r.gotIt,
      response_time: r.responseTime,
    })),
    started_at: results.startedAt.toISOString(),
    completed_at: results.completedAt.toISOString(),
  };
  
  const response = await apiClient.post<FlashcardSessionResponse>(
    '/study/flashcard-session',
    payload
  );
  
  return response.data;
};

/**
 * Update spaced repetition data for an instrument
 */
export const updateSpacedRepetition = async (
  instrumentId: string,
  data: Partial<SpacedRepetitionData>
): Promise<SpacedRepetitionData> => {
  const payload = {
    ease_factor: data.easeFactor,
    interval: data.interval,
    repetitions: data.repetitions,
    next_review_date: data.nextReviewDate?.toISOString(),
  };
  
  const response = await apiClient.patch<SpacedRepetitionData>(
    `/study/instruments/${instrumentId}/progress`,
    payload
  );
  
  return response.data;
};

/**
 * Get overall study progress/stats
 */
export const getStudyProgress = async (): Promise<StudyProgressResponse> => {
  const response = await apiClient.get<StudyProgressResponse>('/study/progress');
  return response.data;
};

/**
 * Bookmark/unbookmark an instrument for study
 */
export const toggleBookmark = async (
  instrumentId: string
): Promise<{ bookmarked: boolean }> => {
  const response = await apiClient.post<{ bookmarked: boolean }>(
    `/instruments/${instrumentId}/bookmark`
  );
  
  return response.data;
};

/**
 * Get recent flashcard sessions
 */
export const getRecentSessions = async (
  limit: number = 10
): Promise<SessionResults[]> => {
  const response = await apiClient.get<SessionResults[]>(
    `/study/sessions?limit=${limit}`
  );
  
  return response.data;
};

// ============================================================================
// Export
// ============================================================================

export const quizApi = {
  getInstrumentsForStudy,
  getDueForReview,
  getBookmarkedInstruments,
  recordFlashcardSession,
  updateSpacedRepetition,
  getStudyProgress,
  toggleBookmark,
  getRecentSessions,
};

export default quizApi;
