// Types for Surgical Instruments - matches backend Pydantic schemas

export interface Instrument {
  id: string;
  name: string;
  aliases: string[] | null;
  category: InstrumentCategory;
  description: string | null;
  primary_uses: string[] | null;
  common_procedures: string[] | null;
  handling_notes: string | null;
  image_url: string | null;
  thumbnail_url: string | null;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

export type InstrumentCategory =
  | 'cutting'
  | 'grasping'
  | 'clamping'
  | 'retracting'
  | 'suturing'
  | 'suctioning'
  | 'dilating'
  | 'probing'
  | 'measuring'
  | 'specialty'
  | 'other';

export const INSTRUMENT_CATEGORIES: { value: InstrumentCategory; label: string }[] = [
  { value: 'cutting', label: 'Cutting & Dissecting' },
  { value: 'grasping', label: 'Grasping & Holding' },
  { value: 'clamping', label: 'Clamping & Occluding' },
  { value: 'retracting', label: 'Retracting & Exposing' },
  { value: 'suturing', label: 'Suturing & Stapling' },
  { value: 'suctioning', label: 'Suctioning & Aspirating' },
  { value: 'dilating', label: 'Dilating & Probing' },
  { value: 'probing', label: 'Probing & Exploring' },
  { value: 'measuring', label: 'Measuring' },
  { value: 'specialty', label: 'Specialty' },
  { value: 'other', label: 'Other' },
];

// Request/Response types for API calls

export interface GetInstrumentsParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: InstrumentCategory;
  sort_by?: 'name' | 'created_at' | 'updated_at';
  sort_order?: 'asc' | 'desc';
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  total_pages: number;
  has_next: boolean;
  has_previous: boolean;
}

export type InstrumentsResponse = PaginatedResponse<Instrument>;

export interface InstrumentSearchParams {
  query: string;
  limit?: number;
  category?: InstrumentCategory;
}

export interface InstrumentSearchResult {
  id: string;
  name: string;
  category: InstrumentCategory;
  thumbnail_url: string | null;
  relevance_score: number;
}

export interface InstrumentSearchResponse {
  results: InstrumentSearchResult[];
  query: string;
  total_results: number;
}

// For instrument detail view - includes premium fields
export interface InstrumentDetail extends Instrument {
  // Additional fields that might be premium-only
  detailed_description?: string;
  usage_tips?: string[];
  related_instruments?: RelatedInstrument[];
}

export interface RelatedInstrument {
  id: string;
  name: string;
  thumbnail_url: string | null;
  category: InstrumentCategory;
}
