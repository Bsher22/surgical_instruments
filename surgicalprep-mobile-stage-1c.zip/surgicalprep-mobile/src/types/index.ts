// ============================================
// User Types
// ============================================
export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  institution?: string;
  is_premium: boolean;
  premium_expires_at?: string;
  created_at: string;
  updated_at: string;
}

export type UserRole = 'student' | 'surgical_tech' | 'nurse' | 'resident' | 'other';

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  token_type: string;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface SignupRequest {
  email: string;
  password: string;
  name: string;
  role: UserRole;
  institution?: string;
}

// ============================================
// Instrument Types
// ============================================
export interface Instrument {
  id: string;
  name: string;
  aliases?: string[];
  category: InstrumentCategory;
  description: string;
  primary_uses: string[];
  common_procedures?: string[];
  handling_notes?: string;
  image_url?: string;
  thumbnail_url?: string;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

export type InstrumentCategory =
  | 'Cutting & Dissecting'
  | 'Clamping & Occluding'
  | 'Grasping & Holding'
  | 'Retracting & Exposing'
  | 'Suturing & Stapling'
  | 'Suctioning'
  | 'Dilating & Probing'
  | 'Specialty';

export interface InstrumentSearchParams {
  query?: string;
  category?: InstrumentCategory;
  page?: number;
  limit?: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  pages: number;
}

// ============================================
// Preference Card Types
// ============================================
export interface PreferenceCard {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: SurgicalSpecialty;
  general_notes?: string;
  setup_notes?: string;
  is_template: boolean;
  is_public: boolean;
  created_at: string;
  updated_at: string;
  items?: PreferenceCardItem[];
  photos?: CardPhoto[];
}

export type SurgicalSpecialty =
  | 'General Surgery'
  | 'Orthopedic'
  | 'Cardiovascular'
  | 'Neurosurgery'
  | 'OB/GYN'
  | 'Urology'
  | 'ENT'
  | 'Plastic Surgery'
  | 'Ophthalmology'
  | 'Other';

export interface PreferenceCardItem {
  id: string;
  card_id: string;
  instrument_id?: string;
  custom_name?: string;
  quantity: number;
  size?: string;
  notes?: string;
  category: ItemCategory;
  sort_order: number;
  instrument?: Instrument;
}

export type ItemCategory = 'instrument' | 'supply' | 'suture' | 'implant' | 'other';

export interface CardPhoto {
  id: string;
  card_id: string;
  url: string;
  caption?: string;
  sort_order: number;
}

export interface CreateCardRequest {
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: SurgicalSpecialty;
  general_notes?: string;
  setup_notes?: string;
}

export interface UpdateCardRequest extends Partial<CreateCardRequest> {}

export interface AddItemRequest {
  instrument_id?: string;
  custom_name?: string;
  quantity?: number;
  size?: string;
  notes?: string;
  category?: ItemCategory;
}

// ============================================
// Quiz Types
// ============================================
export interface QuizSession {
  id: string;
  user_id: string;
  quiz_type: QuizType;
  category?: InstrumentCategory;
  total_questions: number;
  correct_answers: number;
  completed_at?: string;
  created_at: string;
}

export type QuizType = 'flashcard' | 'multiple_choice' | 'image_to_name' | 'name_to_use';

export interface QuizQuestion {
  id: string;
  instrument_id: string;
  question_type: QuizType;
  question_text: string;
  image_url?: string;
  options?: string[];
  correct_answer: string;
}

export interface QuizAnswer {
  question_id: string;
  user_answer: string;
  is_correct: boolean;
  time_taken_ms?: number;
}

export interface StartQuizRequest {
  quiz_type: QuizType;
  category?: InstrumentCategory;
  question_count?: number;
}

export interface QuizSessionResult {
  session: QuizSession;
  questions: QuizQuestion[];
}

// ============================================
// Study Progress Types
// ============================================
export interface UserInstrumentProgress {
  id: string;
  user_id: string;
  instrument_id: string;
  times_studied: number;
  times_correct: number;
  last_studied_at: string;
  next_review_at: string;
  ease_factor: number;
  interval_days: number;
  is_bookmarked: boolean;
}

export interface StudyStats {
  total_instruments_studied: number;
  total_quizzes_completed: number;
  average_score: number;
  current_streak: number;
  due_for_review: number;
}

// ============================================
// API Response Types
// ============================================
export interface ApiError {
  detail: string;
  status_code?: number;
}

export interface ApiResponse<T> {
  data?: T;
  error?: ApiError;
}
