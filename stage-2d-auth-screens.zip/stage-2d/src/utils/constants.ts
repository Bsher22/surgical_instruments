/**
 * Application Constants
 *
 * Centralized configuration values used throughout the app.
 */

// API Configuration
export const API_CONFIG = {
  TIMEOUT: 30000, // 30 seconds
  RETRY_ATTEMPTS: 3,
  RETRY_DELAY: 1000, // 1 second
};

// Authentication
export const AUTH_CONFIG = {
  TOKEN_REFRESH_THRESHOLD: 5 * 60 * 1000, // Refresh 5 minutes before expiry
  SESSION_CHECK_INTERVAL: 60 * 1000, // Check session every minute
};

// Form Validation
export const VALIDATION = {
  PASSWORD_MIN_LENGTH: 8,
  PASSWORD_MAX_LENGTH: 128,
  NAME_MIN_LENGTH: 2,
  NAME_MAX_LENGTH: 100,
  EMAIL_MAX_LENGTH: 254,
};

// Free Tier Limits
export const FREE_TIER_LIMITS = {
  MAX_PREFERENCE_CARDS: 5,
  MAX_DAILY_QUIZZES: 3,
  MAX_STUDY_INSTRUMENTS: 50,
};

// Premium Features
export const PREMIUM_FEATURES = [
  'Unlimited preference cards',
  'Unlimited daily quizzes',
  'Full instrument database access',
  'Advanced study statistics',
  'Export preference cards',
  'Priority support',
];

// App Store IDs (update when published)
export const APP_STORE = {
  IOS_APP_ID: '', // Add after App Store submission
  ANDROID_PACKAGE: 'com.yourname.surgicalprep',
};

// External Links
export const LINKS = {
  PRIVACY_POLICY: 'https://surgicalprep.app/privacy',
  TERMS_OF_SERVICE: 'https://surgicalprep.app/terms',
  SUPPORT_EMAIL: 'support@surgicalprep.app',
  HELP_CENTER: 'https://surgicalprep.app/help',
};

// Theme Colors
export const COLORS = {
  // Primary - Teal (medical/trustworthy)
  primary: '#0D9488',
  primaryLight: '#14B8A6',
  primaryDark: '#0F766E',
  primaryBackground: '#ECFDF5',

  // Secondary
  secondary: '#6366F1',
  secondaryLight: '#818CF8',
  secondaryDark: '#4F46E5',

  // Neutrals
  background: '#F8FAFB',
  surface: '#FFFFFF',
  textPrimary: '#1F2937',
  textSecondary: '#6B7280',
  textMuted: '#9CA3AF',
  border: '#E5E7EB',
  borderLight: '#F3F4F6',

  // Status
  success: '#10B981',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#3B82F6',

  // Premium
  premium: '#F59E0B',
  premiumBackground: '#FFFBEB',
};

// Spacing Scale
export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
};

// Font Sizes
export const FONT_SIZES = {
  xs: 12,
  sm: 14,
  md: 16,
  lg: 18,
  xl: 20,
  xxl: 24,
  xxxl: 28,
  display: 32,
};

// Border Radius
export const RADIUS = {
  sm: 6,
  md: 10,
  lg: 12,
  xl: 16,
  full: 9999,
};

// Animation Durations (ms)
export const ANIMATION = {
  fast: 150,
  normal: 300,
  slow: 500,
};

// Instrument Categories for filtering
export const INSTRUMENT_CATEGORIES = [
  { value: 'cutting', label: 'Cutting' },
  { value: 'grasping', label: 'Grasping' },
  { value: 'clamping', label: 'Clamping' },
  { value: 'retracting', label: 'Retracting' },
  { value: 'probing', label: 'Probing' },
  { value: 'suturing', label: 'Suturing' },
  { value: 'dilating', label: 'Dilating' },
  { value: 'suctioning', label: 'Suctioning' },
  { value: 'specialty', label: 'Specialty' },
  { value: 'other', label: 'Other' },
] as const;

// Specialties for preference cards
export const SPECIALTIES = [
  { value: 'general', label: 'General Surgery' },
  { value: 'orthopedic', label: 'Orthopedic' },
  { value: 'obgyn', label: 'OB/GYN' },
  { value: 'neuro', label: 'Neurosurgery' },
  { value: 'cardiovascular', label: 'Cardiovascular' },
  { value: 'plastic', label: 'Plastic Surgery' },
  { value: 'urology', label: 'Urology' },
  { value: 'ent', label: 'ENT' },
  { value: 'ophthalmic', label: 'Ophthalmic' },
  { value: 'pediatric', label: 'Pediatric' },
  { value: 'other', label: 'Other' },
] as const;
