// ============================================================================
// Flashcards Screen (Placeholder - Full implementation in Stage 6C)
// ============================================================================

import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { useRouter } from 'expo-router';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons } from '@expo/vector-icons';

import { colors, spacing, typography } from '../../../src/utils/theme';

/**
 * Flashcards Screen
 * 
 * This is a placeholder screen. Full implementation will include:
 * - Swipeable card stack
 * - Card flip animations
 * - Progress tracking
 * - Spaced repetition responses
 * 
 * See Stage 6C for full implementation details.
 */
export default function FlashcardsScreen() {
  const router = useRouter();

  return (
    <SafeAreaView style={styles.container}>
      {/* Header */}
      <View style={styles.header}>
        <TouchableOpacity
          style={styles.closeButton}
          onPress={() => router.back()}
        >
          <Ionicons name="close" size={28} color={colors.text} />
        </TouchableOpacity>
        <Text style={styles.title}>Flashcards</Text>
        <View style={styles.placeholder} />
      </View>

      {/* Content */}
      <View style={styles.content}>
        <Ionicons name="layers-outline" size={80} color={colors.textTertiary} />
        <Text style={styles.placeholderTitle}>Flashcard Mode</Text>
        <Text style={styles.placeholderText}>
          Full implementation coming in Stage 6C
        </Text>
        <Text style={styles.placeholderFeatures}>
          Features will include:{'\n'}
          • Swipeable card stack{'\n'}
          • Tap to flip animations{'\n'}
          • Spaced repetition tracking{'\n'}
          • Session progress and summary
        </Text>
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: colors.background,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: spacing.md,
    paddingVertical: spacing.md,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  closeButton: {
    width: 44,
    height: 44,
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: typography.sizes.lg,
    fontWeight: typography.weights.semibold,
    color: colors.text,
  },
  placeholder: {
    width: 44,
  },
  content: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: spacing.xl,
    gap: spacing.md,
  },
  placeholderTitle: {
    fontSize: typography.sizes.xxl,
    fontWeight: typography.weights.bold,
    color: colors.text,
    marginTop: spacing.md,
  },
  placeholderText: {
    fontSize: typography.sizes.md,
    color: colors.textSecondary,
  },
  placeholderFeatures: {
    fontSize: typography.sizes.sm,
    color: colors.textTertiary,
    textAlign: 'center',
    lineHeight: 24,
    marginTop: spacing.md,
  },
});
