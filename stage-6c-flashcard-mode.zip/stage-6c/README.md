# Stage 6C: Flashcard Mode

This stage implements an interactive flashcard study system with swipeable cards, flip animations, and session tracking for the SurgicalPrep app.

## Features

- **Swipeable Card Stack**: Gesture-based card navigation with smooth animations
- **Flip Animation**: Tap to flip cards between question (image) and answer (details)
- **Progress Tracking**: Visual progress bar with got it/study more counts
- **Session Summary**: Comprehensive results with accuracy, timing stats, and grade
- **Spaced Repetition**: SM-2 algorithm integration for optimal review scheduling
- **Haptic Feedback**: Tactile responses for swipes, flips, and completions
- **Review Mistakes**: Option to re-study incorrectly answered cards

## File Structure

```
stage-6c/
├── app/
│   └── (tabs)/
│       └── quiz/
│           └── flashcards.tsx       # Main flashcard screen
├── src/
│   ├── api/
│   │   └── quiz.ts                  # Quiz API endpoints
│   ├── components/
│   │   └── flashcard/
│   │       ├── index.ts             # Component exports
│   │       ├── FlashCard.tsx        # Individual card with flip
│   │       ├── SwipeableCardStack.tsx # Gesture-enabled stack
│   │       ├── FlashcardProgressBar.tsx # Progress indicator
│   │       └── SessionSummary.tsx   # Results display
│   ├── hooks/
│   │   └── useFlashcardSession.ts   # Session management hooks
│   ├── stores/
│   │   └── flashcardStore.ts        # Zustand state management
│   ├── types/
│   │   └── flashcard.ts             # TypeScript definitions
│   └── utils/
│       ├── haptics.ts               # Haptic feedback utility
│       └── theme.ts                 # Colors, typography, spacing
└── README.md
```

## Installation

### 1. Required Dependencies

Add these to your existing `package.json` if not already present:

```bash
# Gesture handling and animations
npx expo install react-native-gesture-handler react-native-reanimated

# Haptic feedback
npx expo install expo-haptics

# UUID generation (for session IDs)
npm install uuid
npm install --save-dev @types/uuid
```

### 2. Configure Babel

Ensure `babel.config.js` includes the Reanimated plugin:

```javascript
module.exports = function (api) {
  api.cache(true);
  return {
    presets: ['babel-preset-expo'],
    plugins: ['react-native-reanimated/plugin'],
  };
};
```

### 3. Copy Files

Copy the stage-6c files to your mobile project:

```bash
# Copy components
cp -r stage-6c/src/components/flashcard mobile/src/components/

# Copy types
cp stage-6c/src/types/flashcard.ts mobile/src/types/

# Copy store
cp stage-6c/src/stores/flashcardStore.ts mobile/src/stores/

# Copy hooks
cp stage-6c/src/hooks/useFlashcardSession.ts mobile/src/hooks/

# Copy API
cp stage-6c/src/api/quiz.ts mobile/src/api/

# Copy utils (if not already present)
cp stage-6c/src/utils/haptics.ts mobile/src/utils/
cp stage-6c/src/utils/theme.ts mobile/src/utils/

# Copy screen
cp stage-6c/app/\(tabs\)/quiz/flashcards.tsx mobile/app/\(tabs\)/quiz/
```

### 4. Update Types Index

Add flashcard types export to `src/types/index.ts`:

```typescript
export * from './flashcard';
```

### 5. Wrap App with GestureHandler

Ensure your root layout includes GestureHandlerRootView:

```typescript
// app/_layout.tsx
import { GestureHandlerRootView } from 'react-native-gesture-handler';

export default function RootLayout() {
  return (
    <GestureHandlerRootView style={{ flex: 1 }}>
      {/* Your app content */}
    </GestureHandlerRootView>
  );
}
```

## Usage

### Starting a Flashcard Session

Navigate to the flashcards screen with optional parameters:

```typescript
import { useRouter } from 'expo-router';

const router = useRouter();

// Start with all instruments
router.push('/quiz/flashcards');

// Start with specific mode
router.push('/quiz/flashcards?mode=due_review');

// Start with category filter
router.push('/quiz/flashcards?mode=all&categoryIds=cutting,grasping&count=10');
```

### Available Modes

| Mode | Description |
|------|-------------|
| `all` | Random selection from all instruments |
| `due_review` | Instruments due for spaced repetition review |
| `bookmarked` | User's bookmarked instruments |

### Query Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `mode` | string | `all` | Study mode (all, due_review, bookmarked) |
| `categoryIds` | string | - | Comma-separated category IDs |
| `count` | number | `20` | Number of cards in session |

## Components

### FlashCard

Individual flashcard with flip animation.

```typescript
<FlashCard
  item={flashcardItem}
  onFlip={() => handleFlip(item.id)}
  isActive={true}
  showHint={true}
/>
```

### SwipeableCardStack

Gesture-enabled card stack with swipe detection.

```typescript
<SwipeableCardStack
  cards={session.cards}
  currentIndex={session.currentIndex}
  onSwipe={(direction, cardId, responseTime) => handleSwipe(direction, cardId, responseTime)}
  onFlip={(cardId) => handleFlip(cardId)}
/>
```

### FlashcardProgressBar

Visual progress indicator.

```typescript
<FlashcardProgressBar
  current={5}
  total={20}
  gotItCount={3}
  studyMoreCount={2}
/>
```

### SessionSummary

Results display with actions.

```typescript
<SessionSummary
  results={sessionResults}
  onRestart={() => restartSession()}
  onReviewMistakes={() => reviewMistakes()}
  onGoHome={() => goBack()}
/>
```

## Hooks

### useFlashcardSession

Main hook for session management.

```typescript
const {
  session,
  currentCard,
  progress,
  isActive,
  isComplete,
  initialize,
  start,
  flip,
  swipe,
  reset,
  reviewMistakes,
} = useFlashcardSession({
  onSessionComplete: (results) => console.log(results),
});
```

### useFlashcardInstruments

Fetch instruments for study.

```typescript
const { data, isLoading, error } = useFlashcardInstruments({
  mode: 'all',
  categoryIds: ['cutting'],
  limit: 20,
});
```

### useSpacedRepetition

SM-2 algorithm calculations.

```typescript
const { calculateNextReview, swipeToQuality } = useSpacedRepetition();

const quality = swipeToQuality(gotIt, responseTime);
const nextData = calculateNextReview(currentData, quality);
```

### useSessionTimer

Track session duration.

```typescript
const { elapsed, formatted, reset } = useSessionTimer(isActive);
// formatted: "2:45"
```

## Backend API Endpoints

The quiz API client expects these endpoints:

```
GET  /study/instruments      # Get instruments for study
GET  /study/due-review       # Get instruments due for review
GET  /study/bookmarked       # Get bookmarked instruments
POST /study/flashcard-session # Record completed session
GET  /study/progress         # Get overall study progress
PATCH /study/instruments/:id/progress # Update spaced repetition
```

## Customization

### Theme Colors

Modify `src/utils/theme.ts` to customize the appearance:

```typescript
export const colors = {
  primary: '#0066CC',
  success: '#22C55E',  // Got it color
  error: '#EF4444',    // Study more color
  // ...
};
```

### Card Dimensions

Adjust card size in `FlashCard.tsx`:

```typescript
const CARD_WIDTH = SCREEN_WIDTH - spacing.xl * 2;
const CARD_HEIGHT = CARD_WIDTH * 1.4;  // Aspect ratio
```

### Swipe Threshold

Modify swipe sensitivity in `SwipeableCardStack.tsx`:

```typescript
const SWIPE_THRESHOLD = SCREEN_WIDTH * 0.25;  // 25% of screen width
```

## Testing

Test the flashcard system with mock data:

```typescript
const mockInstruments: Instrument[] = [
  {
    id: '1',
    name: 'Mayo Scissors',
    category: 'Cutting',
    description: 'Heavy scissors for cutting sutures and tissue',
    primary_uses: ['Cutting sutures', 'Cutting heavy tissue'],
    image_url: 'https://example.com/mayo-scissors.jpg',
  },
  // Add more mock instruments...
];
```

## Troubleshooting

### Gestures Not Working

1. Ensure `GestureHandlerRootView` wraps your app
2. Check that `react-native-gesture-handler` is installed correctly
3. Rebuild the app after installing gesture handler

### Animations Choppy

1. Add Reanimated babel plugin to `babel.config.js`
2. Clear babel cache: `npx expo start -c`
3. Use `useAnimatedStyle` instead of inline animated values

### Haptics Not Working

1. Haptics only work on physical devices
2. Check that `expo-haptics` is installed
3. Haptics are disabled on web platform automatically

## Next Steps

After implementing Stage 6C, proceed to:

- **Stage 6D**: Multiple Choice Quiz
- **Stage 6E**: Study Progress Tracking

These will complete the full quiz/study system for SurgicalPrep.
