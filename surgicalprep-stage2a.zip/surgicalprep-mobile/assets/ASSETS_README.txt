Placeholder - Replace with actual icon (1024x1024 PNG)
