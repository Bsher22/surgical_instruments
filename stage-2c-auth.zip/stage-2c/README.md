# Stage 2C: Authentication Store & Flow

This stage implements the complete authentication system for SurgicalPrep using Zustand for state management and expo-secure-store for secure token storage.

## Files Included

```
src/
├── types/
│   ├── auth.ts          # TypeScript interfaces for auth
│   └── index.ts         # Central type exports
├── utils/
│   ├── constants.ts     # App-wide constants
│   └── tokenStorage.ts  # Secure token storage utilities
├── api/
│   └── auth.ts          # Auth API functions
├── stores/
│   └── authStore.ts     # Zustand auth store
├── hooks/
│   └── useAuth.ts       # Auth convenience hooks
└── components/
    └── ProtectedRoute.tsx  # Protected route wrapper
```

## Installation

Ensure these dependencies are installed:

```bash
npx expo install expo-secure-store zustand
```

## Setup

### 1. Configure API Base URL

Update `src/utils/constants.ts` or set the environment variable:

```bash
# In .env or app.json extra config
EXPO_PUBLIC_API_URL=https://your-api.railway.app/api/v1
```

### 2. Initialize Auth in Root Layout

In your `app/_layout.tsx`:

```tsx
import { useAuthInitializer } from '@/src/hooks/useAuth';

export default function RootLayout() {
  // Initialize auth on app start
  useAuthInitializer();

  return (
    <Stack>
      <Stack.Screen name="(auth)" options={{ headerShown: false }} />
      <Stack.Screen name="(tabs)" options={{ headerShown: false }} />
    </Stack>
  );
}
```

### 3. Protect Authenticated Routes

In your `app/(tabs)/_layout.tsx`:

```tsx
import { ProtectedRoute } from '@/src/components/ProtectedRoute';

export default function TabsLayout() {
  return (
    <ProtectedRoute>
      <Tabs>
        {/* Your tab screens */}
      </Tabs>
    </ProtectedRoute>
  );
}
```

## Usage Examples

### Login Screen

```tsx
import { useAuth } from '@/src/hooks/useAuth';
import { useState } from 'react';

export default function LoginScreen() {
  const { login, isLoading, error, clearError } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = async () => {
    try {
      await login({ email, password });
      // Navigation happens automatically via ProtectedRoute
    } catch (e) {
      // Error is already set in store
    }
  };

  return (
    <View>
      {error && <Text style={styles.error}>{error}</Text>}
      <TextInput value={email} onChangeText={setEmail} />
      <TextInput value={password} onChangeText={setPassword} secureTextEntry />
      <Button onPress={handleLogin} disabled={isLoading}>
        {isLoading ? 'Logging in...' : 'Login'}
      </Button>
    </View>
  );
}
```

### Accessing User Data

```tsx
import { useAuth } from '@/src/hooks/useAuth';

function ProfileHeader() {
  const { user, isPremium } = useAuth();

  return (
    <View>
      <Text>Hello, {user?.full_name}</Text>
      {isPremium && <Badge>Premium</Badge>}
    </View>
  );
}
```

### Premium Feature Gating

```tsx
import { PremiumGuard } from '@/src/components/ProtectedRoute';
import { useFeatureLimit } from '@/src/hooks/useAuth';
import { FREE_TIER_LIMITS } from '@/src/utils/constants';

function PreferenceCardsList() {
  const cardCount = 3; // From API
  const { remaining, isAtLimit, isPremium } = useFeatureLimit(
    cardCount,
    FREE_TIER_LIMITS.MAX_PREFERENCE_CARDS
  );

  return (
    <View>
      {!isPremium && (
        <Text>Cards: {cardCount}/{FREE_TIER_LIMITS.MAX_PREFERENCE_CARDS}</Text>
      )}
      
      <PremiumGuard
        premium={<CreateCardButton />}
        free={
          isAtLimit ? (
            <UpgradePrompt />
          ) : (
            <CreateCardButton />
          )
        }
      />
    </View>
  );
}
```

### Logout

```tsx
import { useAuth } from '@/src/hooks/useAuth';

function LogoutButton() {
  const { logout, isLoading } = useAuth();

  return (
    <Button onPress={logout} disabled={isLoading}>
      {isLoading ? 'Logging out...' : 'Logout'}
    </Button>
  );
}
```

### Auth Header for API Calls

```tsx
import { useAuthHeader } from '@/src/hooks/useAuth';

function useCustomApiCall() {
  const authHeader = useAuthHeader();

  const fetchData = async () => {
    const response = await fetch(`${API_URL}/custom-endpoint`, {
      headers: {
        'Content-Type': 'application/json',
        ...authHeader,
      },
    });
    return response.json();
  };

  return { fetchData };
}
```

## API Endpoints Expected

The auth system expects these endpoints on your FastAPI backend:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/auth/login` | POST | Login (OAuth2 form data) |
| `/auth/register` | POST | Create new account |
| `/auth/refresh` | POST | Refresh access token |
| `/auth/me` | GET | Get current user |
| `/auth/logout` | POST | Invalidate refresh token |
| `/auth/forgot-password` | POST | Request password reset |
| `/auth/reset-password` | POST | Reset password with token |
| `/auth/change-password` | POST | Change password (authenticated) |

## State Structure

```typescript
interface AuthState {
  user: User | null;           // Current user data
  tokens: AuthTokens | null;   // Access & refresh tokens
  isAuthenticated: boolean;    // Is user logged in
  isLoading: boolean;          // Loading state for operations
  isInitialized: boolean;      // Has initial auth check completed
  error: string | null;        // Current error message
}
```

## Next Steps

After implementing Stage 2C, proceed to:

1. **Stage 2D**: Build the Login and Signup screens using this auth system
2. **Stage 3A**: Create the instruments API layer (uses auth headers from this stage)

## Troubleshooting

### Tokens not persisting
- Ensure `expo-secure-store` is properly installed
- Check that you're testing on a real device or simulator (not Expo Go web)

### Auth not initializing
- Verify `useAuthInitializer()` is called in root layout
- Check console for initialization errors

### API errors
- Confirm `API_BASE_URL` is correctly set
- Verify backend is running and accessible
- Check that endpoint paths match your FastAPI routes
