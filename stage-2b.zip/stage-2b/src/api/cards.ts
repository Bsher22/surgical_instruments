// ============================================
// SurgicalPrep - Cards API
// Preference cards CRUD endpoints
// ============================================

import apiClient from './client';
import type {
  PreferenceCard,
  PreferenceCardCreate,
  PreferenceCardUpdate,
  PreferenceCardItem,
  PreferenceCardItemCreate,
  PreferenceCardItemUpdate,
  CardListParams,
  PaginatedResponse,
} from '../types';

export const cardsApi = {
  // -------------------- Cards --------------------

  /**
   * Get paginated list of user's cards
   */
  getCards: async (params: CardListParams = {}): Promise<PaginatedResponse<PreferenceCard>> => {
    const response = await apiClient.get<PaginatedResponse<PreferenceCard>>('/cards', { params });
    return response.data;
  },

  /**
   * Get single card by ID with all items
   */
  getCard: async (id: string): Promise<PreferenceCard> => {
    const response = await apiClient.get<PreferenceCard>(`/cards/${id}`);
    return response.data;
  },

  /**
   * Create new preference card
   */
  createCard: async (data: PreferenceCardCreate): Promise<PreferenceCard> => {
    const response = await apiClient.post<PreferenceCard>('/cards', data);
    return response.data;
  },

  /**
   * Update preference card
   */
  updateCard: async (id: string, data: PreferenceCardUpdate): Promise<PreferenceCard> => {
    const response = await apiClient.patch<PreferenceCard>(`/cards/${id}`, data);
    return response.data;
  },

  /**
   * Delete preference card
   */
  deleteCard: async (id: string): Promise<void> => {
    await apiClient.delete(`/cards/${id}`);
  },

  /**
   * Duplicate preference card
   */
  duplicateCard: async (id: string): Promise<PreferenceCard> => {
    const response = await apiClient.post<PreferenceCard>(`/cards/${id}/duplicate`);
    return response.data;
  },

  /**
   * Get public template cards
   */
  getTemplates: async (params: Omit<CardListParams, 'templates_only'> = {}): Promise<PaginatedResponse<PreferenceCard>> => {
    const response = await apiClient.get<PaginatedResponse<PreferenceCard>>('/cards/templates', { params });
    return response.data;
  },

  // -------------------- Card Items --------------------

  /**
   * Add item to card
   */
  addItem: async (cardId: string, data: PreferenceCardItemCreate): Promise<PreferenceCardItem> => {
    const response = await apiClient.post<PreferenceCardItem>(`/cards/${cardId}/items`, data);
    return response.data;
  },

  /**
   * Update card item
   */
  updateItem: async (cardId: string, itemId: string, data: PreferenceCardItemUpdate): Promise<PreferenceCardItem> => {
    const response = await apiClient.patch<PreferenceCardItem>(`/cards/${cardId}/items/${itemId}`, data);
    return response.data;
  },

  /**
   * Delete card item
   */
  deleteItem: async (cardId: string, itemId: string): Promise<void> => {
    await apiClient.delete(`/cards/${cardId}/items/${itemId}`);
  },

  /**
   * Reorder card items
   */
  reorderItems: async (cardId: string, itemIds: string[]): Promise<PreferenceCardItem[]> => {
    const response = await apiClient.post<PreferenceCardItem[]>(`/cards/${cardId}/items/reorder`, {
      item_ids: itemIds,
    });
    return response.data;
  },

  // -------------------- Card Photos --------------------

  /**
   * Upload photo to card
   */
  uploadPhoto: async (cardId: string, photo: FormData): Promise<{ url: string }> => {
    const response = await apiClient.post<{ url: string }>(`/cards/${cardId}/photos`, photo, {
      headers: { 'Content-Type': 'multipart/form-data' },
    });
    return response.data;
  },

  /**
   * Delete photo from card
   */
  deletePhoto: async (cardId: string, photoUrl: string): Promise<void> => {
    await apiClient.delete(`/cards/${cardId}/photos`, {
      data: { url: photoUrl },
    });
  },
};

export default cardsApi;
