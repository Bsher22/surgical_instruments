// ============================================
// SurgicalPrep - Quiz API
// Quiz sessions and study progress endpoints
// ============================================

import apiClient from './client';
import type {
  QuizSession,
  QuizSessionCreate,
  QuizAnswerSubmit,
  QuizQuestion,
  UserInstrumentProgress,
  StudyStats,
  Instrument,
  PaginatedResponse,
  InstrumentCategory,
} from '../types';

export const quizApi = {
  // -------------------- Quiz Sessions --------------------

  /**
   * Start a new quiz session
   */
  startSession: async (data: QuizSessionCreate): Promise<QuizSession> => {
    const response = await apiClient.post<QuizSession>('/quiz/sessions', data);
    return response.data;
  },

  /**
   * Get current active session
   */
  getActiveSession: async (): Promise<QuizSession | null> => {
    try {
      const response = await apiClient.get<QuizSession>('/quiz/sessions/active');
      return response.data;
    } catch {
      return null;
    }
  },

  /**
   * Get session by ID
   */
  getSession: async (sessionId: string): Promise<QuizSession> => {
    const response = await apiClient.get<QuizSession>(`/quiz/sessions/${sessionId}`);
    return response.data;
  },

  /**
   * Submit answer for a question
   */
  submitAnswer: async (sessionId: string, data: QuizAnswerSubmit): Promise<QuizQuestion> => {
    const response = await apiClient.post<QuizQuestion>(`/quiz/sessions/${sessionId}/answer`, data);
    return response.data;
  },

  /**
   * End/complete quiz session
   */
  endSession: async (sessionId: string): Promise<QuizSession> => {
    const response = await apiClient.post<QuizSession>(`/quiz/sessions/${sessionId}/complete`);
    return response.data;
  },

  /**
   * Abandon quiz session
   */
  abandonSession: async (sessionId: string): Promise<void> => {
    await apiClient.delete(`/quiz/sessions/${sessionId}`);
  },

  /**
   * Get quiz history
   */
  getSessionHistory: async (params: { page?: number; limit?: number } = {}): Promise<PaginatedResponse<QuizSession>> => {
    const response = await apiClient.get<PaginatedResponse<QuizSession>>('/quiz/sessions', { params });
    return response.data;
  },

  // -------------------- Flashcard Mode --------------------

  /**
   * Get flashcard deck (instruments for study)
   */
  getFlashcardDeck: async (params: {
    category?: InstrumentCategory;
    count?: number;
    due_only?: boolean;
  } = {}): Promise<Instrument[]> => {
    const response = await apiClient.get<Instrument[]>('/quiz/flashcards', { params });
    return response.data;
  },

  /**
   * Record flashcard result
   */
  recordFlashcardResult: async (instrumentId: string, result: 'correct' | 'incorrect'): Promise<UserInstrumentProgress> => {
    const response = await apiClient.post<UserInstrumentProgress>('/quiz/flashcards/result', {
      instrument_id: instrumentId,
      result,
    });
    return response.data;
  },

  // -------------------- Study Progress --------------------

  /**
   * Get user's study statistics
   */
  getStudyStats: async (): Promise<StudyStats> => {
    const response = await apiClient.get<StudyStats>('/study/stats');
    return response.data;
  },

  /**
   * Get instruments due for review (spaced repetition)
   */
  getDueForReview: async (params: { limit?: number } = {}): Promise<Instrument[]> => {
    const response = await apiClient.get<Instrument[]>('/study/due', { params });
    return response.data;
  },

  /**
   * Get progress for specific instrument
   */
  getInstrumentProgress: async (instrumentId: string): Promise<UserInstrumentProgress> => {
    const response = await apiClient.get<UserInstrumentProgress>(`/study/progress/${instrumentId}`);
    return response.data;
  },

  /**
   * Get all instrument progress (paginated)
   */
  getAllProgress: async (params: { page?: number; limit?: number } = {}): Promise<PaginatedResponse<UserInstrumentProgress>> => {
    const response = await apiClient.get<PaginatedResponse<UserInstrumentProgress>>('/study/progress', { params });
    return response.data;
  },

  /**
   * Reset progress for instrument
   */
  resetInstrumentProgress: async (instrumentId: string): Promise<void> => {
    await apiClient.delete(`/study/progress/${instrumentId}`);
  },

  /**
   * Reset all study progress
   */
  resetAllProgress: async (): Promise<void> => {
    await apiClient.delete('/study/progress');
  },
};

export default quizApi;
