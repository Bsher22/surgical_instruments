import axios, { AxiosInstance, AxiosRequestConfig, AxiosError } from 'axios';
import * as SecureStore from 'expo-secure-store';
import { API_URL } from '../utils/constants';

const TOKEN_KEY = 'auth_token';

/**
 * Create configured axios instance
 */
function createApiClient(): AxiosInstance {
  const client = axios.create({
    baseURL: API_URL,
    timeout: 15000,
    headers: {
      'Content-Type': 'application/json',
    },
  });

  // Request interceptor - add auth token
  client.interceptors.request.use(
    async (config) => {
      try {
        const token = await SecureStore.getItemAsync(TOKEN_KEY);
        if (token) {
          config.headers.Authorization = `Bearer ${token}`;
        }
      } catch (error) {
        console.warn('Failed to get auth token:', error);
      }
      return config;
    },
    (error) => Promise.reject(error)
  );

  // Response interceptor - handle errors
  client.interceptors.response.use(
    (response) => response,
    async (error: AxiosError) => {
      const originalRequest = error.config as AxiosRequestConfig & {
        _retry?: boolean;
      };

      // Handle 401 - Token expired
      if (error.response?.status === 401 && !originalRequest._retry) {
        originalRequest._retry = true;

        try {
          // Attempt to refresh token
          const refreshToken = await SecureStore.getItemAsync('refresh_token');
          if (refreshToken) {
            const response = await axios.post(`${API_URL}/auth/refresh`, {
              refresh_token: refreshToken,
            });

            const { access_token } = response.data;
            await SecureStore.setItemAsync(TOKEN_KEY, access_token);

            // Retry original request with new token
            if (originalRequest.headers) {
              originalRequest.headers.Authorization = `Bearer ${access_token}`;
            }
            return client(originalRequest);
          }
        } catch (refreshError) {
          // Refresh failed - clear tokens and redirect to login
          await SecureStore.deleteItemAsync(TOKEN_KEY);
          await SecureStore.deleteItemAsync('refresh_token');
          // Could emit event here to trigger logout in auth store
        }
      }

      // Handle 403 - Premium content gating
      if (error.response?.status === 403) {
        const data = error.response.data as { detail?: string };
        if (data.detail?.includes('premium')) {
          // This is a premium-gated resource
          // The UI should handle this gracefully
          console.log('Premium content requested by free user');
        }
      }

      // Format error message
      const message = extractErrorMessage(error);
      return Promise.reject(new Error(message));
    }
  );

  return client;
}

/**
 * Extract readable error message from axios error
 */
function extractErrorMessage(error: AxiosError): string {
  if (error.response?.data) {
    const data = error.response.data as { detail?: string; message?: string };
    return data.detail || data.message || 'An unexpected error occurred';
  }

  if (error.request) {
    return 'Network error. Please check your connection.';
  }

  return error.message || 'An unexpected error occurred';
}

export const apiClient = createApiClient();

// Export types for use in API modules
export type ApiResponse<T> = {
  data: T;
  status: number;
};

export type ApiError = {
  message: string;
  status?: number;
  code?: string;
};
