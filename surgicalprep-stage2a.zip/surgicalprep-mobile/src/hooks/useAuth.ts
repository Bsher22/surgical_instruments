import { useAuthStore } from '../stores/authStore';

/**
 * Custom hook for authentication state and actions
 * Provides a simplified interface to the auth store
 */
export function useAuth() {
  const {
    user,
    isAuthenticated,
    isLoading,
    error,
    login,
    signup,
    logout,
    clearError,
  } = useAuthStore();

  const isPremium = user?.subscription_tier === 'premium';
  
  const isSubscriptionValid = () => {
    if (!user?.subscription_expires_at) return false;
    return new Date(user.subscription_expires_at) > new Date();
  };

  return {
    user,
    isAuthenticated,
    isLoading,
    error,
    isPremium: isPremium && isSubscriptionValid(),
    login,
    signup,
    logout,
    clearError,
  };
}
