import apiClient, { tokenManager } from './client';
import { ENDPOINTS } from '@/utils/constants';
import { User, AuthTokens, LoginRequest, SignupRequest } from '@/types';

export const authApi = {
  async login(credentials: LoginRequest): Promise<AuthTokens> {
    const formData = new URLSearchParams();
    formData.append('username', credentials.email);
    formData.append('password', credentials.password);

    const response = await apiClient.post<AuthTokens>(ENDPOINTS.login, formData, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    await tokenManager.setTokens(response.data);
    return response.data;
  },

  async signup(data: SignupRequest): Promise<User> {
    const response = await apiClient.post<User>(ENDPOINTS.signup, data);
    return response.data;
  },

  async getCurrentUser(): Promise<User> {
    const response = await apiClient.get<User>(ENDPOINTS.me);
    return response.data;
  },

  async logout(): Promise<void> {
    await tokenManager.clearTokens();
  },

  async checkAuthStatus(): Promise<User | null> {
    const token = await tokenManager.getAccessToken();
    if (!token) {
      return null;
    }

    try {
      return await this.getCurrentUser();
    } catch {
      await tokenManager.clearTokens();
      return null;
    }
  },
};
