// src/utils/constants.ts
// App-wide constants

import Constants from 'expo-constants';

/**
 * API Base URL
 * In development, this comes from app.json extra config or defaults to localhost
 * In production, this should be your deployed backend URL
 */
export const API_BASE_URL: string =
  Constants.expoConfig?.extra?.apiUrl ||
  process.env.EXPO_PUBLIC_API_URL ||
  'http://localhost:8000/api/v1';

/**
 * App version
 */
export const APP_VERSION: string =
  Constants.expoConfig?.version || '1.0.0';

/**
 * Feature flags and limits
 */
export const FREE_TIER_LIMITS = {
  MAX_PREFERENCE_CARDS: 5,
  MAX_DAILY_QUIZZES: 3,
  MAX_INSTRUMENTS_VIEWED: 50, // per day
} as const;

/**
 * Storage keys (non-sensitive, for AsyncStorage)
 */
export const STORAGE_KEYS = {
  THEME_PREFERENCE: 'surgicalprep_theme',
  RECENT_SEARCHES: 'surgicalprep_recent_searches',
  QUIZ_PREFERENCES: 'surgicalprep_quiz_prefs',
  ONBOARDING_COMPLETE: 'surgicalprep_onboarding_complete',
} as const;

/**
 * Query keys for React Query
 */
export const QUERY_KEYS = {
  USER: ['user'] as const,
  INSTRUMENTS: ['instruments'] as const,
  INSTRUMENT: (id: string) => ['instruments', id] as const,
  PREFERENCE_CARDS: ['preference-cards'] as const,
  PREFERENCE_CARD: (id: string) => ['preference-cards', id] as const,
  QUIZ_SESSION: (id: string) => ['quiz-session', id] as const,
  STUDY_PROGRESS: ['study-progress'] as const,
} as const;

/**
 * Time constants (in milliseconds)
 */
export const TIME = {
  SEARCH_DEBOUNCE: 300,
  TOKEN_REFRESH_BUFFER: 60 * 1000, // Refresh 1 minute before expiry
  STALE_TIME: 5 * 60 * 1000, // React Query stale time: 5 minutes
  CACHE_TIME: 30 * 60 * 1000, // React Query cache time: 30 minutes
} as const;
