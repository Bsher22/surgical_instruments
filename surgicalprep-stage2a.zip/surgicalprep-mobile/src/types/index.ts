// ============================================
// User & Auth Types
// ============================================

export interface User {
  id: string;
  email: string;
  name: string;
  role?: string;
  institution?: string;
  subscription_tier: 'free' | 'premium';
  subscription_expires_at?: string;
  created_at: string;
  updated_at: string;
}

export interface SignupData {
  email: string;
  password: string;
  name: string;
  role?: string;
  institution?: string;
}

export interface AuthTokens {
  access_token: string;
  refresh_token?: string;
  token_type: string;
}

// ============================================
// Instrument Types
// ============================================

export type InstrumentCategory =
  | 'cutting'
  | 'grasping'
  | 'clamping'
  | 'retracting'
  | 'suturing'
  | 'specialty'
  | 'other';

export interface Instrument {
  id: string;
  name: string;
  aliases?: string[];
  category: InstrumentCategory;
  description: string;
  primary_uses: string[];
  common_procedures?: string[];
  handling_notes?: string;
  image_url?: string;
  thumbnail_url?: string;
  is_premium: boolean;
  created_at: string;
  updated_at: string;
}

// ============================================
// Preference Card Types
// ============================================

export type ItemCategory =
  | 'instruments'
  | 'supplies'
  | 'sutures'
  | 'implants'
  | 'other';

export interface CardItem {
  id: string;
  instrument_id?: string;
  custom_name?: string;
  category: ItemCategory;
  quantity: number;
  size?: string;
  notes?: string;
  sort_order: number;
  
  // Populated from instrument if instrument_id exists
  instrument?: Instrument;
}

export interface PreferenceCard {
  id: string;
  user_id: string;
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: string;
  general_notes?: string;
  setup_notes?: string;
  is_template: boolean;
  is_public: boolean;
  items: CardItem[];
  photos?: string[];
  created_at: string;
  updated_at: string;
}

export interface PreferenceCardCreate {
  title: string;
  surgeon_name?: string;
  procedure_name?: string;
  specialty?: string;
  general_notes?: string;
  setup_notes?: string;
  items?: Omit<CardItem, 'id'>[];
}

export interface PreferenceCardUpdate extends Partial<PreferenceCardCreate> {}

// ============================================
// Quiz & Study Types
// ============================================

export type QuestionType =
  | 'image_to_name'
  | 'name_to_use'
  | 'image_to_category';

export interface QuizQuestion {
  id: string;
  type: QuestionType;
  prompt: string;
  image_url?: string;
  options: string[];
  instrument_id: string;
}

export interface QuizSession {
  id: string;
  user_id: string;
  question_count: number;
  correct_count: number;
  started_at: string;
  ended_at?: string;
  score?: number;
}

export interface UserInstrumentProgress {
  id: string;
  user_id: string;
  instrument_id: string;
  times_studied: number;
  correct_count: number;
  incorrect_count: number;
  last_studied_at: string;
  next_review_at: string;
  ease_factor: number;
  interval_days: number;
}

export interface StudyProgress {
  total_studied: number;
  average_accuracy: number;
  due_for_review: number;
  current_streak: number;
  instruments_mastered: number;
}

// ============================================
// API Response Types
// ============================================

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  limit: number;
  has_more: boolean;
}

export interface ApiError {
  detail: string;
  status_code?: number;
}
