# Placeholder for instrument-placeholder.png
