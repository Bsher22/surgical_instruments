import { useQuery, useInfiniteQuery } from '@tanstack/react-query';
import { instrumentsApi } from '@/api';
import { InstrumentCategory } from '@/types';

// Query keys
export const instrumentKeys = {
  all: ['instruments'] as const,
  lists: () => [...instrumentKeys.all, 'list'] as const,
  list: (filters: { query?: string; category?: InstrumentCategory }) =>
    [...instrumentKeys.lists(), filters] as const,
  details: () => [...instrumentKeys.all, 'detail'] as const,
  detail: (id: string) => [...instrumentKeys.details(), id] as const,
  search: (query: string) => [...instrumentKeys.all, 'search', query] as const,
};

// Fetch single instrument
export function useInstrument(id: string) {
  return useQuery({
    queryKey: instrumentKeys.detail(id),
    queryFn: () => instrumentsApi.getInstrument(id),
    enabled: !!id,
    staleTime: 1000 * 60 * 5, // 5 minutes
  });
}

// Fetch instruments list with infinite scroll
export function useInstruments(filters?: { query?: string; category?: InstrumentCategory }) {
  return useInfiniteQuery({
    queryKey: instrumentKeys.list(filters || {}),
    queryFn: ({ pageParam = 1 }) =>
      instrumentsApi.getInstruments({
        page: pageParam,
        limit: 20,
        query: filters?.query,
        category: filters?.category,
      }),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => {
      if (lastPage.page < lastPage.pages) {
        return lastPage.page + 1;
      }
      return undefined;
    },
    staleTime: 1000 * 60 * 2, // 2 minutes
  });
}

// Search instruments (for autocomplete)
export function useInstrumentSearch(query: string) {
  return useQuery({
    queryKey: instrumentKeys.search(query),
    queryFn: () => instrumentsApi.searchInstruments(query, 10),
    enabled: query.length >= 2,
    staleTime: 1000 * 60, // 1 minute
  });
}
