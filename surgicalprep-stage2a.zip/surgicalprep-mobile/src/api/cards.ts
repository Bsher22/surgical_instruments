import { apiClient } from './client';
import { PreferenceCard, PreferenceCardCreate, PreferenceCardUpdate, PaginatedResponse } from '../types';

interface GetCardsParams {
  page?: number;
  limit?: number;
  search?: string;
  specialty?: string;
}

export const cardsApi = {
  getCards: async (params: GetCardsParams = {}): Promise<PaginatedResponse<PreferenceCard>> => {
    const queryParams = new URLSearchParams();
    if (params.page) queryParams.append('page', params.page.toString());
    if (params.limit) queryParams.append('limit', params.limit.toString());
    if (params.search) queryParams.append('search', params.search);
    if (params.specialty) queryParams.append('specialty', params.specialty);
    
    const query = queryParams.toString();
    return apiClient.get(`/cards${query ? `?${query}` : ''}`);
  },

  getCard: async (id: string): Promise<PreferenceCard> => {
    return apiClient.get(`/cards/${id}`);
  },

  createCard: async (data: PreferenceCardCreate): Promise<PreferenceCard> => {
    return apiClient.post('/cards', data);
  },

  updateCard: async (id: string, data: PreferenceCardUpdate): Promise<PreferenceCard> => {
    return apiClient.put(`/cards/${id}`, data);
  },

  deleteCard: async (id: string): Promise<void> => {
    return apiClient.delete(`/cards/${id}`);
  },

  duplicateCard: async (id: string): Promise<PreferenceCard> => {
    return apiClient.post(`/cards/${id}/duplicate`);
  },

  getTemplates: async (): Promise<PreferenceCard[]> => {
    return apiClient.get('/cards/templates');
  },
};
