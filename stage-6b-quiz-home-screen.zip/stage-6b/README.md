# Stage 6B: Quiz Home Screen

## Overview

This stage implements the Quiz Home Screen - the central hub for the study/quiz system in SurgicalPrep. It provides users with their study statistics, quick access to different quiz modes, and a history of recent quiz sessions.

## Files Included

```
stage-6b/
├── app/
│   └── (tabs)/
│       └── quiz/
│           ├── _layout.tsx          # Quiz tab navigation layout
│           ├── index.tsx            # Quiz Home Screen (main implementation)
│           ├── flashcards.tsx       # Placeholder for Stage 6C
│           ├── session.tsx          # Placeholder for Stage 6D
│           ├── results.tsx          # Placeholder for Stage 6D
│           └── history.tsx          # Full quiz history screen
└── src/
    ├── api/
    │   └── quiz.ts                  # Quiz API client functions
    ├── components/
    │   └── quiz/
    │       ├── index.ts             # Barrel export
    │       ├── StatsDashboard.tsx   # Study statistics display
    │       ├── QuickActionButtons.tsx # Quick start actions
    │       ├── CategorySelectModal.tsx # Category filter modal
    │       ├── QuizHistoryList.tsx  # Quiz history list component
    │       └── FreeTierLimitBanner.tsx # Free tier limit indicator
    ├── hooks/
    │   └── useQuiz.ts               # React Query hooks for quiz
    ├── stores/
    │   └── quizStore.ts             # Zustand store for quiz state
    ├── types/
    │   └── quiz.ts                  # TypeScript type definitions
    └── utils/
        └── theme.ts                 # Theme configuration & constants
```

## Features Implemented

### 1. Stats Dashboard
- Instruments studied count with progress bar
- Average quiz score (circular progress indicator)
- Study streak counter
- Due for review count
- Total quizzes taken
- Overall accuracy percentage
- Motivational messages based on performance

### 2. Quick Action Buttons
- **Review Due**: Start a flashcard session with instruments due for spaced repetition review
- **Quick 10**: Instantly start a 10-card flashcard session
- **Full Quiz**: Open category selection for a customized quiz

### 3. Category Selection Modal
- Multi-select categories for targeted study
- Select all / Clear all buttons
- Instrument count per category
- Total instruments indicator

### 4. Quiz History List
- Recent quiz sessions with scores
- Quiz type indicators (Flashcard, Multiple Choice, Mixed)
- Status badges (Completed, In Progress, Abandoned)
- Relative timestamps
- View all history option

### 5. Free Tier Limit Banner
- Daily quiz limit progress bar
- Remaining quizzes indicator
- Prominent banner when limit reached
- Upgrade to Premium CTA
- Premium benefits list

## Integration Instructions

### 1. Install Dependencies

```bash
cd mobile
npm install date-fns expo-linear-gradient
```

### 2. Copy Files

Copy the contents of this package to your mobile app:

```bash
# Copy app screens
cp -r stage-6b/app/(tabs)/quiz/* mobile/app/(tabs)/quiz/

# Copy source files
cp -r stage-6b/src/* mobile/src/
```

### 3. Update Existing Files

If you have an existing `src/types/index.ts`, add the quiz exports:

```typescript
export * from './quiz';
```

If you have an existing `src/api/index.ts`, add:

```typescript
export * from './quiz';
```

### 4. Ensure API Client Exists

The quiz API functions expect an `apiClient` from `./client`. Make sure you have:

```typescript
// src/api/client.ts
import axios from 'axios';
import * as SecureStore from 'expo-secure-store';

const API_BASE_URL = process.env.EXPO_PUBLIC_API_URL || 'http://localhost:8000';

export const apiClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add auth interceptor
apiClient.interceptors.request.use(async (config) => {
  const token = await SecureStore.getItemAsync('access_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});
```

### 5. Add Tab Navigation

If not already present, add the Quiz tab to your tab navigator:

```typescript
// app/(tabs)/_layout.tsx
<Tabs.Screen
  name="quiz"
  options={{
    title: 'Study',
    tabBarIcon: ({ color, size }) => (
      <Ionicons name="school-outline" size={size} color={color} />
    ),
  }}
/>
```

## API Endpoints Required

The following backend endpoints are expected:

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/v1/quiz/stats` | GET | Get study statistics and quiz limits |
| `/api/v1/quiz/limit` | GET | Get current quiz limit status |
| `/api/v1/quiz/due-for-review` | GET | Get instruments due for review |
| `/api/v1/quiz/history` | GET | Get paginated quiz history |
| `/api/v1/instruments/categories` | GET | Get instrument categories |
| `/api/v1/quiz/sessions` | POST | Start a new quiz session |
| `/api/v1/quiz/review/start` | POST | Start a review session |

## State Management

### Quiz Store (Zustand)

The store manages:
- Quiz configuration (type, question count, timer settings)
- Selected categories
- Active session state
- Flashcard session state
- UI modal visibility
- User preferences (persisted)

### React Query

Hooks provided:
- `useStudyStats()` - Fetch study statistics
- `useQuizLimit()` - Fetch quiz limits
- `useDueForReview()` - Fetch due instruments
- `useQuizHistory()` - Fetch quiz history
- `useInfiniteQuizHistory()` - Infinite scroll history
- `useCategories()` - Fetch categories
- `useStartQuizSession()` - Start quiz mutation
- `useStartReviewSession()` - Start review mutation

## Styling

Theme constants are provided in `src/utils/theme.ts`:
- Color palette (light mode with dark mode ready)
- Spacing scale
- Typography settings
- Border radius values
- Shadow presets
- Helper functions

## Next Steps

After integrating Stage 6B, proceed to:
- **Stage 6C**: Flashcard Mode (swipeable cards, flip animations)
- **Stage 6D**: Multiple Choice Quiz (questions, timer, results)
- **Stage 6E**: Study Progress & Bookmarks

## Notes

- Placeholder screens are provided for flashcards, session, and results
- The free tier limit is enforced client-side (backend should also enforce)
- Haptic feedback is included for key interactions
- Pull-to-refresh is implemented on the home screen
- The category modal uses virtualized list for performance
