// ============================================
// SurgicalPrep - Instrument Hooks
// React Query hooks for instruments
// ============================================

import { useQuery, useMutation, useQueryClient, useInfiniteQuery } from '@tanstack/react-query';
import { instrumentsApi } from '../api/instruments';
import { queryKeys } from '../providers/QueryProvider';
import type { InstrumentListParams, InstrumentCategory } from '../types';
import { DEFAULT_PAGE_SIZE } from '../utils/constants';

/**
 * Hook to fetch paginated list of instruments
 */
export function useInstruments(params: InstrumentListParams = {}) {
  return useQuery({
    queryKey: queryKeys.instruments.list(params),
    queryFn: () => instrumentsApi.getInstruments({
      page: 1,
      limit: DEFAULT_PAGE_SIZE,
      ...params,
    }),
  });
}

/**
 * Hook for infinite scroll instrument list
 */
export function useInfiniteInstruments(params: Omit<InstrumentListParams, 'page'> = {}) {
  return useInfiniteQuery({
    queryKey: queryKeys.instruments.list({ ...params, infinite: true }),
    queryFn: ({ pageParam = 1 }) => instrumentsApi.getInstruments({
      ...params,
      page: pageParam,
      limit: DEFAULT_PAGE_SIZE,
    }),
    initialPageParam: 1,
    getNextPageParam: (lastPage) => lastPage.has_next ? lastPage.page + 1 : undefined,
  });
}

/**
 * Hook to fetch single instrument by ID
 */
export function useInstrument(id: string | undefined) {
  return useQuery({
    queryKey: queryKeys.instruments.detail(id!),
    queryFn: () => instrumentsApi.getInstrument(id!),
    enabled: !!id,
  });
}

/**
 * Hook for full-text search
 */
export function useInstrumentSearch(query: string, limit: number = 10) {
  return useQuery({
    queryKey: queryKeys.instruments.search(query),
    queryFn: () => instrumentsApi.searchInstruments({ query, limit }),
    enabled: query.length >= 2, // Only search with 2+ characters
    staleTime: 1000 * 60, // 1 minute for search results
  });
}

/**
 * Hook to get instruments by category
 */
export function useInstrumentsByCategory(category: InstrumentCategory, params: Omit<InstrumentListParams, 'category'> = {}) {
  return useQuery({
    queryKey: queryKeys.instruments.list({ category, ...params }),
    queryFn: () => instrumentsApi.getByCategory(category, params),
  });
}

/**
 * Hook to get category counts
 */
export function useInstrumentCategories() {
  return useQuery({
    queryKey: queryKeys.instruments.categories(),
    queryFn: () => instrumentsApi.getCategories(),
    staleTime: 1000 * 60 * 30, // Categories don't change often, cache for 30 min
  });
}

/**
 * Hook to get bookmarked instruments
 */
export function useBookmarkedInstruments(params: Omit<InstrumentListParams, 'category'> = {}) {
  return useQuery({
    queryKey: queryKeys.instruments.bookmarked(params),
    queryFn: () => instrumentsApi.getBookmarked(params),
  });
}

/**
 * Hook to toggle bookmark
 */
export function useToggleBookmark() {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (instrumentId: string) => instrumentsApi.toggleBookmark(instrumentId),
    onSuccess: (_, instrumentId) => {
      // Invalidate bookmarked list
      queryClient.invalidateQueries({ queryKey: queryKeys.instruments.bookmarked() });
      
      // Optionally update the specific instrument in cache
      queryClient.invalidateQueries({ queryKey: queryKeys.instruments.detail(instrumentId) });
    },
  });
}

/**
 * Hook to prefetch instrument detail
 */
export function usePrefetchInstrument() {
  const queryClient = useQueryClient();

  return (id: string) => {
    queryClient.prefetchQuery({
      queryKey: queryKeys.instruments.detail(id),
      queryFn: () => instrumentsApi.getInstrument(id),
    });
  };
}
