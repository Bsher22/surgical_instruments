# Stage 5A: Card Form State Management - Outline

## Overview

Stage 5A establishes the state management foundation for preference card creation and editing. This includes a Zustand store for form state, automatic draft saving to AsyncStorage, and unsaved changes tracking to prevent data loss.

---

## Components to Build

### 1. TypeScript Types (`src/types/cardForm.ts`)

**CardFormData** - The shape of the form state:
- `id?: string` - Card ID (undefined for new cards)
- `title: string` - Card title (required)
- `surgeonName: string` - Surgeon name
- `procedureName: string` - Procedure name
- `specialty: Specialty | null` - Selected specialty
- `generalNotes: string` - General notes textarea
- `setupNotes: string` - Setup notes textarea
- `items: CardFormItem[]` - Array of items on the card
- `photos: CardFormPhoto[]` - Array of photos

**CardFormItem** - Individual item in the card:
- `id: string` - Unique ID (UUID for new, actual ID for existing)
- `instrumentId?: string` - Linked instrument ID (optional)
- `name: string` - Item name
- `quantity: number` - Quantity needed
- `size?: string` - Size specification
- `notes?: string` - Item-specific notes
- `category: ItemCategory` - Category enum
- `isCustom: boolean` - Whether manually entered
- `order: number` - Display order

**CardFormPhoto** - Photo metadata:
- `id: string` - Unique ID
- `uri: string` - Local URI or remote URL
- `isNew: boolean` - Whether newly added
- `isDeleted: boolean` - Marked for deletion

**ItemCategory** - Enum for item categorization:
- `INSTRUMENT`, `SUPPLY`, `SUTURE`, `IMPLANT`, `SPECIAL`, `OTHER`

**FormValidationErrors** - Validation error tracking:
- `title?: string` - Title validation error
- `items?: string` - Items validation error

---

### 2. Zustand Store (`src/stores/cardFormStore.ts`)

**State Properties:**
- `formData: CardFormData` - Current form state
- `originalData: CardFormData | null` - Original data for change detection
- `isDirty: boolean` - Whether form has unsaved changes
- `isLoading: boolean` - Loading state
- `isSaving: boolean` - Save in progress
- `lastSavedAt: Date | null` - Last auto-save timestamp
- `validationErrors: FormValidationErrors` - Current validation errors
- `draftKey: string | null` - AsyncStorage key for current draft

**Actions:**
- `initializeNewCard()` - Reset to blank form for new card
- `initializeFromCard(card: PreferenceCard)` - Load existing card for editing
- `initializeFromDraft(draftKey: string)` - Restore from saved draft
- `updateField(field, value)` - Update a single form field
- `addItem(item: Partial<CardFormItem>)` - Add item to card
- `updateItem(itemId: string, updates)` - Update existing item
- `removeItem(itemId: string)` - Remove item from card
- `reorderItems(fromIndex: number, toIndex: number)` - Reorder items
- `addPhoto(photo: CardFormPhoto)` - Add photo
- `removePhoto(photoId: string)` - Mark photo for deletion
- `validate(): boolean` - Run validation, return success
- `saveDraft()` - Save current state to AsyncStorage
- `clearDraft()` - Remove draft from AsyncStorage
- `reset()` - Clear all form state
- `markAsSaved()` - Update originalData, clear dirty flag

**Computed/Derived:**
- `hasUnsavedChanges` - Compare formData to originalData
- `isValid` - No validation errors and required fields present

---

### 3. Auto-Save Hook (`src/hooks/useCardFormAutoSave.ts`)

**Functionality:**
- Debounced auto-save (2 second delay after last change)
- Saves to AsyncStorage with unique key per card
- Handles both new cards and edits
- Clears draft on successful save to server
- Provides `lastSavedAt` for UI feedback

**Draft Key Format:**
- New card: `card_draft_new`
- Editing: `card_draft_${cardId}`

---

### 4. Unsaved Changes Guard Hook (`src/hooks/useUnsavedChangesGuard.ts`)

**Functionality:**
- Detects navigation attempts when form is dirty
- Shows confirmation alert before discarding changes
- Integrates with Expo Router navigation
- Provides `canNavigate` and `confirmDiscard` methods

---

### 5. Draft Recovery Hook (`src/hooks/useCardDraftRecovery.ts`)

**Functionality:**
- Checks for existing drafts on mount
- Prompts user to restore or discard
- Handles draft conflicts (editing same card twice)
- Cleans up stale drafts

---

### 6. Utility Functions (`src/utils/cardFormUtils.ts`)

**Functions:**
- `createEmptyFormData(): CardFormData` - Default blank form
- `cardToFormData(card: PreferenceCard): CardFormData` - Convert API model to form
- `formDataToCreateRequest(data: CardFormData): CreateCardRequest` - Prepare for API
- `formDataToUpdateRequest(data: CardFormData): UpdateCardRequest` - Prepare for API
- `generateItemId(): string` - Generate unique item IDs
- `deepCompare(a: CardFormData, b: CardFormData): boolean` - Compare for dirty detection
- `validateFormData(data: CardFormData): FormValidationErrors` - Validation logic

---

## File Structure

```
src/
├── types/
│   └── cardForm.ts              # Form-specific types
├── stores/
│   └── cardFormStore.ts         # Zustand store
├── hooks/
│   ├── useCardFormAutoSave.ts   # Auto-save hook
│   ├── useUnsavedChangesGuard.ts # Navigation guard
│   └── useCardDraftRecovery.ts  # Draft restoration
└── utils/
    └── cardFormUtils.ts         # Form utilities
```

---

## Integration Points

### With Existing Code:
- Uses `PreferenceCard` type from `src/types/index.ts`
- Uses `Specialty` enum from existing types
- Integrates with React Query for server sync
- Uses Expo Router for navigation guards

### With Future Stages:
- **Stage 5B** (Basic Info Form) - Consumes store state
- **Stage 5C** (Item Management) - Uses item CRUD actions
- **Stage 5D** (Photo Upload) - Uses photo actions
- **Stage 5E** (Card Operations) - Uses save/validation

---

## Key Design Decisions

### 1. Zustand over Context
- Simpler API with less boilerplate
- Built-in performance optimizations
- Easy persistence middleware integration
- Works well with React Query

### 2. Separate Form Types
- `CardFormData` differs from API `PreferenceCard`
- Form state includes UI-specific fields (isNew, isDeleted, order)
- Enables optimistic updates and offline editing

### 3. Draft Key Strategy
- Single draft per card (overwrites on edit)
- Separate key for new cards
- Prevents draft collision issues

### 4. Debounced Auto-Save
- 2 second delay balances UX and storage writes
- Saves on blur events for immediate feedback
- Clears timeout on component unmount

### 5. Deep Comparison for Dirty State
- Accurate change detection
- Ignores order changes in array comparison
- Handles nested object comparison

---

## Testing Considerations

- Test store actions in isolation
- Mock AsyncStorage for hook tests
- Test navigation guard with mock router
- Verify draft recovery flow
- Test validation edge cases

---

## Dependencies

**New packages needed:**
- `@react-native-async-storage/async-storage` - Persistent storage
- `lodash.debounce` or custom implementation
- `lodash.isequal` for deep comparison (or custom)

**Already installed (from Stage 2):**
- `zustand` - State management
- `expo-router` - Navigation

---

## Implementation Order

1. **Types** (`cardForm.ts`) - Foundation for everything
2. **Utilities** (`cardFormUtils.ts`) - Helper functions
3. **Store** (`cardFormStore.ts`) - Core state management
4. **Auto-Save Hook** - Draft persistence
5. **Unsaved Changes Guard** - Navigation safety
6. **Draft Recovery Hook** - User experience polish

---

## Usage Example

```typescript
// In CardEditScreen.tsx
import { useCardFormStore } from '@/stores/cardFormStore';
import { useCardFormAutoSave } from '@/hooks/useCardFormAutoSave';
import { useUnsavedChangesGuard } from '@/hooks/useUnsavedChangesGuard';

function CardEditScreen() {
  const { formData, updateField, isDirty, validate } = useCardFormStore();
  
  // Enable auto-save
  useCardFormAutoSave();
  
  // Protect against navigation
  useUnsavedChangesGuard();
  
  const handleSave = async () => {
    if (!validate()) return;
    // Submit to API...
  };
  
  return (
    <View>
      <TextInput
        value={formData.title}
        onChangeText={(text) => updateField('title', text)}
      />
      {/* ... */}
    </View>
  );
}
```
