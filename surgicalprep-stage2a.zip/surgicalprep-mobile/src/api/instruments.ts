import { apiClient } from './client';
import { Instrument, PaginatedResponse } from '../types';

interface GetInstrumentsParams {
  page?: number;
  limit?: number;
  search?: string;
  category?: string;
}

export const instrumentsApi = {
  getInstruments: async (params: GetInstrumentsParams = {}): Promise<PaginatedResponse<Instrument>> => {
    const queryParams = new URLSearchParams();
    if (params.page) queryParams.append('page', params.page.toString());
    if (params.limit) queryParams.append('limit', params.limit.toString());
    if (params.search) queryParams.append('search', params.search);
    if (params.category) queryParams.append('category', params.category);
    
    const query = queryParams.toString();
    return apiClient.get(`/instruments${query ? `?${query}` : ''}`);
  },

  getInstrument: async (id: string): Promise<Instrument> => {
    return apiClient.get(`/instruments/${id}`);
  },

  searchInstruments: async (query: string): Promise<Instrument[]> => {
    return apiClient.get(`/instruments/search?q=${encodeURIComponent(query)}`);
  },

  bookmarkInstrument: async (id: string): Promise<void> => {
    return apiClient.post(`/instruments/${id}/bookmark`);
  },

  unbookmarkInstrument: async (id: string): Promise<void> => {
    return apiClient.delete(`/instruments/${id}/bookmark`);
  },
};
