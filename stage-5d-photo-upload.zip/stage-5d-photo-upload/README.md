# Stage 5D: Photo Upload

Complete photo upload functionality for SurgicalPrep preference cards.

## Features

- 📸 **Camera capture** - Take photos directly from the app
- 🖼️ **Gallery selection** - Pick single or multiple photos from device
- 📤 **Background upload** - Photos upload while you continue working
- 📊 **Progress tracking** - Visual feedback for upload progress
- 🔄 **Retry failed uploads** - Easily retry if something goes wrong
- ❌ **Delete photos** - Remove unwanted photos with confirmation
- 🗜️ **Auto compression** - Images compressed for optimal storage
- 📱 **Permission handling** - Graceful handling of camera/gallery permissions

## Installation

### 1. Install Dependencies

```bash
# If not already installed from Stage 1
npx expo install expo-image-picker

# Additional dependencies for Stage 5D
npx expo install expo-file-system expo-image-manipulator expo-haptics
```

### 2. Copy Files

Copy the following directories to your project:

```
src/
├── api/
│   ├── storage.ts        # Supabase Storage operations
│   └── supabase.ts       # Supabase client (if not exists)
├── components/
│   └── photos/
│       ├── index.ts
│       ├── PhotoUploader.tsx
│       ├── PhotoPreviewGrid.tsx
│       ├── PhotoPreviewItem.tsx
│       └── PhotoSourceModal.tsx
├── hooks/
│   ├── index.ts
│   ├── usePhotoUpload.ts
│   ├── useImagePicker.ts
│   └── usePhotoDelete.ts
├── types/
│   └── photo.ts
└── utils/
    ├── constants.ts
    ├── imageUtils.ts
    └── fileUtils.ts
```

### 3. Configure Supabase Storage

Create a storage bucket in your Supabase project:

1. Go to Supabase Dashboard → Storage
2. Create a new bucket named `card-photos`
3. Set the bucket to **Public** (for simplicity) or configure RLS
4. Add a storage policy for authenticated users:

```sql
-- Allow authenticated users to upload to their own folder
CREATE POLICY "Users can upload to own folder"
ON storage.objects
FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'card-photos' AND
  (storage.foldername(name))[1] = 'cards' AND
  (storage.foldername(name))[2] = auth.uid()::text
);

-- Allow authenticated users to delete from their own folder
CREATE POLICY "Users can delete own files"
ON storage.objects
FOR DELETE
TO authenticated
USING (
  bucket_id = 'card-photos' AND
  (storage.foldername(name))[1] = 'cards' AND
  (storage.foldername(name))[2] = auth.uid()::text
);

-- Allow public read access
CREATE POLICY "Public read access"
ON storage.objects
FOR SELECT
TO public
USING (bucket_id = 'card-photos');
```

### 4. Add Environment Variables

Make sure these are in your `.env`:

```
EXPO_PUBLIC_SUPABASE_URL=your-supabase-url
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 5. Configure app.json (iOS Camera/Photo Permissions)

```json
{
  "expo": {
    "plugins": [
      [
        "expo-image-picker",
        {
          "photosPermission": "The app accesses your photos to add setup images to your preference cards.",
          "cameraPermission": "The app accesses your camera to take photos of surgical setups."
        }
      ]
    ]
  }
}
```

## Usage

### Basic Usage in Card Edit Screen

```tsx
import { PhotoUploader, Photo, urlsToPhotos, photosToUrls } from '@/components/photos';

function CardEditScreen({ card }) {
  // Convert existing URLs to Photo objects
  const [photos, setPhotos] = useState<Photo[]>(() => 
    urlsToPhotos(card?.setup_photos || [])
  );
  
  const handleSave = async () => {
    // Convert back to URLs for API
    const photoUrls = photosToUrls(photos);
    await updateCard({ ...cardData, setup_photos: photoUrls });
  };
  
  return (
    <ScrollView>
      {/* Other form fields... */}
      
      <PhotoUploader
        photos={photos}
        onPhotosChange={setPhotos}
        cardId={card?.id}
        userId={user.id}
        maxPhotos={10}
      />
      
      <Button onPress={handleSave}>Save Card</Button>
    </ScrollView>
  );
}
```

### Using the Upload Hook Directly

```tsx
import { usePhotoUpload } from '@/hooks/usePhotoUpload';

function MyComponent() {
  const {
    photos,
    isUploading,
    uploadProgress,
    openCamera,
    openGallery,
    removePhoto,
    retryFailedUploads,
    canAddMore,
  } = usePhotoUpload({
    cardId: 'card-123',
    userId: 'user-456',
    maxPhotos: 5,
  });
  
  return (
    <View>
      <Button onPress={openCamera} disabled={!canAddMore}>
        Take Photo
      </Button>
      <Button onPress={openGallery} disabled={!canAddMore}>
        Choose from Gallery
      </Button>
      
      {isUploading && <Text>Uploading... {uploadProgress}%</Text>}
      
      {photos.map(photo => (
        <PhotoItem
          key={photo.id}
          photo={photo}
          onDelete={() => removePhoto(photo.id)}
        />
      ))}
    </View>
  );
}
```

## Configuration

Adjust defaults in `src/utils/constants.ts`:

```typescript
export const PHOTO_CONFIG = {
  maxPhotosPerCard: 10,      // Max photos per card
  maxFileSizeMB: 5,          // Max file size before compression
  compressionQuality: 0.8,   // JPEG quality (0-1)
  targetWidth: 1200,         // Max image width
  targetHeight: 1200,        // Max image height
  concurrentUploads: 2,      // Parallel upload count
  storageBucket: 'card-photos', // Supabase bucket name
};
```

## Component Props

### PhotoUploader

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `photos` | `Photo[]` | - | Controlled photos array |
| `onPhotosChange` | `(photos: Photo[]) => void` | - | Callback when photos change |
| `initialUrls` | `string[]` | - | Initial photo URLs (uncontrolled mode) |
| `cardId` | `string` | - | Card ID for storage path |
| `userId` | `string` | - | User ID for storage path |
| `maxPhotos` | `number` | `10` | Maximum photos allowed |
| `disabled` | `boolean` | `false` | Disable all interactions |
| `showHeader` | `boolean` | `true` | Show section header |
| `headerTitle` | `string` | `'Setup Photos'` | Header title text |

### PhotoPreviewGrid

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| `photos` | `Photo[]` | - | Photos to display |
| `onDelete` | `(id: string) => void` | - | Delete callback |
| `onPhotoPress` | `(photo: Photo) => void` | - | Photo tap callback |
| `columns` | `number` | `3` | Grid columns |
| `spacing` | `number` | `8` | Item spacing |

## File Structure

```
Stage 5D Package
├── STAGE_5D_OUTLINE.md     # Detailed implementation outline
├── README.md               # This file
├── src/
│   ├── api/
│   │   ├── storage.ts      # Supabase Storage operations
│   │   └── supabase.ts     # Supabase client reference
│   ├── components/
│   │   └── photos/
│   │       ├── index.ts    # Barrel exports
│   │       ├── PhotoUploader.tsx
│   │       ├── PhotoPreviewGrid.tsx
│   │       ├── PhotoPreviewItem.tsx
│   │       └── PhotoSourceModal.tsx
│   ├── hooks/
│   │   ├── index.ts
│   │   ├── usePhotoUpload.ts
│   │   ├── useImagePicker.ts
│   │   └── usePhotoDelete.ts
│   ├── types/
│   │   └── photo.ts
│   └── utils/
│       ├── constants.ts
│       ├── imageUtils.ts
│       └── fileUtils.ts
└── examples/
    └── CardEditScreen-PhotoIntegration.tsx
```

## Testing Checklist

- [ ] Camera capture works on iOS
- [ ] Camera capture works on Android
- [ ] Gallery single selection works
- [ ] Gallery multiple selection works
- [ ] Permission denied shows settings prompt
- [ ] Photos appear immediately after selection
- [ ] Upload progress indicator shows
- [ ] Successful upload updates photo URL
- [ ] Failed upload shows error state
- [ ] Retry button works for failed uploads
- [ ] Delete removes photo from grid
- [ ] Max photos limit enforced
- [ ] Large images compressed before upload
- [ ] Photos persist after save/reload

## Troubleshooting

### Camera not opening
- Check camera permissions in device settings
- Ensure `expo-image-picker` plugin is in app.json
- Rebuild the app after adding permissions

### Upload failures
- Verify Supabase storage bucket exists
- Check storage policies allow uploads
- Ensure EXPO_PUBLIC_SUPABASE_URL is correct
- Check network connectivity

### Images not displaying
- Verify storage bucket is public or RLS allows read
- Check that URLs are correctly formatted
- Try clearing app cache

## Next Steps

After completing Stage 5D, proceed to:
- **Stage 5E**: Card Operations (save, delete, duplicate with photos)
- **Stage 6**: Quiz & Study System
