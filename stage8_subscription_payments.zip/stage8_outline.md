# Stage 8: Subscription & Payments - Implementation Outline

## Overview

Stage 8 implements the premium subscription system using Stripe for payment processing. This enables monetization through tiered access control, with a free tier offering limited functionality and a premium tier unlocking full app capabilities.

---

## Architecture

### Payment Flow

```
┌─────────────────────────────────────────────────────────────────────────┐
│                           SUBSCRIPTION FLOW                              │
├─────────────────────────────────────────────────────────────────────────┤
│                                                                         │
│  Mobile App                    Backend                    Stripe        │
│  ─────────                     ───────                    ──────        │
│                                                                         │
│  1. User taps "Subscribe"                                               │
│         │                                                               │
│         ▼                                                               │
│  2. POST /api/subscriptions/create-checkout                             │
│         │                                                               │
│         └──────────────────────▶ 3. Create Stripe Checkout Session      │
│                                         │                               │
│                                         └──────────────────────▶        │
│         ◀──────────────────────────────────────────────────────         │
│                                 4. Return checkout URL                  │
│         │                                                               │
│         ▼                                                               │
│  5. Open WebBrowser to Stripe Checkout                                  │
│         │                                                               │
│         └──────────────────────────────────────────────────────▶        │
│                                                                         │
│  6. User completes payment on Stripe                                    │
│                                                                         │
│         ◀──────────────────────────────────────────────────────         │
│  7. Redirect back to app (success/cancel URL)                           │
│                                                                         │
│                                         ◀──────────────────────         │
│                                 8. Webhook: checkout.session.completed  │
│                                         │                               │
│                                         ▼                               │
│                                 9. Update user.subscription_tier        │
│                                    Store customer_id, subscription_id   │
│                                                                         │
│  10. App refreshes user data                                            │
│         │                                                               │
│         ▼                                                               │
│  11. Premium features unlocked                                          │
│                                                                         │
└─────────────────────────────────────────────────────────────────────────┘
```

### Tier System

| Feature | Free Tier | Premium Tier |
|---------|-----------|--------------|
| Preference Cards | 5 max | Unlimited |
| Daily Quizzes | 3/day | Unlimited |
| Instrument Details | Basic only | Full details |
| Flashcard Sessions | 10/day | Unlimited |
| Ad-Free Experience | No | Yes |

### Pricing

- **Monthly**: $4.99/month
- **Annual**: $29.99/year (50% savings)

---

## Backend Implementation

### 8A: Stripe Configuration

#### Environment Variables

```bash
# .env additions
STRIPE_SECRET_KEY=sk_test_...
STRIPE_PUBLISHABLE_KEY=pk_test_...
STRIPE_WEBHOOK_SECRET=whsec_...
STRIPE_MONTHLY_PRICE_ID=price_...
STRIPE_ANNUAL_PRICE_ID=price_...
FRONTEND_URL=surgicalprep://
```

#### Database Schema Updates

```sql
-- Add to users table
ALTER TABLE users ADD COLUMN stripe_customer_id VARCHAR(255);
ALTER TABLE users ADD COLUMN stripe_subscription_id VARCHAR(255);
ALTER TABLE users ADD COLUMN subscription_expires_at TIMESTAMPTZ;
ALTER TABLE users ADD COLUMN subscription_status VARCHAR(50) DEFAULT 'inactive';

-- Create subscription history table
CREATE TABLE subscription_events (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    event_type VARCHAR(100) NOT NULL,
    stripe_event_id VARCHAR(255),
    data JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE INDEX idx_subscription_events_user_id ON subscription_events(user_id);
CREATE INDEX idx_subscription_events_stripe_event_id ON subscription_events(stripe_event_id);
```

#### New Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/subscriptions/create-checkout` | Create Stripe checkout session |
| POST | `/api/subscriptions/webhook` | Handle Stripe webhooks |
| GET | `/api/subscriptions/status` | Get current subscription status |
| POST | `/api/subscriptions/portal` | Create customer portal session |
| POST | `/api/subscriptions/restore` | Restore purchases (verify with Stripe) |

#### Webhook Events to Handle

1. `checkout.session.completed` - Initial subscription
2. `customer.subscription.updated` - Plan changes
3. `customer.subscription.deleted` - Cancellation
4. `invoice.payment_succeeded` - Renewal
5. `invoice.payment_failed` - Failed payment

### 8B: Backend Files Structure

```
backend/
├── app/
│   ├── api/
│   │   └── endpoints/
│   │       └── subscriptions.py    # New endpoints
│   ├── core/
│   │   └── stripe_config.py        # Stripe initialization
│   ├── schemas/
│   │   └── subscription.py         # Pydantic models
│   ├── services/
│   │   └── subscription_service.py # Business logic
│   └── db/
│       └── models.py               # Updated User model
```

---

## Frontend Implementation

### 8B: Paywall Screen

The paywall screen presents premium benefits and pricing options to users.

#### Components

1. **PaywallScreen** - Main subscription screen
   - Benefits list with icons
   - Pricing toggle (monthly/annual)
   - Subscribe buttons
   - Restore purchases link
   - Terms and privacy links

2. **PricingCard** - Individual plan display
   - Price display
   - Billing period
   - Savings badge (for annual)
   - CTA button

3. **BenefitItem** - Single benefit row
   - Icon
   - Title
   - Description

#### User Flow

```
┌────────────────────────────────────────┐
│            Upgrade to Premium           │
├────────────────────────────────────────┤
│                                        │
│  ✓ Unlimited Preference Cards          │
│  ✓ Unlimited Daily Quizzes             │
│  ✓ Full Instrument Details             │
│  ✓ Unlimited Flashcard Sessions        │
│  ✓ Ad-Free Experience                  │
│                                        │
├────────────────────────────────────────┤
│                                        │
│    [Monthly]     [Annual - Save 50%]   │
│                                        │
│  ┌──────────────────────────────────┐  │
│  │         $29.99/year              │  │
│  │    Just $2.50/month billed       │  │
│  │          annually                │  │
│  │                                  │  │
│  │    [  Subscribe Now  ]           │  │
│  └──────────────────────────────────┘  │
│                                        │
│         Restore Purchases              │
│                                        │
│    Terms of Service | Privacy Policy   │
│                                        │
└────────────────────────────────────────┘
```

### 8C: Premium Gating

#### PremiumGate Component

A wrapper component that conditionally renders content based on subscription status.

```tsx
// Usage examples
<PremiumGate feature="unlimited_cards">
  <CreateCardButton />
</PremiumGate>

<PremiumGate 
  feature="full_instrument_details"
  fallback={<LockedOverlay />}
>
  <InstrumentDetails instrument={instrument} />
</PremiumGate>
```

#### Feature Limits

```typescript
const FREE_TIER_LIMITS = {
  maxCards: 5,
  dailyQuizzes: 3,
  dailyFlashcards: 10,
  showFullInstrumentDetails: false,
};

const PREMIUM_FEATURES = [
  'unlimited_cards',
  'unlimited_quizzes',
  'unlimited_flashcards',
  'full_instrument_details',
  'ad_free',
];
```

#### Locked Content Overlay

For gated content, display a blur overlay with upgrade CTA:

```
┌────────────────────────────────────┐
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░  ┌──────────────────┐ ░░░░  │
│  ░░░░░  │  🔒 Premium Only │ ░░░░  │
│  ░░░░░  │                  │ ░░░░  │
│  ░░░░░  │ [Upgrade Now]    │ ░░░░  │
│  ░░░░░  └──────────────────┘ ░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
│  ░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░░  │
└────────────────────────────────────┘
```

### Frontend Files Structure

```
mobile/src/
├── api/
│   └── subscriptions.ts           # API client functions
├── stores/
│   └── subscriptionStore.ts       # Zustand store
├── hooks/
│   ├── useSubscription.ts         # Subscription status hook
│   └── usePremiumFeature.ts       # Feature gating hook
├── components/
│   ├── subscription/
│   │   ├── PaywallScreen.tsx      # Main paywall
│   │   ├── PricingCard.tsx        # Plan card
│   │   ├── BenefitItem.tsx        # Benefit row
│   │   └── PremiumBadge.tsx       # Premium indicator
│   └── premium/
│       ├── PremiumGate.tsx        # Feature gate wrapper
│       ├── LockedOverlay.tsx      # Blur + CTA overlay
│       └── UpgradePrompt.tsx      # Inline upgrade nudge
├── screens/
│   └── subscription/
│       └── PaywallScreen.tsx      # Screen wrapper
└── types/
    └── subscription.ts            # TypeScript types
```

---

## Implementation Steps

### Step 1: Stripe Dashboard Setup

1. Create Stripe account (or use existing)
2. Create Products:
   - "SurgicalPrep Premium Monthly" - $4.99/month recurring
   - "SurgicalPrep Premium Annual" - $29.99/year recurring
3. Note Price IDs for each product
4. Set up webhook endpoint pointing to `/api/subscriptions/webhook`
5. Configure webhook events to send
6. Get API keys (test mode first, then production)

### Step 2: Backend Implementation

1. Install `stripe` Python package
2. Create Stripe configuration module
3. Update User model with subscription fields
4. Create subscription schemas
5. Implement subscription service
6. Create API endpoints
7. Add webhook signature verification
8. Write unit tests

### Step 3: Frontend Implementation

1. Create TypeScript types for subscriptions
2. Build API client functions
3. Create Zustand subscription store
4. Build paywall screen components
5. Implement premium gating components
6. Update existing screens with gates
7. Add subscription status to profile
8. Test complete flow

### Step 4: Integration Testing

1. Test checkout flow (test mode)
2. Test webhook handling
3. Test subscription renewal
4. Test cancellation
5. Test premium feature access
6. Test free tier limits

---

## API Response Handling

### 403 Forbidden (Premium Required)

When a free user tries to access premium content:

```json
{
  "detail": {
    "code": "PREMIUM_REQUIRED",
    "message": "This feature requires a premium subscription",
    "feature": "unlimited_cards",
    "upgrade_url": "/subscription/upgrade"
  }
}
```

### Handling in API Client

```typescript
// In api/client.ts
apiClient.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 403) {
      const detail = error.response.data?.detail;
      if (detail?.code === 'PREMIUM_REQUIRED') {
        // Trigger upgrade modal
        subscriptionStore.getState().showUpgradePrompt(detail.feature);
      }
    }
    return Promise.reject(error);
  }
);
```

---

## Security Considerations

1. **Webhook Verification**: Always verify Stripe webhook signatures
2. **Server-Side Validation**: Never trust client claims about subscription status
3. **Idempotency**: Handle duplicate webhook events gracefully
4. **Error Handling**: Log all subscription events for debugging
5. **Token Security**: Keep Stripe keys in environment variables only

---

## Testing Checklist

### Backend Tests
- [ ] Create checkout session returns valid URL
- [ ] Webhook processes checkout.session.completed
- [ ] Webhook processes subscription.updated
- [ ] Webhook processes subscription.deleted
- [ ] Invalid webhook signature rejected
- [ ] Subscription status endpoint returns correct data
- [ ] Customer portal session creation works

### Frontend Tests
- [ ] Paywall screen renders correctly
- [ ] Pricing toggle switches plans
- [ ] Subscribe button opens browser
- [ ] Deep link returns user to app
- [ ] Premium gate hides content for free users
- [ ] Premium gate shows content for premium users
- [ ] Locked overlay displays correctly
- [ ] Restore purchases flow works

### Integration Tests
- [ ] Full subscription flow (test card)
- [ ] Webhook updates user subscription
- [ ] App reflects subscription status
- [ ] Premium features unlock after subscription
- [ ] Cancellation removes access appropriately

---

## Stripe Test Cards

| Card Number | Result |
|-------------|--------|
| 4242 4242 4242 4242 | Success |
| 4000 0000 0000 0002 | Declined |
| 4000 0000 0000 3220 | 3D Secure required |

Use any future expiry date and any 3-digit CVC.

---

## Files Included in This Package

### Backend
- `app/api/endpoints/subscriptions.py` - API routes
- `app/core/stripe_config.py` - Stripe initialization
- `app/schemas/subscription.py` - Pydantic schemas
- `app/services/subscription_service.py` - Business logic
- `app/db/models_subscription.py` - Model updates
- `migrations/add_subscription_fields.sql` - Database migration

### Frontend
- `src/api/subscriptions.ts` - API client
- `src/stores/subscriptionStore.ts` - State management
- `src/hooks/useSubscription.ts` - Subscription hook
- `src/hooks/usePremiumFeature.ts` - Feature gating hook
- `src/types/subscription.ts` - TypeScript types
- `src/components/subscription/PaywallScreen.tsx` - Main paywall
- `src/components/subscription/PricingCard.tsx` - Pricing display
- `src/components/subscription/BenefitItem.tsx` - Benefit row
- `src/components/subscription/PremiumBadge.tsx` - Premium indicator
- `src/components/premium/PremiumGate.tsx` - Feature wrapper
- `src/components/premium/LockedOverlay.tsx` - Lock UI
- `src/components/premium/UpgradePrompt.tsx` - Inline prompt
- `app/(tabs)/profile/subscription.tsx` - Subscription screen
- `src/constants/subscription.ts` - Constants and limits

---

## Next Steps After Implementation

1. **Stage 9**: Populate production content database
2. **Stage 10**: Polish UI and performance optimization
3. **Before Launch**: Switch Stripe to production mode
4. **Post-Launch**: Monitor subscription analytics
