# Stage 5A: Card Form State Management

## Overview

This stage implements the state management foundation for preference card creation and editing. It provides a Zustand store for managing form state, automatic draft saving to AsyncStorage, and unsaved changes protection.

## Features

- **Zustand Store** - Centralized form state with TypeScript support
- **Auto-Save Drafts** - Debounced saving to AsyncStorage
- **Unsaved Changes Guard** - Prevents accidental data loss
- **Draft Recovery** - Restores previous sessions
- **Form Validation** - Comprehensive validation with error tracking
- **Dirty State Detection** - Deep comparison for change detection

## Installation

### 1. Install Dependencies

```bash
# Navigate to your mobile app directory
cd mobile

# Install required packages
npx expo install @react-native-async-storage/async-storage
```

Note: `zustand` and `expo-router` should already be installed from Stage 2.

### 2. Copy Files

Copy the following files to your project:

```
src/
├── types/
│   └── cardForm.ts           # Form-specific TypeScript types
├── stores/
│   └── cardFormStore.ts      # Zustand store
├── hooks/
│   ├── index.ts              # Hook exports
│   ├── useCardFormAutoSave.ts
│   ├── useUnsavedChangesGuard.ts
│   └── useCardDraftRecovery.ts
├── utils/
│   └── cardFormUtils.ts      # Utility functions
└── examples/
    └── CardFormExamples.tsx  # Usage examples (optional)
```

### 3. Update Types Index

Add to `src/types/index.ts`:

```typescript
export * from './cardForm';
```

### 4. Verify Specialty Type

Ensure your `src/types/index.ts` exports a `Specialty` type:

```typescript
export type Specialty =
  | 'general'
  | 'orthopedic'
  | 'cardiovascular'
  | 'neurosurgery'
  | 'ob_gyn'
  | 'urology'
  | 'plastic'
  | 'ent'
  | 'ophthalmology'
  | 'other';
```

## Quick Start

### Creating a New Card

```tsx
import {
  useCardFormStore,
  useCardFormActions,
} from '@/stores/cardFormStore';
import { useCardFormAutoSave } from '@/hooks/useCardFormAutoSave';
import { useUnsavedChangesGuard } from '@/hooks/useUnsavedChangesGuard';
import { useCardDraftRecovery } from '@/hooks/useCardDraftRecovery';

function NewCardScreen() {
  const actions = useCardFormActions();
  const formData = useCardFormStore((state) => state.formData);

  // Check for existing draft
  const { isChecking } = useCardDraftRecovery({
    onNoDraft: () => actions.initializeNewCard(),
  });

  // Enable auto-save
  useCardFormAutoSave();

  // Protect against navigation
  useUnsavedChangesGuard();

  if (isChecking) return <LoadingSpinner />;

  return (
    <View>
      <TextInput
        value={formData.title}
        onChangeText={(text) => actions.updateField('title', text)}
      />
    </View>
  );
}
```

### Editing an Existing Card

```tsx
function EditCardScreen({ cardId }: { cardId: string }) {
  const actions = useCardFormActions();

  // Check for draft, otherwise load from API
  useCardDraftRecovery({
    cardId,
    onNoDraft: async () => {
      const card = await cardsApi.getCard(cardId);
      actions.initializeFromCard(card);
    },
  });

  useCardFormAutoSave();
  useUnsavedChangesGuard();

  // ... rest of component
}
```

## API Reference

### Store State

| Property | Type | Description |
|----------|------|-------------|
| `formData` | `CardFormData` | Current form state |
| `originalData` | `CardFormData \| null` | Original data for comparison |
| `isDirty` | `boolean` | Has unsaved changes |
| `isLoading` | `boolean` | Loading state |
| `isSaving` | `boolean` | Save in progress |
| `lastSavedAt` | `Date \| null` | Last auto-save time |
| `validationErrors` | `FormValidationErrors` | Current errors |
| `isEditing` | `boolean` | Editing existing card |

### Store Actions

| Action | Description |
|--------|-------------|
| `initializeNewCard()` | Reset for new card |
| `initializeFromCard(card)` | Load existing card |
| `initializeFromDraft(draft)` | Restore from draft |
| `updateField(field, value)` | Update form field |
| `addItem(item)` | Add item to card |
| `updateItem(id, updates)` | Update item |
| `removeItem(id)` | Remove item |
| `reorderItems(from, to)` | Reorder items |
| `addPhoto(uri)` | Add photo |
| `removePhoto(id)` | Remove photo |
| `validate()` | Run validation |
| `saveDraft()` | Save to AsyncStorage |
| `clearDraft()` | Remove draft |
| `reset()` | Clear all state |
| `markAsSaved()` | Clear dirty flag |

### Selector Hooks

```typescript
// Get just the form data
const formData = useCardFormData();

// Get dirty state
const isDirty = useCardFormIsDirty();

// Get validation errors
const errors = useCardFormErrors();

// Get loading/saving status
const { isLoading, isSaving, lastSavedAt } = useCardFormStatus();

// Get visible (non-deleted) items
const items = useCardFormVisibleItems();

// Get visible photos
const photos = useCardFormVisiblePhotos();

// Get all actions (stable references)
const actions = useCardFormActions();
```

## File Structure

```
stage-5a/
├── STAGE_5A_OUTLINE.md         # Detailed outline
├── README.md                   # This file
└── src/
    ├── types/
    │   └── cardForm.ts         # TypeScript types
    ├── stores/
    │   └── cardFormStore.ts    # Zustand store
    ├── hooks/
    │   ├── index.ts            # Exports
    │   ├── useCardFormAutoSave.ts
    │   ├── useUnsavedChangesGuard.ts
    │   └── useCardDraftRecovery.ts
    ├── utils/
    │   └── cardFormUtils.ts    # Helpers
    └── examples/
        └── CardFormExamples.tsx # Examples
```

## Best Practices

### 1. Use Selectors for Performance

```tsx
// ✅ Good - Only re-renders when title changes
const title = useCardFormStore((state) => state.formData.title);

// ❌ Avoid - Re-renders on any state change
const { formData } = useCardFormStore();
```

### 2. Clean Up on Unmount

The hooks handle cleanup automatically. If you need manual cleanup:

```tsx
useEffect(() => {
  return () => {
    useCardFormStore.getState().reset();
  };
}, []);
```

### 3. Handle Validation Before Save

```tsx
const handleSave = async () => {
  const { validate, formData } = useCardFormStore.getState();
  
  if (!validate()) {
    // Show error toast
    return;
  }
  
  // Proceed with save...
};
```

## Integration with Stages 5B-5E

This stage provides the foundation. Future stages will:

- **5B**: Build the basic info form UI
- **5C**: Add item management modals
- **5D**: Implement photo upload
- **5E**: Complete CRUD operations

## Troubleshooting

### Draft Not Saving

1. Check that `draftKey` is set (use `initializeNewCard()` or `initializeFromCard()`)
2. Verify AsyncStorage is properly installed
3. Check for errors in the auto-save `onError` callback

### Navigation Guard Not Working

1. Ensure `useUnsavedChangesGuard` is called in the screen component
2. Check that `isDirty` is `true` (make a change to the form)
3. Verify expo-router is properly configured

### Types Not Matching API

Update the API types in `cardForm.ts` to match your backend schema:

- `PreferenceCardWithItems`
- `PreferenceCardItem`
- `CreatePreferenceCardRequest`
- `UpdatePreferenceCardRequest`
