// ============================================
// SurgicalPrep - Instruments API
// Instrument browsing and search endpoints
// ============================================

import apiClient from './client';
import type {
  Instrument,
  InstrumentListParams,
  InstrumentSearchParams,
  PaginatedResponse,
} from '../types';

export const instrumentsApi = {
  /**
   * Get paginated list of instruments
   */
  getInstruments: async (params: InstrumentListParams = {}): Promise<PaginatedResponse<Instrument>> => {
    const response = await apiClient.get<PaginatedResponse<Instrument>>('/instruments', { params });
    return response.data;
  },

  /**
   * Get single instrument by ID
   */
  getInstrument: async (id: string): Promise<Instrument> => {
    const response = await apiClient.get<Instrument>(`/instruments/${id}`);
    return response.data;
  },

  /**
   * Full-text search instruments
   */
  searchInstruments: async (params: InstrumentSearchParams): Promise<Instrument[]> => {
    const response = await apiClient.get<Instrument[]>('/instruments/search', { params });
    return response.data;
  },

  /**
   * Get instruments by category
   */
  getByCategory: async (category: string, params: Omit<InstrumentListParams, 'category'> = {}): Promise<PaginatedResponse<Instrument>> => {
    const response = await apiClient.get<PaginatedResponse<Instrument>>('/instruments', {
      params: { ...params, category },
    });
    return response.data;
  },

  /**
   * Get instrument categories with counts
   */
  getCategories: async (): Promise<Array<{ category: string; count: number }>> => {
    const response = await apiClient.get<Array<{ category: string; count: number }>>('/instruments/categories');
    return response.data;
  },

  /**
   * Toggle bookmark for instrument
   */
  toggleBookmark: async (instrumentId: string): Promise<{ is_bookmarked: boolean }> => {
    const response = await apiClient.post<{ is_bookmarked: boolean }>(`/instruments/${instrumentId}/bookmark`);
    return response.data;
  },

  /**
   * Get user's bookmarked instruments
   */
  getBookmarked: async (params: Omit<InstrumentListParams, 'category'> = {}): Promise<PaginatedResponse<Instrument>> => {
    const response = await apiClient.get<PaginatedResponse<Instrument>>('/instruments/bookmarked', { params });
    return response.data;
  },
};

export default instrumentsApi;
