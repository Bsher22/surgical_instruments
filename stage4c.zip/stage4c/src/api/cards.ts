/**
 * Cards API Client
 * API functions for preference card CRUD operations
 */
import { apiClient } from './client';
import type {
  PreferenceCard,
  PreferenceCardListItem,
  GetCardsParams,
  CreatePreferenceCardInput,
  UpdatePreferenceCardInput,
  PaginatedResponse,
} from '../types';

const CARDS_ENDPOINT = '/api/v1/cards';

export const cardsApi = {
  /**
   * Get paginated list of user's preference cards
   */
  async getCards(params: GetCardsParams = {}): Promise<PaginatedResponse<PreferenceCardListItem>> {
    const searchParams = new URLSearchParams();
    
    if (params.search) searchParams.append('search', params.search);
    if (params.specialty) searchParams.append('specialty', params.specialty);
    if (params.page) searchParams.append('page', params.page.toString());
    if (params.page_size) searchParams.append('page_size', params.page_size.toString());
    if (params.include_templates !== undefined) {
      searchParams.append('include_templates', params.include_templates.toString());
    }

    const queryString = searchParams.toString();
    const url = queryString ? `${CARDS_ENDPOINT}?${queryString}` : CARDS_ENDPOINT;

    const response = await apiClient.get<PaginatedResponse<PreferenceCardListItem>>(url);
    return response.data;
  },

  /**
   * Get single preference card with all items and photos
   */
  async getCard(id: string): Promise<PreferenceCard> {
    const response = await apiClient.get<PreferenceCard>(`${CARDS_ENDPOINT}/${id}`);
    return response.data;
  },

  /**
   * Get public template cards
   */
  async getTemplates(): Promise<PreferenceCardListItem[]> {
    const response = await apiClient.get<PreferenceCardListItem[]>(`${CARDS_ENDPOINT}/templates`);
    return response.data;
  },

  /**
   * Create a new preference card
   */
  async createCard(data: CreatePreferenceCardInput): Promise<PreferenceCard> {
    const response = await apiClient.post<PreferenceCard>(CARDS_ENDPOINT, data);
    return response.data;
  },

  /**
   * Update an existing preference card
   */
  async updateCard(id: string, data: UpdatePreferenceCardInput): Promise<PreferenceCard> {
    const response = await apiClient.patch<PreferenceCard>(`${CARDS_ENDPOINT}/${id}`, data);
    return response.data;
  },

  /**
   * Delete a preference card
   */
  async deleteCard(id: string): Promise<void> {
    await apiClient.delete(`${CARDS_ENDPOINT}/${id}`);
  },

  /**
   * Duplicate a preference card
   */
  async duplicateCard(id: string): Promise<PreferenceCard> {
    const response = await apiClient.post<PreferenceCard>(`${CARDS_ENDPOINT}/${id}/duplicate`);
    return response.data;
  },

  /**
   * Upload a photo to a card
   */
  async uploadPhoto(cardId: string, formData: FormData): Promise<{ photo_url: string }> {
    const response = await apiClient.post<{ photo_url: string }>(
      `${CARDS_ENDPOINT}/${cardId}/photos`,
      formData,
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );
    return response.data;
  },

  /**
   * Delete a photo from a card
   */
  async deletePhoto(cardId: string, photoId: string): Promise<void> {
    await apiClient.delete(`${CARDS_ENDPOINT}/${cardId}/photos/${photoId}`);
  },

  /**
   * Add an item to a card
   */
  async addItem(
    cardId: string,
    item: {
      instrument_id?: string;
      item_name: string;
      quantity?: number;
      size?: string;
      notes?: string;
      category?: string;
    }
  ) {
    const response = await apiClient.post(`${CARDS_ENDPOINT}/${cardId}/items`, item);
    return response.data;
  },

  /**
   * Update an item on a card
   */
  async updateItem(
    cardId: string,
    itemId: string,
    data: {
      item_name?: string;
      quantity?: number;
      size?: string;
      notes?: string;
      category?: string;
      order_index?: number;
    }
  ) {
    const response = await apiClient.patch(`${CARDS_ENDPOINT}/${cardId}/items/${itemId}`, data);
    return response.data;
  },

  /**
   * Delete an item from a card
   */
  async deleteItem(cardId: string, itemId: string): Promise<void> {
    await apiClient.delete(`${CARDS_ENDPOINT}/${cardId}/items/${itemId}`);
  },

  /**
   * Reorder items on a card
   */
  async reorderItems(cardId: string, itemIds: string[]): Promise<void> {
    await apiClient.post(`${CARDS_ENDPOINT}/${cardId}/items/reorder`, { item_ids: itemIds });
  },
};
