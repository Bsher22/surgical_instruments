# Stage 3A: Instruments API Layer

This package contains the API client and React Query hooks for the Instruments feature of SurgicalPrep.

## Files Overview

```
src/
├── api/
│   ├── client.ts          # Base axios client with auth interceptors
│   └── instruments.ts     # Instruments API functions
├── hooks/
│   └── useInstruments.ts  # React Query hooks
└── types/
    ├── index.ts           # Type exports
    └── instruments.ts     # Instrument type definitions
```

## Installation

Copy these files into your `mobile/src/` directory, then install dependencies:

```bash
npm install axios @tanstack/react-query expo-secure-store expo-constants
```

## Setup

### 1. Configure API URL

Create or update your `app.json` or `app.config.ts`:

```json
{
  "expo": {
    "extra": {
      "apiUrl": "https://your-api.railway.app"
    }
  }
}
```

Or set environment variable:
```bash
EXPO_PUBLIC_API_URL=https://your-api.railway.app
```

### 2. Add React Query Provider

In your root layout (`app/_layout.tsx`):

```tsx
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 2,
      refetchOnWindowFocus: false,
    },
  },
});

export default function RootLayout() {
  return (
    <QueryClientProvider client={queryClient}>
      {/* Your app */}
    </QueryClientProvider>
  );
}
```

## Usage Examples

### Paginated List with Filters

```tsx
import { useInstruments } from '@/hooks/useInstruments';

function InstrumentList() {
  const [category, setCategory] = useState<InstrumentCategory | undefined>();
  
  const { data, isLoading, error } = useInstruments({
    category,
    limit: 20,
  });

  if (isLoading) return <LoadingSpinner />;
  if (error) return <ErrorMessage error={error} />;

  return (
    <FlatList
      data={data?.items}
      renderItem={({ item }) => <InstrumentCard instrument={item} />}
    />
  );
}
```

### Infinite Scroll

```tsx
import { useInfiniteInstruments } from '@/hooks/useInstruments';

function InstrumentList() {
  const {
    data,
    fetchNextPage,
    hasNextPage,
    isFetchingNextPage,
  } = useInfiniteInstruments({ category: 'cutting' });

  const instruments = data?.pages.flatMap(page => page.items) ?? [];

  return (
    <FlatList
      data={instruments}
      renderItem={({ item }) => <InstrumentCard instrument={item} />}
      onEndReached={() => hasNextPage && fetchNextPage()}
      ListFooterComponent={isFetchingNextPage ? <LoadingSpinner /> : null}
    />
  );
}
```

### Search with Debounce

```tsx
import { useInstrumentSearch } from '@/hooks/useInstruments';
import { useDebouncedValue } from '@/hooks/useDebouncedValue';

function InstrumentSearch() {
  const [searchText, setSearchText] = useState('');
  const debouncedSearch = useDebouncedValue(searchText, 300);

  const { data, isLoading } = useInstrumentSearch({
    query: debouncedSearch,
    limit: 10,
  });

  return (
    <>
      <TextInput
        value={searchText}
        onChangeText={setSearchText}
        placeholder="Search instruments..."
      />
      {isLoading && <ActivityIndicator />}
      {data?.results.map(result => (
        <SearchResultItem key={result.id} result={result} />
      ))}
    </>
  );
}
```

### Single Instrument Detail

```tsx
import { useInstrument } from '@/hooks/useInstruments';

function InstrumentDetail({ id }: { id: string }) {
  const { data: instrument, isLoading } = useInstrument(id);

  if (isLoading) return <DetailSkeleton />;
  if (!instrument) return null;

  return (
    <ScrollView>
      <Image source={{ uri: instrument.image_url }} />
      <Text>{instrument.name}</Text>
      <CategoryBadge category={instrument.category} />
      <Text>{instrument.description}</Text>
      {/* ... */}
    </ScrollView>
  );
}
```

## API Functions

| Function | Description |
|----------|-------------|
| `getInstruments(params)` | Paginated list with search/filter |
| `getInstrument(id)` | Single instrument detail |
| `searchInstruments(params)` | Full-text search |
| `getCategories()` | Category list with counts |
| `getInstrumentsByIds(ids)` | Batch fetch by IDs |
| `getPopularInstruments(limit)` | Popular/suggested instruments |
| `getRelatedInstruments(id, limit)` | Related instruments |

## React Query Hooks

| Hook | Description |
|------|-------------|
| `useInstruments(params)` | Paginated list query |
| `useInfiniteInstruments(params)` | Infinite scroll query |
| `useInstrument(id)` | Single instrument query |
| `useInstrumentSearch(params)` | Search query (auto-enabled when query ≥ 2 chars) |
| `useCategories()` | Categories with counts |
| `usePopularInstruments(limit)` | Popular instruments |
| `useRelatedInstruments(id, limit)` | Related instruments |
| `useInstrumentsByIds(ids)` | Batch fetch by IDs |

## Query Keys

Use `instrumentKeys` for cache invalidation:

```tsx
import { useQueryClient } from '@tanstack/react-query';
import { instrumentKeys } from '@/hooks/useInstruments';

const queryClient = useQueryClient();

// Invalidate all instrument queries
queryClient.invalidateQueries({ queryKey: instrumentKeys.all });

// Invalidate specific instrument
queryClient.invalidateQueries({ queryKey: instrumentKeys.detail(instrumentId) });

// Invalidate all list queries
queryClient.invalidateQueries({ queryKey: instrumentKeys.lists() });
```

## Next Steps

After integrating Stage 3A, proceed to:
- **Stage 3B**: Instrument List Screen UI
- **Stage 3C**: UI Components (SearchBar, CategoryChip, InstrumentCard)
- **Stage 3D**: Instrument Detail Screen
