# Stage 3B: Instrument List Screen

## Overview

This stage implements the main instrument browsing screen with search, filtering, infinite scroll pagination, and related UI components.

## Features

| Feature | Description |
|---------|-------------|
| **Infinite Scroll** | FlatList with automatic pagination when nearing end of list |
| **Search** | Debounced search bar (300ms) for instrument lookup |
| **Category Filter** | Horizontal scrollable chips for filtering by instrument category |
| **Pull-to-Refresh** | Standard refresh gesture to reload data |
| **Loading States** | Skeleton placeholders during initial load and pagination |
| **Empty State** | Friendly message when no instruments match filters |

## Files Included

```
stage-3b/
├── STAGE-3B-OUTLINE.md          # This file
├── app/
│   └── (tabs)/
│       └── instruments/
│           └── index.tsx        # Main instrument list screen
└── src/
    └── components/
        ├── InstrumentCard.tsx   # Individual instrument display card
        ├── SearchBar.tsx        # Search input with debounce
        ├── CategoryChip.tsx     # Filter chip component
        ├── LoadingSkeleton.tsx  # Skeleton loading placeholders
        ├── EmptyState.tsx       # Empty/no results state
        └── ui/
            └── index.ts         # Common UI component exports
```

## Dependencies (from Stage 2)

These should already be installed from Stage 2:

```bash
# Core
npx expo install @tanstack/react-query
npx expo install zustand

# For this stage specifically
npx expo install expo-image              # Optimized image loading
npx expo install lodash                  # For debounce utility
npm install --save-dev @types/lodash
```

## Prerequisites from Stage 3A

This stage assumes the following API layer exists from Stage 3A:

```typescript
// src/api/instruments.ts
export function useInstruments(params: InstrumentQueryParams): UseInfiniteQueryResult
export function useInstrumentSearch(query: string): UseQueryResult

// src/types/index.ts
export interface Instrument { ... }
export interface InstrumentQueryParams { ... }
```

## Component Specifications

### InstrumentCard
- Displays instrument thumbnail image (with fallback)
- Shows instrument name and category badge
- Touchable - navigates to detail screen
- Optimized with React.memo for list performance

### SearchBar
- Text input with search icon
- Clear button when text present
- 300ms debounced onChange callback
- Customizable placeholder text

### CategoryChip
- Toggleable pill/chip button
- Visual distinction for selected state
- Used in horizontal ScrollView

### LoadingSkeleton
- Mimics InstrumentCard layout
- Animated pulse/shimmer effect
- Configurable count for grid display

### EmptyState
- Icon + title + subtitle pattern
- Optional action button
- Used for both "no results" and "no data" states

## Usage

### Integration with Existing App

1. Copy files to your project maintaining the directory structure
2. Ensure Stage 3A API hooks are implemented
3. Update category list to match your database categories
4. Customize colors/styling to match your theme

### Screen Navigation

The list screen expects Expo Router file-based routing:
- List: `app/(tabs)/instruments/index.tsx` → `/instruments`
- Detail: `app/(tabs)/instruments/[id].tsx` → `/instruments/123` (Stage 3D)

## Customization Points

### Categories
Update the `CATEGORIES` array in `index.tsx` to match your instrument categories:

```typescript
const CATEGORIES = [
  'All',
  'Cutting',
  'Clamping',
  'Grasping',
  'Retracting',
  'Suturing',
  // Add your categories...
];
```

### Styling
Key style values to customize:
- `CARD_MARGIN`: Spacing between cards
- `NUM_COLUMNS`: Grid column count (default: 2)
- Color values for chips, cards, backgrounds

### Pagination
Adjust `PAGE_SIZE` constant for items per page (default: 20)

## Testing Checklist

- [ ] List loads initial instruments
- [ ] Scroll to bottom triggers pagination
- [ ] Pull down refreshes the list
- [ ] Search filters results after typing stops
- [ ] Category chips filter by category
- [ ] "All" chip clears category filter
- [ ] Empty state shows when no results
- [ ] Loading skeletons appear during fetch
- [ ] Tapping card navigates to detail (once Stage 3D complete)
- [ ] Performance smooth with 100+ items
